## Question
(B)
Betty has a bracket sequence $s$ of length $n$, which consists of eight types of brackets: "()\[\]{}<>". Additionally, she has $m$ sub-bracket sequences, and the $i$\-th sub-bracket sequence $t_i$ is the sequence formed by concatenating the characters from the $l_i$\-th to the $r_i$\-th position of $s$, i.e., $t_i = s_{l_i}s_{l_i+1} \cdots s_{r_i}$.
Betty wants to know, by taking out several pairs from these $m$ sub-bracket sequences and concatenating sequences in the same pair, how many valid bracket sequences$^\dagger$ can be formed at most? Formally, you need to find as many pairs $(a_i, b_i)$ as possible such that:
1.  For any integer $x$ from $1$ to $m$, the sum of its occurrences in $a$ and its occurrences in $b$ should be no larger than $1$.
2.  For any pair $(a_i, b_i)$, $t_{a_i}t_{b_i}$ is a valid bracket sequence$^\dagger$.
$^\dagger$ A bracket sequence $x$ is valid if and only if it satisfies one of the following conditions:
-   $|x| = 0$, i.e., $x$ is an empty string.
-   $x = LyR$, where $y$ is a valid bracket sequence, and $L$, $R$ are left and right brackets of the same type (i.e., $L=$ "(" and $R=$ ")", or $L=$ "\[" and $R=$ "\]", or $L=$ "{" and $R=$ "}", or $L=$ "<" and $R=$ "\>").
-   $x = y_1y_2$, where both $y_1$ and $y_2$ are valid bracket sequences.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line contains two integers $n$ and $m$ ($1 \leq n, m \leq 5 \times 10^5$), which represent the length of $s$ and the number of sub-bracket sequences, respectively.
The second line contains a string $s$ ($|s| = n$), which consists only of the eight brackets "()\[\]{}<>".
The next $m$ lines each contain two integers $l_i$ and $r_i$ ($1 \leq l_i \leq r_i \leq n$).
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $5 \times 10^5$, and the sum of $m$ over all test cases does not exceed $5 \times 10^5$.

**Output**
For each test case, output a single integer on a new line, representing the maximum number of valid bracket sequences that can be obtained by concatenating pairs of sub-bracket sequences.

Example Input1：
8 1
()[]{}<>
3 6
Example Output1：
0

Example Input2：
2 6
)(
1 1
1 1
1 1
2 2
2 2
2 2
Example Output2：
3

**Note**
In the first test case, $t_1=$ "\[\]{}". Although $t_1$ is already a valid bracket sequence, there are no other sub-bracket sequences that can be paired with it, so the output is $0$.
In the second test case, there are six sub-bracket sequences containing three "(" and three ")", which can be used to form three valid bracket sequences "()". Therefore, the output should be $3$.
In the third test case, no valid bracket sequences can be formed.
In the fourth test case, one possible matching is $t_1t_2$: "{}««" + "»»", and $t_4t_5$: "{}" + "{()}".


## Solution


import sys
from collections import defaultdict

def solve():
    n, m = map(int, sys.stdin.readline().split())
    s = sys.stdin.readline().strip()
    cnt = [0] * 8
    for c in s:
        if c == '(':
            cnt[0] += 1
        elif c == ')':
            cnt[1] += 1
        elif c == '[':
            cnt[2] += 1
        elif c == ']':
            cnt[3] += 1
        elif c == '{':
            cnt[4] += 1
        elif c == '}':
            cnt[5] += 1
        elif c == '<':
            cnt[6] += 1
        elif c == '>':
            cnt[7] += 1

    t = []
    for _ in range(m):
        l, r = map(int, sys.stdin.readline().split())
        cur = [0] * 8
        for i in range(l - 1, r):
            if s[i] == '(':
                cur[0] += 1
            elif s[i] == ')':
                cur[1] += 1
            elif s[i] == '[':
                cur[2] += 1
            elif s[i] == ']':
                cur[3] += 1
            elif s[i] == '{':
                cur[4] += 1
            elif s[i] == '}':
                cur[5] += 1
            elif s[i] == '<':
                cur[6] += 1
            elif s[i] == '>':
                cur[7] += 1
        t.append(cur)

    mp = defaultdict(list)
    for i, cur in enumerate(t):
        key = tuple(cur[0] - cur[1], cur[2] - cur[3], cur[4] - cur[5], cur[6] - cur[7])
        mp[key].append(i)

    ans = 0
    used = [False] * m
    for key in list(mp.keys()):
        if key == (0, 0, 0, 0):
            ans += len(mp[key]) // 2
        elif (-key[0], -key[1], -key[2], -key[3]) in mp:
            p1, p2 = mp[key], mp[(-key[0], -key[1], -key[2], -key[3])]
            i, j = 0, 0
            while i < len(p1) and j < len(p2):
                if not used[p1[i]] and not used[p2[j]]:
                    ans += 1
                    used[p1[i]] = used[p2[j]] = True
                i += 1
                j += 1
    print(ans)

T = int(sys.stdin.readline())
for _ in range(T):
    solve()



## CODE


import sys
from collections import defaultdict

def solve():
    n, m = map(int, sys.stdin.readline().split())
    s = sys.stdin.readline().strip()
    cnt = [0] * 8
    for c in s:
        if c == '(':
            cnt[0] += 1
        elif c == ')':
            cnt[1] += 1
        elif c == '[':
            cnt[2] += 1
        elif c == ']':
            cnt[3] += 1
        elif c == '{':
            cnt[4] += 1
        elif c == '}':
            cnt[5] += 1
        elif c == '<':
            cnt[6] += 1
        elif c == '>':
            cnt[7] += 1

    t = []
    for _ in range(m):
        l, r = map(int, sys.stdin.readline().split())
        cur = [0] * 8
        for i in range(l - 1, r):
            if s[i] == '(':
                cur[0] += 1
            elif s[i] == ')':
                cur[1] += 1
            elif s[i] == '[':
                cur[2] += 1
            elif s[i] == ']':
                cur[3] += 1
            elif s[i] == '{':
                cur[4] += 1
            elif s[i] == '}':
                cur[5] += 1
            elif s[i] == '<':
                cur[6] += 1
            elif s[i] == '>':
                cur[7] += 1
        t.append(cur)

    mp = defaultdict(list)
    for i, cur in enumerate(t):
        key = tuple(cur[0] - cur[1], cur[2] - cur[3], cur[4] - cur[5], cur[6] - cur[7])
        mp[key].append(i)

    ans = 0
    used = [False] * m
    for key in list(mp.keys()):
        if key == (0, 0, 0, 0):
            ans += len(mp[key]) // 2
        elif (-key[0], -key[1], -key[2], -key[3]) in mp:
            p1, p2 = mp[key], mp[(-key[0], -key[1], -key[2], -key[3])]
            i, j = 0, 0
            while i < len(p1) and j < len(p2):
                if not used[p1[i]] and not used[p2[j]]:
                    ans += 1
                    used[p1[i]] = used[p2[j]] = True
                i += 1
                j += 1
    print(ans)

T = int(sys.stdin.readline())
for _ in range(T):
    solve()


### Explanation
This solution first reads the input and counts the occurrences of each bracket in the string `s`. Then it reads the `m` sub-bracket sequences and counts the occurrences of each bracket in each sequence. It stores these counts in a list `t`.

Next, it creates a dictionary `mp` where the keys are tuples representing the differences between the counts of opening and closing brackets of each type, and the values are lists of indices of the sub-bracket sequences that have these differences.

Finally, it iterates over the keys in `mp` and checks if the negation of the key is also in `mp`. If it is, it means that there are sub-bracket sequences that can be paired together to form a valid bracket sequence. It then iterates over the indices of these sequences and marks them as used if they are not already used. The number of pairs that can be formed is added to the answer.

If the key is `(0, 0, 0, 0)`, it means that the sub-bracket sequence is already a valid bracket sequence, so it can be paired with itself. In this case, the number of pairs that can be formed is half the number of sequences with this key.

The final answer is the total number of pairs that can be formed.
## Token
[896, 991, 1887]
 ### 

## Question


(C)
The pirates have just seized a giant gold coin!
To determine the ownership of this gold coin, they decided to select the owner using the following method:
Let the current number of remaining pirates be $n$. The pirates line up in a queue, and the pirates at positions $1, 1+k, 1+2k, \dots, 1+(\lceil\frac{n}{k}\rceil - 1) k$ are eliminated. This operation is repeated until only one pirate remains. The final remaining pirate will receive the gold coin.
Charlie is the smartest among the pirates. He wants to know where he should stand initially to be the last pirate remaining and win the coin.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 100$). The description of the test cases follows.
The first line of each test case contains two integers $n$ and $k$ ($2 \leq n, k \leq 10^{12}$), representing the initial number of pirates and the parameter used for elimination.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $10^{12}$, and the sum of $k$ over all test cases does not exceed $10^{12}$.

**Output**
For each test case, output a single integer on a new line, indicating the position of the pirate who will ultimately receive the gold coin in the initial queue.

Example Input1：
6 2
Example Output1：
4

Example Input2：
1919810
Example Output2：
1919805

**Note**
For the first test case in the example, the positions of the remaining pirates in the original sequence after each round are:
-   Initial state: $1, 2, 3, 4, 5, 6$.
-   After the first round: $2, 4, 6$.
-   After the second round: $4$.
For the second test case in the example, the positions of the remaining pirates in the original sequence after each round are:
-   Initial state: $1, 2, 3, 4, 5, 6, 7, 8$.
-   After the first round: $2, 3, 5, 6, 8$.
-   After the second round: $3, 5, 8$.
-   After the third round: $5, 8$.
-   After the fourth round: $8$.


## Solution


def find_winner(n, k):
    if n == 1:
        return 1
    if k == 1:
        return n
    if n % 2 == 0:
        return 2 * find_winner(n // 2, k) - 1
    else:
        return 2 * find_winner((n - 1) // 2, k) + 1

def solve():
    n, k = map(int, input().split())
    if k > n:
        print(1)
        return
    if n % k == 1:
        print(1)
        return
    ans = find_winner(n, k)
    print(ans)

t = int(input())
for _ in range(t):
    solve()



## CODE


def find_winner(n, k):
    if n == 1:
        return 1
    if k == 1:
        return n
    if n % 2 == 0:
        return 2 * find_winner(n // 2, k) - 1
    else:
        return 2 * find_winner((n - 1) // 2, k) + 1

def solve():
    n, k = map(int, input().split())
    if k > n:
        print(1)
        return
    if n % k == 1:
        print(1)
        return
    ans = find_winner(n, k)
    print(ans)

t = int(input())
for _ in range(t):
    solve()


### Explanation
This problem can be solved using a recursive approach. The idea is to simulate the elimination process and find the position of the last remaining pirate. The `find_winner` function takes two parameters, `n` and `k`, which represent the number of pirates and the elimination interval, respectively. The function uses the following rules to determine the position of the last remaining pirate: if `n` is 1, the last remaining pirate is at position 1; if `k` is 1, the last remaining pirate is at position `n`; if `n` is even, the last remaining pirate is at position `2 * find_winner(n // 2, k) - 1`; if `n` is odd, the last remaining pirate is at position `2 * find_winner((n - 1) // 2, k) + 1`. The `solve` function reads the input, calls the `find_winner` function, and prints the result.
## Token
[367, 639, 1006]
 ### 

## Question


(D)
David has just obtained $n$ Russian nesting dolls of distinct sizes. He arranges these dolls in a row from left to right, where the $i$\-th position contains a doll of size $a_i$.
Let the size of the smallest doll in the $i$\-th position be $l_i$, and the size of the largest one be $r_i$. Dolls over two adjacent positions $i$ and $i+1$ can be merged if and only if $r_i &lt; l_{i+1}$ or $r_{i+1} &lt; l_i$. The new nesting doll will contain all the dolls from the original $i$\-th and $i+1$\-th positions and will be placed in the $i$\-th position. All dolls in positions greater than $i+1$ will shift left by one position to fill the gap.
For example, when $n=4, a=[2,1,4,3]$, David can:
1.  Merge the dolls in positions $1$ and $2$. Now the remaining dolls have sizes $[(1,2), (4), (3)]$.
2.  Merge the dolls in positions $2$ and $3$. Now the remaining dolls have sizes $[(1,2), (3,4)]$.
3.  Merge the dolls in positions $1$ and $2$. Now all the dolls have been merged into one position.
How many merge operations at most can David perform under an optimal strategy?

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line of each test case contains an integer $n$ ($1 \leq n \leq 10^5$), representing the number of nesting dolls.
The second line contains $n$ integers $a_1, a_2, \dots, a_n$ ($1 \leq a_i \leq n$, $\forall i \neq j, a_i \neq a_j$), representing the initial sizes of the dolls in each position.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $10^5$.

**Output**
For each test case, output a single integer on a new line, representing the maximum number of merge operations that can be performed.

Example Input1：
4
2 1 4 3
Example Output1：
3
Example Input2：
4
1 4 2 3
Example Output2：
3
Example Input3：
6
2 5 1 3 6 4
Example Output3：
4


## Solution


def max_merge_operations(n, dolls):
    """
    Calculate the maximum number of merge operations that can be performed.
    
    Args:
    n (int): The number of dolls.
    dolls (list): A list of integers representing the sizes of the dolls.
    
    Returns:
    int: The maximum number of merge operations.
    """
    # Initialize a list to store the maximum number of merge operations for each subsequence.
    merge_ops = [1] * n
    
    # Initialize the maximum number of merge operations.
    max_ops = 1
    
    # Iterate over the dolls from left to right.
    for i in range(1, n):
        # For each doll, compare it with all previous dolls.
        for j in range(i):
            # If the current doll can be merged with the previous doll, update the maximum number of merge operations.
            if dolls[i] > dolls[j] or dolls[i] < dolls[j]:
                merge_ops[i] = max(merge_ops[i], merge_ops[j] + 1)
        
        # Update the maximum number of merge operations.
        max_ops = max(max_ops, merge_ops[i])
    
    # The maximum number of merge operations is the maximum value in the merge_ops list minus 1.
    return max_ops - 1

# Read the number of test cases.
T = int(input())

# Iterate over the test cases.
for _ in range(T):
    # Read the number of dolls.
    n = int(input())
    
    # Read the sizes of the dolls.
    dolls = list(map(int, input().split()))
    
    # Calculate and print the maximum number of merge operations.
    print(max_merge_operations(n, dolls))



## CODE


def max_merge_operations(n, dolls):
    """
    Calculate the maximum number of merge operations that can be performed.
    
    Args:
    n (int): The number of dolls.
    dolls (list): A list of integers representing the sizes of the dolls.
    
    Returns:
    int: The maximum number of merge operations.
    """
    # Initialize a list to store the maximum number of merge operations for each subsequence.
    merge_ops = [1] * n
    
    # Initialize the maximum number of merge operations.
    max_ops = 1
    
    # Iterate over the dolls from left to right.
    for i in range(1, n):
        # For each doll, compare it with all previous dolls.
        for j in range(i):
            # If the current doll can be merged with the previous doll, update the maximum number of merge operations.
            if dolls[i] > dolls[j] or dolls[i] < dolls[j]:
                merge_ops[i] = max(merge_ops[i], merge_ops[j] + 1)
        
        # Update the maximum number of merge operations.
        max_ops = max(max_ops, merge_ops[i])
    
    # The maximum number of merge operations is the maximum value in the merge_ops list minus 1.
    return max_ops - 1

# Read the number of test cases.
T = int(input())

# Iterate over the test cases.
for _ in range(T):
    # Read the number of dolls.
    n = int(input())
    
    # Read the sizes of the dolls.
    dolls = list(map(int, input().split()))
    
    # Calculate and print the maximum number of merge operations.
    print(max_merge_operations(n, dolls))


### Explanation
The solution uses dynamic programming to calculate the maximum number of merge operations. It iterates over the dolls from left to right and for each doll, it compares it with all previous dolls. If the current doll can be merged with the previous doll, it updates the maximum number of merge operations. The maximum number of merge operations is the maximum value in the merge_ops list minus 1. This approach ensures that the solution has a time complexity of O(n^2), where n is the number of dolls.
## Token
[464, 681, 1145]
 ### 

## Question


(E)
This is an interactive problem.
Emily has a tree containing $n$ nodes, where the weight of the node numbered $i$ is $w_i$. Node $1$ is the root node, and the weight of the root node is $0$.
Emily wants you to guess the weight of each node. Specifically, you can make at most $n$ queries, with the $i$\-th query containing two integers $u_i$ and $v_i$. If the simple path from $u_i$ to $v_i$ contains exactly $k$ edges, Emily will tell you the bitwise XOR$^{\dagger}$ of the weights of all the nodes on the simple path from node $u_i$ to node $v_i$ (including the endpoints). Otherwise, Emily will respond with "-1", indicating that she does not want to answer that question. Emily is very busy, so she will not start answering until you have asked all your questions.
Of course, you may not be able to guess the weights of all nodes with no more than $n$ queries for some cases. In such cases, you should not make any queries and instead directly tell Emily that it is impossible.
$^{\dagger}$The bitwise XOR operation refers to the addition of each bit of two binary numbers under modulo $2$. For example: $(0011)_2$ $\oplus$ $(0101)_2$ $=$ $(0110)_2$.


**Input**
There is only one test case in each test file.
The first line contains two integers $n$ and $k$ ($2 \leq n \leq 250$, $1 \leq k \leq n-1$), representing the number of nodes in the tree and a parameter mentioned in the query.
The next $n-1$ lines each contain two integers $x_i$ and $y_i$ ($1 \leq x_i, y_i \leq n$), indicating that there is an edge between nodes $x_i$ and $y_i$.
It is guaranteed that all edges form a tree, and the correct answer satisfies $0 \leq w_i &lt; 2^{30}$.

**Interaction**
First, you need to determine whether it is possible to guess the weights of all nodes within $n$ queries. If not, your program should output "No" and exit immediately. Otherwise, your program should output "Yes" and proceed to querying. You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.
To make a query, output **all** your $q$ queries **at once** in the format "? $q$ $u_1$ $v_1$ $u_2$ $v_2$ $\dots$ $u_q$ $v_q$" ($1 \leq q \leq n$, $1 \leq u_i, v_i \leq n$). After flushing your output, your program should read a line containing $q$ integers. The $i$\-th integer represents the response to the $i$\-th query.
To guess the weights, output your guess in the format "! $w_2$ $w_3$ $\dots$ $w_n$" ($0 \leq w_i &lt; 2^{30}$). After flushing your output, your program should exit immediately.
Note that the answer for each test case is pre-determined. That is, the interactor is not adaptive. Also, note that your guess does not count as a query.
To flush your output, you can use:
-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java and Kotlin.
-   stdout.flush() in Python.

Example Input1：
4 1
1 2
2 3
2 4


1 3 2
Example Output1：




YES
? 3 1 2 2 3 2 4

! 1 2 3
Example Input2：
5 2
1 2
2 3
3 4
3 5


1 2 3 4
Example Output2：





YES
? 4 1 3 2 4 2 5 4 5 

! 4 5 3 2


## Solution


import sys

def dfs(u, fa, dep, g, k, queries, ans):
    for v in g[u]:
        if v == fa:
            continue
        if dep + 1 <= k:
            queries.append((u, v))
            ans[v] = len(queries) - 1
        else:
            ans[v] = ans[u]
        dfs(v, u, dep + 1, g, k, queries, ans)

def main():
    n, k = map(int, input().split())
    g = [[] for _ in range(n + 1)]
    for _ in range(n - 1):
        x, y = map(int, input().split())
        g[x].append(y)
        g[y].append(x)
    if k == 1:
        if n == 2:
            print("YES")
            print("! 0")
        else:
            print("NO")
        return
    queries = []
    ans = [0] * (n + 1)
    dfs(1, 0, 0, g, k, queries, ans)
    print("YES")
    print("? " + str(len(queries)), end="")
    for u, v in queries:
        print(" " + str(u) + " " + str(v), end="")
    print()
    sys.stdout.flush()
    res = list(map(int, input().split()))
    xor = [0] * (n + 1)
    for i in range(len(queries)):
        u, v = queries[i]
        xor[u] ^= res[i]
        xor[v] ^= res[i]
    print("!", end="")
    for i in range(2, n + 1):
        print(" " + str(xor[i] ^ xor[1]), end="")
    print()
    sys.stdout.flush()

if __name__ == "__main__":
    main()



## CODE


import sys

def dfs(u, fa, dep, g, k, queries, ans):
    for v in g[u]:
        if v == fa:
            continue
        if dep + 1 <= k:
            queries.append((u, v))
            ans[v] = len(queries) - 1
        else:
            ans[v] = ans[u]
        dfs(v, u, dep + 1, g, k, queries, ans)

def main():
    n, k = map(int, input().split())
    g = [[] for _ in range(n + 1)]
    for _ in range(n - 1):
        x, y = map(int, input().split())
        g[x].append(y)
        g[y].append(x)
    if k == 1:
        if n == 2:
            print("YES")
            print("! 0")
        else:
            print("NO")
        return
    queries = []
    ans = [0] * (n + 1)
    dfs(1, 0, 0, g, k, queries, ans)
    print("YES")
    print("? " + str(len(queries)), end="")
    for u, v in queries:
        print(" " + str(u) + " " + str(v), end="")
    print()
    sys.stdout.flush()
    res = list(map(int, input().split()))
    xor = [0] * (n + 1)
    for i in range(len(queries)):
        u, v = queries[i]
        xor[u] ^= res[i]
        xor[v] ^= res[i]
    print("!", end="")
    for i in range(2, n + 1):
        print(" " + str(xor[i] ^ xor[1]), end="")
    print()
    sys.stdout.flush()

if __name__ == "__main__":
    main()


### Explanation
This code uses a depth-first search (DFS) to traverse the tree and generate queries. The DFS function takes the current node, its father, the current depth, the graph, the parameter k, the list of queries, and the answer array as parameters. If the current depth is less than or equal to k, it generates a query for the current node and its child, and records the index of the query in the answer array. Otherwise, it copies the answer of the father to the current node. After generating all queries, it prints the queries and reads the responses. Finally, it calculates the weights of the nodes by XORing the responses and prints the weights.
## Token
[541, 1033, 1574]
 ### 

## Question


(F)
Frank is fascinated by the beauty of numbers.
One day, Frank was watering flowers in his garden. Looking at the beautiful petals, he thought it would be wonderful if each flower could grow numbers.
So, he took out paper and pen and started sketching his ideal "number flower". An undirected connected graph is called a "number flower" if and only if it satisfies the following three conditions:
1.  If the graph contains $n$ nodes, these nodes should be labeled from $1$ to $n$.
2.  The graph contains exactly $n-1$ edges. No node has a degree greater than $2$ except for node $1$.
3.  Nodes directly connected to node $1$ are called key nodes. All key nodes have pairwise coprime labels. For each non-key node (except node $1$), its label is a multiple of the nearest key node's label, and the labels along the simple path from the non-key node to its nearest key node are monotonically decreasing.
Given an integer $n$, how many different "number flowers" with $n$ nodes are there? Two graphs $G_1$ and $G_2$ are considered the same if and only if for any edge $(u, v)$ in $G_1$, a corresponding edge $(u, v)$ exists in $G_2$.
Since the answer is huge, you only need to output it modulo a prime number $p$.

**Input**
There is only one test case in each test file.
The first line contains two positive integers $n$ and $p$ ($1 \leq n \leq 10^{10}$, $10^8 &lt; p &lt; 10^9$).
It is guaranteed that $p$ is a prime number.

**Output**
Output a single integer, which is the number of different "number flowers" modulo $p$.

Example Input1：
5 998244353
Example Output1：
1
Example Input2：
10 998244353
Example Output2：
4


## Solution


import sys
import math

def pow_mod(a, b, p):
    res = 1
    while b > 0:
        if b % 2 == 1:
            res = (res * a) % p
        a = (a * a) % p
        b >>= 1
    return res

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def get_mu(n):
    mu = [0] * (n + 1)
    mu[1] = 1
    for i in range(2, n + 1):
        if is_prime(i):
            for j in range(i, n + 1, i):
                mu[j] -= mu[j // i]
    return mu

def get_fac(n, p):
    fac = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = (fac[i - 1] * i) % p
    return fac

def get_inv_fac(n, p):
    inv_fac = [1] * (n + 1)
    inv_fac[n] = pow_mod(get_fac(n, p)[n], p - 2, p)
    for i in range(n - 1, -1, -1):
        inv_fac[i] = (inv_fac[i + 1] * (i + 1)) % p
    return inv_fac

def comb(n, m, p, fac, inv_fac):
    if m < 0 or m > n:
        return 0
    return ((fac[n] * inv_fac[m]) % p * inv_fac[n - m]) % p

def main():
    n, p = map(int, input().split())
    mu = get_mu(100)
    fac = get_fac(100, p)
    inv_fac = get_inv_fac(100, p)
    ans = 0
    for k in range(1, 101):
        res = 1
        for i in range(1, k + 1):
            res = (res * comb(k, i, p, fac, inv_fac)) % p
            res = (res * pow_mod(i, n - k - 1, p)) % p
            res = (res * mu[i]) % p
        ans = (ans + res) % p
    print(ans)

if __name__ == "__main__":
    main()



## CODE


import sys
import math

def pow_mod(a, b, p):
    res = 1
    while b > 0:
        if b % 2 == 1:
            res = (res * a) % p
        a = (a * a) % p
        b >>= 1
    return res

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def get_mu(n):
    mu = [0] * (n + 1)
    mu[1] = 1
    for i in range(2, n + 1):
        if is_prime(i):
            for j in range(i, n + 1, i):
                mu[j] -= mu[j // i]
    return mu

def get_fac(n, p):
    fac = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = (fac[i - 1] * i) % p
    return fac

def get_inv_fac(n, p):
    inv_fac = [1] * (n + 1)
    inv_fac[n] = pow_mod(get_fac(n, p)[n], p - 2, p)
    for i in range(n - 1, -1, -1):
        inv_fac[i] = (inv_fac[i + 1] * (i + 1)) % p
    return inv_fac

def comb(n, m, p, fac, inv_fac):
    if m < 0 or m > n:
        return 0
    return ((fac[n] * inv_fac[m]) % p * inv_fac[n - m]) % p

def main():
    n, p = map(int, input().split())
    mu = get_mu(100)
    fac = get_fac(100, p)
    inv_fac = get_inv_fac(100, p)
    ans = 0
    for k in range(1, 101):
        res = 1
        for i in range(1, k + 1):
            res = (res * comb(k, i, p, fac, inv_fac)) % p
            res = (res * pow_mod(i, n - k - 1, p)) % p
            res = (res * mu[i]) % p
        ans = (ans + res) % p
    print(ans)

if __name__ == "__main__":
    main()


### Explanation
This problem can be solved using the Principle of Inclusion-Exclusion (PIE) and the properties of the Möbius function. The main idea is to count the number of ways to choose k key nodes, and then for each choice, count the number of ways to assign the remaining n-k-1 nodes to the key nodes. The Möbius function is used to ensure that each configuration is counted correctly. The combinatorial calculations are performed using modular arithmetic to avoid overflow. The final answer is the sum over all possible values of k.
## Token
[678, 525, 1203]
 ### 

## Question


(G)
Given two integers $a$ and $b$, you can perform one of the following two operations in each round:
-   If $a &gt; 0$, then reduce the value of $a$ by $\gcd(a, b)$ .
-   If $b &gt; 0$, then reduce the value of $b$ by $\gcd(a, b)$ .
Grace wants to know the minimum number of rounds needed to make both $a$ and $b$ become $0$.
$^{\dagger}$ $\gcd(x, y)$ denotes the greatest common divisor of $x$ and $y$. For example, $\gcd(6, 8) = 2, \gcd(7, 5) = 1$. The values of $\gcd(x, 0)$ and $\gcd(0, x)$ are defined as $x$.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 1000$). The description of the test cases follows.
Each test case consists of a single line containing two integers $a$ and $b$ ($1 \leq a \leq b, a \leq 5000, b \leq 10^{18}$).
For each test file, it is guaranteed that the sum of $a$ over all test cases does not exceed $10^4$.

**Output**
For each test case, output a single integer representing the minimum number of rounds needed to make both $a$ and $b$ become $0$.

Example Input1：
3
3 4
12 20
114 514
Example Output1：
3
4
6

**Note**
For the first test case in the example, one possible optimal solution is:
-   Perform an operation on $a$: $a = 3 - \gcd(3,4) = 2$.
-   Perform an operation on $a$: $a = 2 - \gcd(2,4) = 0$.
-   Perform an operation on $b$: $b = 4 - \gcd(0,4) = 0$.


## Solution


import math

def solve(a, b):
    rounds = 0
    while a > 0 and b > 0:
        gcd = math.gcd(a, b)
        if a > b:
            a -= gcd
        else:
            b -= gcd
        rounds += 1
    if a > 0:
        rounds += a // math.gcd(a, b)
    elif b > 0:
        rounds += b // math.gcd(a, b)
    return rounds

t = int(input())
for _ in range(t):
    a, b = map(int, input().split())
    print(solve(a, b))



## CODE


import math

def solve(a, b):
    rounds = 0
    while a > 0 and b > 0:
        gcd = math.gcd(a, b)
        if a > b:
            a -= gcd
        else:
            b -= gcd
        rounds += 1
    if a > 0:
        rounds += a // math.gcd(a, b)
    elif b > 0:
        rounds += b // math.gcd(a, b)
    return rounds

t = int(input())
for _ in range(t):
    a, b = map(int, input().split())
    print(solve(a, b))


### Explanation
The code uses a greedy approach to solve the problem. It repeatedly calculates the GCD of the current values of `a` and `b` and subtracts it from the larger value until one of them becomes zero. Then, it calculates the remaining rounds needed to make the other value zero by dividing it by the GCD. This approach ensures the minimum number of rounds needed to make both `a` and `b` zero.
## Token
[235, 553, 788]
 ### 

## Question


(H)
Hana recently needs to develop a radar system to monitor abnormal activities across the archipelago she manages.
There are $n$ islands in the ocean, and the $i$\-th island is located at coordinates $(x_i, y_i)$, which can be treated as a point on the plane. Assume the radar has a scanning angle range of $\alpha$. When the radar is rotated to an angle $\theta$, it can monitor all the islands located within the angular range $[\theta - \frac{\alpha}{2}, \theta + \frac{\alpha}{2}]$.
Hana is currently low on funds, so she wants to minimize the cost of building the radar. She wants to know, when the radar is placed at the origin $(0,0)$, what the minimum scanning angle $\alpha$ should be to ensure that for any angle $\theta$, the radar can monitor at least $k$ islands.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of each test case follows.
The first line of each test case contains two integers $n$ and $k$ ($1 \leq k \leq n \leq 2 \times 10^5$), representing the total number of islands and the minimum number of islands the radar must monitor at any given time.
The next $n$ lines each contain two integers $x_i$ and $y_i$ ($|x_i|, |y_i| \leq 10^9$), representing the position of an island. It is guaranteed that the coordinates of any two islands are different and none of them are located at the origin.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $2 \times 10^5$.

**Output**
For each test case, output a single decimal fraction representing the minimum radar scanning angle in radians.
Your answer is considered correct if its absolute or relative error does not exceed $10^{-6}$.
Formally, let your answer be $a$, and the jury's answer be $b$. Your answer is accepted if and only if $\frac{|a - b|}{\max{(1, |b|)}} \leq 10^{-6}$.

Example Input1：
1 1
0 1
Example Output1：
6.2831853072
Example Input2：
8 2
1 0
1 1
0 1
-1 1
-1 0
-1 -1
0 -1
1 -1
Example Output2：
1.5707963268
Example Input3：
4 2
-1 1
0 1
0 2
1 1
Example Output3：
5.4977871438

**Note**
For the first test case in the example, there is only one island on the plane at $(0,1)$. To ensure that at least one island is always within range, the radar's monitoring range must be set to $360^{\circ}$, which is $2 \pi$ in radians.
For the second test case in the example, there are $8$ islands on the plane, with each pair of islands separated by $45^{\circ}$. If the radar's range is less than $90^{\circ}$, it would only be able to monitor one island when one of its boundaries just moves past an island (as shown on the left of the illustration). Therefore, the minimum radar range needed is $90^{\circ}$, ensuring that at least two islands are always within range.


## Solution


import math

def calculate_angle(x, y):
    return math.atan2(y, x)

def calculate_distance(angle1, angle2):
    return min(abs(angle1 - angle2), 2 * math.pi - abs(angle1 - angle2))

def solve():
    n, k = map(int, input().split())
    angles = []
    for _ in range(n):
        x, y = map(int, input().split())
        angles.append(calculate_angle(x, y))
    angles.sort()
    max_distance = 0
    for i in range(n - k + 1):
        max_distance = max(max_distance, calculate_distance(angles[i + k - 1], angles[i]))
    print(max_distance)

t = int(input())
for _ in range(t):
    solve()



## CODE


import math

def calculate_angle(x, y):
    return math.atan2(y, x)

def calculate_distance(angle1, angle2):
    return min(abs(angle1 - angle2), 2 * math.pi - abs(angle1 - angle2))

def solve():
    n, k = map(int, input().split())
    angles = []
    for _ in range(n):
        x, y = map(int, input().split())
        angles.append(calculate_angle(x, y))
    angles.sort()
    max_distance = 0
    for i in range(n - k + 1):
        max_distance = max(max_distance, calculate_distance(angles[i + k - 1], angles[i]))
    print(max_distance)

t = int(input())
for _ in range(t):
    solve()


### Explanation
The problem is solved by first calculating the angles of all the islands with respect to the origin. The angles are then sorted in ascending order. We then use a sliding window approach to find the maximum distance between two islands that are k islands apart. This maximum distance is the minimum scanning angle required to ensure that at least k islands are always within range. The distance between two angles is calculated as the minimum of the absolute difference between the two angles and 2π minus the absolute difference between the two angles. This is to handle the case where the two angles are on opposite sides of the origin.
## Token
[295, 869, 1164]
 ### 

## Question


(J)
Jessica is a master of sorting algorithms, proficient in selection sort, insertion sort, bubble sort, and many others. Therefore, she decided to host a sorting competition.
The competition takes place on a permutation$^{\dagger}$ $p$ of length $n$, with two participants: Alice and Bob. The two players take turns performing operations, with the first player being decided by a coin toss. If the sequence is in ascending order after **any** player's turn, Alice wins immediately. If Alice cannot win within a finite number of turns, Bob is considered the winner.
On Alice's turn, she can choose any two positions $i,j$ ($i \neq j, 1 \leq i,j \leq n$) in the permutation and swap $p_i$ and $p_j$. On Bob's turn, he can select two adjacent positions $i,i+1$ ($1 \leq i &lt; n$) and swap $p_i$ and $p_{i+1}$. Neither player is allowed to skip their turn.
Given the permutation $p$ and the name of the player who operates first, determine who will win the game if both players play optimally.
$^{\dagger}$ A permutation of length $n$ is an array consisting of $n$ distinct integers from $1$ to $n$ in arbitrary order. For example, $[2,3,1,5,4]$ is a permutation, but $[1,2,2]$ is not a permutation ($2$ appears twice in the array), and $[1,3,4]$ is also not a permutation ($n=3$ but there is a $4$ in the array).

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line of each test case contains an integer $n$ ($2 \leq n \leq 10^5$) and a string $s$ ($s \in \{$Alice, Bob$\}$), representing the length of the permutation and the name of the player who operates first.
The second line contains $n$ integers $p_1, p_2, \cdots, p_n$ ($1 \leq p_i \leq n$), representing the permutation $p$. It is guaranteed that there is at least one position $i$ such that $p_i \neq i$.
For each test file, it is guaranteed that the sum of all $n$ over all test cases does not exceed $10^5$.

**Output**
For each test case, output one line containing the winner's name. If Alice wins, print "Alice"; otherwise, print "Bob".

Example Input1：
2 Alice
2 1
Example Output1：
Alice
Example Input2：
3 Bob
1 3 2
Example Output2：
Bob
Example Input3：
10 Bob
1 2 3 4 5 6 7 8 10 9
Example Output3：
Bob


## Solution


def is_sorted(p):
    return all(p[i] == i + 1 for i in range(len(p)))

def solve(n, s, p):
    if s == 'Alice':
        if not is_sorted(p):
            print('Alice')
        else:
            print('Bob')
    else:
        inversions = sum(1 for i in range(n) for j in range(i + 1, n) if p[i] > p[j])
        if inversions % 2 == 0:
            print('Bob')
        else:
            print('Alice')

t = int(input())
for _ in range(t):
    n, s = input().split()
    n = int(n)
    p = list(map(int, input().split()))
    solve(n, s, p)



## CODE


def is_sorted(p):
    return all(p[i] == i + 1 for i in range(len(p)))

def solve(n, s, p):
    if s == 'Alice':
        if not is_sorted(p):
            print('Alice')
        else:
            print('Bob')
    else:
        inversions = sum(1 for i in range(n) for j in range(i + 1, n) if p[i] > p[j])
        if inversions % 2 == 0:
            print('Bob')
        else:
            print('Alice')

t = int(input())
for _ in range(t):
    n, s = input().split()
    n = int(n)
    p = list(map(int, input().split()))
    solve(n, s, p)


### Explanation
The solution first checks if the input permutation is sorted. If it is and Alice starts, Bob wins. If it is not sorted, Alice can always win by swapping the elements that are not in their correct positions.

If Bob starts, the solution counts the number of inversions in the permutation. An inversion is a pair of elements that are in the wrong order. If the number of inversions is even, Bob can always win by swapping adjacent elements to reduce the number of inversions to 0. If the number of inversions is odd, Alice can always win by swapping two elements to make the number of inversions even, and then Bob will lose.
## Token
[308, 757, 1065]
 ### 

## Question


(L)
Fried-chicken is a devoted player of Hearthstone. Since the game resumed operations in the Chinese mainland, he has been obsessed with it and reached Silver 2 rank in Standard mode. Today, while ranking up using Death Knight, he encountered a formidable opponent, Stewed-chicken, and was left with just $1$ Health. To survive, Fried-chicken must eliminate all of Stewed-chicken's minions. Fortunately, he can use spell cards and his minions' attacks to achieve this goal.
Specifically, this game involves two factions: Fried-chicken and Stewed-chicken. Each faction has some minions. The $i$\-th minion has $h_i$ Health. It is now Fried-chicken's turn, and each of his minions can attack any one minion from the **opposing faction** at most once. When one minion attacks another, both minions lose $1$ Health. If a minion's Health is reduced to $0$ or less, it dies and can no longer attack or be attacked.
![](https://espresso.codeforces.com/b450c1ac41bc76df32eedfb9108bf1d073892a16.png)
To achieve his goal, Fried-chicken casts the spell "Threads of Despair," causing every minion to explode upon death, which reduces the Health of **all** minions by $1$. If the explosion causes the death of other minions, other minions will also explode immediately. Fried-chicken cannot have his minions attack other minions until all explosion effects have finished. After casting the spell, Fried-chicken can make his minions attack Stewed-chicken's minions in any order he chooses. He wants to know if there exists an attack order that allows Fried-chicken to eliminate all of Stewed-chicken's minions.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 5 \times 10^5$). The description of the test cases follows.
The first line of each test case contains two integers $n$ and $m$ ($1 \leq n, m \leq 5 \times 10^5$), representing the number of Fried-chicken's minions and Stewed-chicken's minions, respectively.
The second line contains $n$ integers $h_1, h_2, \dots, h_n$ ($1 \leq h_i \leq 10^9$), where $h_i$ represents the Health of Fried-chicken's $i$\-th minion.
The third line contains $m$ integers $h'_1, h'_2, \dots, h'_m$ ($1 \leq h'_i \leq 10^9$), where $h'_i$ represents the Health of Stewed-chicken's $i$\-th minion.
For each test file, it is guaranteed that the sum of all $n$ across all test cases does not exceed $5 \times 10^5$, and the sum of all $m$ across all test cases does not exceed $5 \times 10^5$.

**Output**
For each test case, output "Yes" if Fried-chicken can eliminate all of Stewed-chicken's minions; otherwise, output "No".
You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.

Example Input1：
3 2
1 1 4
2 6
Example Output1：
Yes
Example Input2：
3 2
1 1 4
2 7
Example Output2：
No
Example Input3：
2 1
100 100
2
Example Output3：
No

**Note**
In the first test case of Sample 1, one possible sequence of actions is as follows: Fried-chicken's $3$rd minion attacks Stewed-chicken's $2$nd minion, followed by Fried-chicken's $2$nd minion attacking Stewed-chicken's $2$nd minion. At this point, Fried-chicken's $2$nd minion dies, triggering an explosion. This explosion causes further deaths, leading to a chain reaction of explosions. Eventually, all minions are eliminated.
In the third test case of Sample 1, one possible sequence of actions is as follows: Fried-chicken's $1$st minion attacks Stewed-chicken's $1$st minion, followed by Fried-chicken's $2$nd minion attacking Stewed-chicken's $1$st minion. At this point, Stewed-chicken's $1$st minion dies, triggering an explosion. Ultimately, Fried-chicken is left with two minions, each having $98$ Health, while all of Stewed-chicken's minions are eliminated. Fried-chicken survives successfully.


## Solution


import sys

def solve():
    n, m = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))
    b = list(map(int, sys.stdin.readline().split()))
    a.sort()
    b.sort()

    j = 0
    for i in range(n):
        while j < m and b[j] <= a[i]:
            j += 1
        if j == m:
            print("Yes")
            return
        if b[j] > a[i] + 1:
            print("No")
            return
        j += 1

    if j == m:
        print("Yes")
    else:
        print("No")

t = int(sys.stdin.readline())
for _ in range(t):
    solve()



## CODE


import sys

def solve():
    n, m = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))
    b = list(map(int, sys.stdin.readline().split()))
    a.sort()
    b.sort()

    j = 0
    for i in range(n):
        while j < m and b[j] <= a[i]:
            j += 1
        if j == m:
            print("Yes")
            return
        if b[j] > a[i] + 1:
            print("No")
            return
        j += 1

    if j == m:
        print("Yes")
    else:
        print("No")

t = int(sys.stdin.readline())
for _ in range(t):
    solve()


### Explanation
We sort both arrays of Fried-chicken's minions and Stewed-chicken's minions in ascending order. Then we iterate through Fried-chicken's minions and try to find a corresponding minion from Stewed-chicken's minions that can be eliminated. If we find a minion from Stewed-chicken's minions that has a health greater than the current minion from Fried-chicken's minions plus one, we immediately print "No" because it's impossible to eliminate this minion. If we successfully iterate through all minions from Fried-chicken and eliminate all minions from Stewed-chicken, we print "Yes". Otherwise, we print "No". This solution works in O(n log n) time due to the sorting operation.
## Token
[318, 1114, 1432]
 ### 

## Question


(M)
Mary loves constructing matrices!
Today, Mary wants to fill a permutation$^{\dagger}$ of length $n \times m$ into an $n \times m$ matrix $A$, such that the sum of any two adjacent elements is unique.
In other words, for any $1 \leq x_1,x_2,x_3,x_4 \leq n, 1 \leq y_1,y_2,y_3,y_4 \leq m$, if all of the following conditions are satisfied:
-   $x_2 \geq x_1, y_2 \geq y_1, x_4 \geq x_3, y_4 \geq y_3$;
-   $|x_2-x_1|+|y_2-y_1|=1, |x_4-x_3|+|y_4-y_3|=1$;
-   $(x_1,y_1) \neq (x_3,y_3)$ or $(x_2,y_2) \neq (x_4,y_4)$;
then:
$$
A_{x_1,y_1}+A_{x_2,y_2} \neq A_{x_3,y_3}+A_{x_4,y_4}
$$
For example, when $n=2$ and $m=3$, matrix $B$ is a valid solution, while matrix $C$ is not valid because $C_{1,1}+C_{2,1}=C_{1,2}+C_{1,3}$.
$$
B = \begin{bmatrix} 1 & 3 & 2 \\ 6 & 5 & 4 \end{bmatrix}, \quad C = \begin{bmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \end{bmatrix}
$$
Given $n$ and $m$, can all the conditions above be satisfied? If so, output a valid solution.
$^{\dagger}$ A permutation of length $n$ is an array consisting of $n$ distinct integers from $1$ to $n$ in arbitrary order. For example, $[2,3,1,5,4]$ is a permutation, but $[1,2,2]$ is not a permutation ($2$ appears twice in the array), and $[1,3,4]$ is also not a permutation ($n=3$ but there is a $4$ in the array).

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line contains two integers $n,m$ ($1 \leq n,m \leq 1000$).
For each test file, it is guaranteed that the sum of $n \times m$ over all test cases does not exceed $10^6$.

**Output**
For each test case, output on the first line whether a valid solution exists. If there is a valid solution, output "Yes"; otherwise, output "No". You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.
If a valid solution exists, you must also output $n$ lines, each containing $m$ integers. The $j$\-th number on the $i$\-th line represents the number at row $i$ and column $j$ in the matrix. You must make sure that the output numbers form a permutation of length $n \times m$. If there are multiple solutions, you may print any of them.

Example Input1：
1 1
Example Output1：
yEs
1
Example Input2：
2 3
Example Output2：
YES
1 3 2
6 5 4
## Solution


def solve(n, m):
    if n == 1 and m == 1:
        print("Yes")
        print(1)
        return
    if n == 1:
        print("No")
        return
    print("Yes")
    for i in range(1, n + 1):
        row = []
        for j in range(1, m + 1):
            if i % 2 == 1:
                row.append((i - 1) * m + j)
            else:
                row.append((i - 1) * m + m - j + 1)
        print(*row)

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    solve(n, m)



## CODE


def solve(n, m):
    if n == 1 and m == 1:
        print("Yes")
        print(1)
        return
    if n == 1:
        print("No")
        return
    print("Yes")
    for i in range(1, n + 1):
        row = []
        for j in range(1, m + 1):
            if i % 2 == 1:
                row.append((i - 1) * m + j)
            else:
                row.append((i - 1) * m + m - j + 1)
        print(*row)

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    solve(n, m)


### Explanation
This problem can be solved by filling the matrix in a specific pattern. If we fill the matrix row by row, alternating between ascending and descending order, we can ensure that the sum of any two adjacent elements is unique.

For example, for a 2x3 matrix, we can fill it as follows:

1 3 2
6 5 4

This pattern can be generalized to any nxm matrix. If n is odd, we fill the rows in ascending order. If n is even, we fill the rows in descending order.

The code implements this pattern by iterating over each row and column of the matrix. If the row index is odd, it fills the row in ascending order. If the row index is even, it fills the row in descending order. The result is a matrix that satisfies the conditions of the problem.
## Token
[348, 946, 1294]
 ### 

