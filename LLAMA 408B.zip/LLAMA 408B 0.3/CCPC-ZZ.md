## Question
(A)
Given three positive integers $p_A,p_B,p_C$, Bobo challenges you to find out three infinite binary strings $A,B,C$ with period $p_A$, $p_B$ and $p_C$ respectively satisfying $A \oplus B = C$, or determine it is impossible to do so.
Please refer to the Note section for the formal definition of period and exclusive or.
**Input**
The first line of the input contains a single integer $T$ ($1 \le T \le 10^4$), denoting the number of test cases. The description of the test cases follows.
The first and the only line of each test case contains three integers $p_A$, $p_B$ and $p_C$ ($1 \le p_A,p_B,p_C \le 10^6$).
It is guaranteed that the sum of $\max(p_A,p_B,p_C)$ over all test cases does not exceed $10^6$.
**Output**
For each test case, output "NO" (without quotes) in one line if no solution exists. Otherwise, output "YES" (without quotes) in one line. Then, output three binary strings of length $p_A$, $p_B$ and $p_C$ in three lines, denoting the first $p_A$, $p_B$, $p_C$ character(s) of the infinite strings $A$, $B$, $C$ respectively.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input：
2 3 6
2 3 5
Example Output：
YES
01
011
001110
NO
**Note**
Let $s=s_1 s_2 s_3 \ldots$ and $t=t_1 t_2 t_3 \ldots$ be infinite binary strings.
The period of $s$ is the smallest positive integer $k$ satisfying $s_i = s_{i+k}$ for all $i \ge 1$.
The exclusive or of strings $s$ and $t$ is given by $s \oplus t$ satisfying $(s \oplus t)_i = s_i \oplus t_i$ for all $i \ge 1$.


## Solution


import math

def find_strings(pa, pb, pc):
    lcm_ab = pa * pb // math.gcd(pa, pb)
    if pc != lcm_ab:
        if lcm_ab % pc == 0:
            return "NO"
        lcm_abc = lcm_ab * pc // math.gcd(lcm_ab, pc)
        a = [0] * lcm_abc
        b = [0] * lcm_abc
        c = [0] * lcm_abc
        for i in range(lcm_abc):
            if i % pa < pa // 2:
                a[i] = 1
            if i % pb < pb // 2:
                b[i] = 1
            c[i] = a[i] ^ b[i]
        ca = a[:pa]
        cb = b[:pb]
        cc = c[:pc]
        return "YES\n" + "".join(map(str, ca)) + "\n" + "".join(map(str, cb)) + "\n" + "".join(map(str, cc))
    else:
        a = [0] * pa
        b = [0] * pb
        c = [0] * pc
        for i in range(pa):
            if i < pa // 2:
                a[i] = 1
        for i in range(pb):
            if i < pb // 2:
                b[i] = 1
        for i in range(pc):
            c[i] = a[i % pa] ^ b[i % pb]
        return "YES\n" + "".join(map(str, a)) + "\n" + "".join(map(str, b)) + "\n" + "".join(map(str, c))

t = int(input())
for _ in range(t):
    pa, pb, pc = map(int, input().split())
    print(find_strings(pa, pb, pc))



## CODE


import math

def find_strings(pa, pb, pc):
    lcm_ab = pa * pb // math.gcd(pa, pb)
    if pc != lcm_ab:
        if lcm_ab % pc == 0:
            return "NO"
        lcm_abc = lcm_ab * pc // math.gcd(lcm_ab, pc)
        a = [0] * lcm_abc
        b = [0] * lcm_abc
        c = [0] * lcm_abc
        for i in range(lcm_abc):
            if i % pa < pa // 2:
                a[i] = 1
            if i % pb < pb // 2:
                b[i] = 1
            c[i] = a[i] ^ b[i]
        ca = a[:pa]
        cb = b[:pb]
        cc = c[:pc]
        return "YES\n" + "".join(map(str, ca)) + "\n" + "".join(map(str, cb)) + "\n" + "".join(map(str, cc))
    else:
        a = [0] * pa
        b = [0] * pb
        c = [0] * pc
        for i in range(pa):
            if i < pa // 2:
                a[i] = 1
        for i in range(pb):
            if i < pb // 2:
                b[i] = 1
        for i in range(pc):
            c[i] = a[i % pa] ^ b[i % pb]
        return "YES\n" + "".join(map(str, a)) + "\n" + "".join(map(str, b)) + "\n" + "".join(map(str, c))

t = int(input())
for _ in range(t):
    pa, pb, pc = map(int, input().split())
    print(find_strings(pa, pb, pc))


### Explanation
This solution first checks if the period of C is equal to the least common multiple (LCM) of the periods of A and B. If not, it checks if the LCM of A and B is a multiple of the period of C. If so, it returns "NO" because it's impossible to find a solution. Otherwise, it constructs the binary strings A, B, and C by setting the first half of each string to 1 and the rest to 0, and then computes the XOR of A and B to get C. If the period of C is equal to the LCM of A and B, it directly constructs A, B, and C by setting the first half of each string to 1 and the rest to 0, and then computes the XOR of A and B to get C.
## Token
[574, 578, 1152]
 ### 

## Question


(B)
Bobo has been playing a puzzle called Rolling Stones, which takes place on an equilateral triangular board consisting of $n$ $(n\geq 2)$ rows and $n^2$ cells. Each cell on the board is labeled with a number from $1$ to $4$. Bobo also has a tetrahedral stone, with each face numbered from $1$ to $4$ (a tetrahedral dice), initially placed at the first cell in the first row of the board. The position of the stone is as follows: the face with the number $1$ is towards the left, the face with the number $2$ is towards the next row, the face with the number $3$ is towards the right, and the face with the number $4$ is on the bottom side.
The goal of the puzzle is to roll the stone to a target cell under the following rules:

- **Matching Numbers**: When the stone rests on a cell, the number on the cell must match the number on the stone's bottom face.
- **Single Visit**: Each cell can only be visited once throughout the journey, including the starting and target cells.
The stone rolls by tipping along an edge that touches the board, moving it to a neighboring cell. Given the board layout, the target cell, and the stone's initial orientation, Bobo wants to know: is it possible to reach the target cell following the rules? If possible, what is the minimum number of rolls required to reach the target?
The illustration for a solution of the first sample test is given as follows.
![]
**Input**
The first line contains an integer $n$ $(2\leq n\leq 100)$, denoting the size of the board.
Then $n$ lines follows, with the $i$\-th $(1\leq i\leq n)$ line containing $2i-1$ numbers $a_{i,1},a_{i,2},\dots,a_{i,2i-1}$, where each $1\leq a_{i,j}\leq 4$ indicates the number on the $j$\-th cell from left to right in the $i$\-th row. It is guaranteed that $a_{1,1}=4$.
Then another line follows, containing two integers $x,y$ $(2\leq x\leq n,1\leq y\leq 2x-1)$. Here, $(x,y)$ represents the target cell, located at the $y$\-th cell from left to right in the $x$\-th row.
**Output**
If there is no way to roll the stone to the target cell, output $-1$ in a line. Otherwise, output the minimum number of rolls to roll the stone to the target cell in a line.
Example Input：
3
4
3 2 3
4 3 2 1 3
3 1
Example Output：
6


## Solution


from collections import deque

def rolling_stones(n, board, target):
    directions = [(0, -1), (-1, 0), (0, 1), (1, 0)]
    visited = set((0, 0, 3))
    queue = deque([(0, 0, 3, 0)])

    while queue:
        x, y, face, steps = queue.popleft()
        if (x, y) == target:
            return steps

        for i, (dx, dy) in enumerate(directions):
            nx, ny = x + dx, y + dy
            if nx < 0 or ny < 0 or nx >= n or ny >= 2 * nx + 1:
                continue
            if board[nx][ny] == (face + 1) % 4 + 1 and (nx, ny, (face + 1) % 4) not in visited:
                visited.add((nx, ny, (face + 1) % 4))
                queue.append((nx, ny, (face + 1) % 4, steps + 1))
            if board[nx][ny] == (face - 1) % 4 + 1 and (nx, ny, (face - 1) % 4) not in visited:
                visited.add((nx, ny, (face - 1) % 4))
                queue.append((nx, ny, (face - 1) % 4, steps + 1))

    return -1

n = int(input())
board = [list(map(int, input().split())) for _ in range(n)]
target = tuple(map(lambda x: int(x) - 1, input().split()))
print(rolling_stones(n, board, target))



## CODE


from collections import deque

def rolling_stones(n, board, target):
    directions = [(0, -1), (-1, 0), (0, 1), (1, 0)]
    visited = set((0, 0, 3))
    queue = deque([(0, 0, 3, 0)])

    while queue:
        x, y, face, steps = queue.popleft()
        if (x, y) == target:
            return steps

        for i, (dx, dy) in enumerate(directions):
            nx, ny = x + dx, y + dy
            if nx < 0 or ny < 0 or nx >= n or ny >= 2 * nx + 1:
                continue
            if board[nx][ny] == (face + 1) % 4 + 1 and (nx, ny, (face + 1) % 4) not in visited:
                visited.add((nx, ny, (face + 1) % 4))
                queue.append((nx, ny, (face + 1) % 4, steps + 1))
            if board[nx][ny] == (face - 1) % 4 + 1 and (nx, ny, (face - 1) % 4) not in visited:
                visited.add((nx, ny, (face - 1) % 4))
                queue.append((nx, ny, (face - 1) % 4, steps + 1))

    return -1

n = int(input())
board = [list(map(int, input().split())) for _ in range(n)]
target = tuple(map(lambda x: int(x) - 1, input().split()))
print(rolling_stones(n, board, target))


### Explanation
The problem is solved using a breadth-first search (BFS) algorithm. The BFS algorithm is suitable for finding the shortest path in an unweighted graph. In this problem, the graph is represented by the triangular board, and the edges are the possible rolls of the stone.

The algorithm starts from the initial position of the stone and explores all possible rolls. For each roll, it checks if the target cell is reached. If not, it adds the new position to the queue and marks it as visited.

The algorithm uses a queue to keep track of the positions to be explored. Each position is represented by the coordinates (x, y) and the face of the stone. The face is used to determine the possible rolls.

The algorithm also uses a set to keep track of the visited positions. This is to avoid exploring the same position multiple times.

The algorithm returns the minimum number of rolls required to reach the target cell. If the target cell is not reachable, it returns -1.
## Token
[589, 714, 1303]
 ### 

## Question


(C)
Bobo is exploring a set of lattice points on a two-dimensional plane. Initially, the set of points is defined as $S = \{(0,0),(A,0),(0,B),(A,B)\}$. Bobo's goal is to include a specific lattice point $(X,Y)$ in $S$. To achieve the goal, Bobo may perform the following operation:
- Select two lattice points $P,Q \in S$ such that $\frac{P+Q}{2}$ is also a lattice point, and add $\frac{P+Q}{2}$ to $S$.
Your task is to help Bobo find a sequence of operations that minimizes the number of steps to achieve the goal or determine if it is impossible to do so.
**Input**
The first line of the input contains two integers $A$ and $B$ ($0 \le A,B \le 10^9$), describing the parameters of the initial lattice points.
The second line of the input contains two integers $X$ and $Y$ ($0 \le X \le A$, $0 \le Y \le B$), denoting the coordinates of the target lattice point.
**Output**
If it is impossible to achieve the goal, output $-1$ in one line. Otherwise, output a single integer $k$ ($0 \le k \le 10^5$) in one line, denoting the total number of operations to perform. Then $k$ lines follow. The $i$\-th line contains four integers $U_i,V_i,S_i,T_i$ ($0 \le U_i,V_i,S_i,T_i \le 10^9$), describing the lattice points $P=(U_i,V_i)$ and $Q=(S_i,T_i)$ chosen in the $i$\-th operation. If there exist multiple solutions, output any.
Example Input1：
2 2
1 1
Example Output1：
1
0 0 2 2
Example Input2：
8 8
5 0
Example Output2：
3
0 0 8 0
4 0 8 0
4 0 6 0
Example Input3：
8 6
7 3
Example Output3：
3
0 0 8 0
4 0 8 0
6 0 8 6


## Solution


import sys

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def solve():
    A, B = map(int, input().split())
    X, Y = map(int, input().split())
    if (X * B - Y * A) % gcd(A, B) != 0:
        print(-1)
        return
    if (A & X) != X or (B & Y) != Y:
        print(-1)
        return
    ans = []
    def add(x1, y1, x2, y2):
        ans.append((x1, y1, x2, y2))
    def work(x, y):
        if x == 0 or y == 0:
            return
        if x == y:
            add(0, 0, x * 2, y * 2)
            work(x, y - y)
            return
        if x > y:
            add(0, 0, x * 2, 0)
            work(x - y, y)
            work(x - (x - y), y)
        else:
            add(0, 0, 0, y * 2)
            work(x, y - x)
            work(x, y - (y - x))
    work(X, Y)
    print(len(ans))
    for x1, y1, x2, y2 in ans:
        print(x1, y1, x2, y2)

if __name__ == "__main__":
    solve()



## CODE


import sys

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def solve():
    A, B = map(int, input().split())
    X, Y = map(int, input().split())
    if (X * B - Y * A) % gcd(A, B) != 0:
        print(-1)
        return
    if (A & X) != X or (B & Y) != Y:
        print(-1)
        return
    ans = []
    def add(x1, y1, x2, y2):
        ans.append((x1, y1, x2, y2))
    def work(x, y):
        if x == 0 or y == 0:
            return
        if x == y:
            add(0, 0, x * 2, y * 2)
            work(x, y - y)
            return
        if x > y:
            add(0, 0, x * 2, 0)
            work(x - y, y)
            work(x - (x - y), y)
        else:
            add(0, 0, 0, y * 2)
            work(x, y - x)
            work(x, y - (y - x))
    work(X, Y)
    print(len(ans))
    for x1, y1, x2, y2 in ans:
        print(x1, y1, x2, y2)

if __name__ == "__main__":
    solve()


### Explanation
The problem is solved by using a greedy algorithm. The main idea is to first check if the target point can be reached by checking if the difference between the x-coordinates and y-coordinates of the target point and the initial points is a multiple of the greatest common divisor of A and B. If not, the target point cannot be reached. Then, we use a recursive function to find the sequence of operations to reach the target point. The function `work(x, y)` is used to find the sequence of operations to reach the point (x, y) from the initial points. If x or y is 0, we can directly reach the point. If x is equal to y, we can reach the point by adding the midpoint of (0, 0) and (x*2, y*2). If x is greater than y, we can reach the point by adding the midpoint of (0, 0) and (x*2, 0), and then recursively find the sequence of operations to reach the point (x-y, y). If x is less than y, we can reach the point by adding the midpoint of (0, 0) and (0, y*2), and then recursively find the sequence of operations to reach the point (x, y-x). The sequence of operations is stored in the list `ans` and then printed out.
## Token
[629, 593, 1222]
 ### 

## Question


(F)
Bobo is trapped in an infinite time loop of a peculiar day! Each day consists of exactly $k$ hours, and every day, $n$ tasks arrive for Bobo to complete.
- The $i$\-th task of the day arrives at the beginning of the $a_i$\-th hour and requires $b_i$ hours of uninterrupted effort to finish.
- Bobo works diligently and always follows a disciplined approach: whenever there are unfinished tasks, 、textbf{Bobo works on the earliest received unfinished task}.
At the beginning of the first day, Bobo starts with no tasks.
Your mission is to help Bobo answer $q$ queries. For the $i$\-th query, you are given $x_i$, the day on which a task is received, and $y_i$, the index of the task received on that day. Your goal is to determine the exact day and hour when Bobo will complete the $y_i$\-th taskof day $x_i$.
**Input**
The first line contains three space-separated integers, which are $n$ ($1 \leq n \leq 10^5$), $k$ ($1 \leq k \leq 10^8$), and $q$ ($1 \leq q \leq 10^5$), respectively.
The next $n$ lines each contain two space-separated integers, where the $i$\-th line contains $a_i$ ($1 \leq a_i \leq k$) and $b_i$ ($1 \leq b_i \leq k$). It is guaranteed that $a_i$ is strictly monotonically increasing.
Then $q$ lines follow, each containing two space-separated integers, where the $i$\-th line contains $x_i$ ($1 \leq x_i \leq 5 \times 10^5$) and $y_i$ ($1 \leq y_i \leq n$).
**Output**
Output $q$ lines, where the $i$\-th line outputs two space-separated integers $d_i$ and $h_i$, indicating that the task for the $i$\-th query is completed at the $h_i$\-th hour on the $d_i$\-th day.
Example Input1:
2 5 6
1 1
4 3
1 1
1 2
2 1
2 2
3 1
3 2
Example Output1:
1 1
2 1
2 2
3 1
3 2
4 1
Example Input2:
3 10 5
2 4
3 1
10 7
2 2
7 1
4 3
5 2
28 3
Example Output2:
3 1
8 10
6 2
6 7
34 10


## Solution


import sys
import bisect
input = sys.stdin.readline

def solve():
    n, k, q = map(int, input().split())
    tasks = []
    for _ in range(n):
        a, b = map(int, input().split())
        tasks.append((a, b))

    queries = []
    for i in range(q):
        x, y = map(int, input().split())
        queries.append((x, y, i))

    queries.sort()

    ans = [0] * q
    cur_day = 0
    cur_hour = 0
    task_idx = 0
    task_time = 0

    for x, y, idx in queries:
        while cur_day < x or task_idx < y:
            if task_idx < n and (cur_day == x or cur_hour < tasks[task_idx][0]):
                if cur_day < x:
                    cur_day = x
                    cur_hour = 0
                if cur_hour < tasks[task_idx][0]:
                    cur_hour = tasks[task_idx][0]
                task_time = tasks[task_idx][1]
                task_idx += 1
            else:
                if task_time > k - cur_hour:
                    task_time -= k - cur_hour
                    cur_day += 1
                    cur_hour = 0
                else:
                    cur_hour += task_time
                    task_time = 0

        if task_time > 0:
            if task_time > k - cur_hour:
                task_time -= k - cur_hour
                cur_day += 1
                cur_hour = 0
            else:
                cur_hour += task_time
                task_time = 0
        ans[idx] = (cur_day, cur_hour)

    for day, hour in ans:
        print(day, hour)

solve()



## CODE


import sys
import bisect
input = sys.stdin.readline

def solve():
    n, k, q = map(int, input().split())
    tasks = []
    for _ in range(n):
        a, b = map(int, input().split())
        tasks.append((a, b))

    queries = []
    for i in range(q):
        x, y = map(int, input().split())
        queries.append((x, y, i))

    queries.sort()

    ans = [0] * q
    cur_day = 0
    cur_hour = 0
    task_idx = 0
    task_time = 0

    for x, y, idx in queries:
        while cur_day < x or task_idx < y:
            if task_idx < n and (cur_day == x or cur_hour < tasks[task_idx][0]):
                if cur_day < x:
                    cur_day = x
                    cur_hour = 0
                if cur_hour < tasks[task_idx][0]:
                    cur_hour = tasks[task_idx][0]
                task_time = tasks[task_idx][1]
                task_idx += 1
            else:
                if task_time > k - cur_hour:
                    task_time -= k - cur_hour
                    cur_day += 1
                    cur_hour = 0
                else:
                    cur_hour += task_time
                    task_time = 0

        if task_time > 0:
            if task_time > k - cur_hour:
                task_time -= k - cur_hour
                cur_day += 1
                cur_hour = 0
            else:
                cur_hour += task_time
                task_time = 0
        ans[idx] = (cur_day, cur_hour)

    for day, hour in ans:
        print(day, hour)

solve()


### Explanation
This solution uses a simulation approach to solve the problem. It first reads the input and sorts the queries by day and task index. Then it iterates through the queries, simulating the work process of Bobo. It keeps track of the current day, hour, and task index, and updates them accordingly. When a query is encountered, it calculates the completion time of the task and stores it in the answer array. Finally, it prints the answers. The time complexity is O(n + q log q), where n is the number of tasks and q is the number of queries.
## Token
[510, 706, 1216]
 ### 

## Question


(G)
Bobo is working with an integer sequence $a_1,a_2,\ldots,a_n$ of length $n$. He must process $q$ queries in order. Each query is of one of the following two types:
- 1 $L$ $R$ $v$ ($1 \le L \le R \le n$, $0 \le v \le 2 \cdot 10^5$): for all $i \in [L,R]$, update $a_i \gets a_i + v$;
- 2 $L$ $R$ ($1 \le L &lt; R \le n$, $R-L+1$ is even): determine if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum.
Your task is to help Bobo process these queries efficiently.
**Input**
The first line of input contains two integers $n$, $q$ ($1 \le n,q \le 2 \cdot 10^5$).
The second line of input contains $n$ integers $a_1, a_2, \ldots, a_n$ ($0 \le a_i \le 2 \cdot 10^5$).
Then $q$ lines follow. Each of the following lines contains a query, described in the statement.
**Output**
For each query of the second type, output "YES" (without quotes) in one line if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum; otherwise, output "NO" (without quotes) in one line.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input:
8 4
1 2 3 4 5 6 7 8
2 1 8
1 1 4 4
2 1 6
2 1 8
Example Output:
YES
NO
YES 


## Solution


import sys
input = sys.stdin.readline

class BIT:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * (n + 1)

    def update(self, i, val):
        while i <= self.n:
            self.bit[i] += val
            i += i & -i

    def query(self, i):
        res = 0
        while i > 0:
            res += self.bit[i]
            i -= i & -i
        return res

    def range_query(self, l, r):
        return self.query(r) - self.query(l - 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    bit = BIT(n)
    bit2 = BIT(n)
    for i in range(n):
        bit.update(i + 1, a[i])
        bit2.update(i + 1, a[i] * (i % 2 == 1 and -1 or 1))

    for _ in range(q):
        query = list(map(int, input().split()))
        if query[0] == 1:
            l, r, v = query[1:]
            bit.update(l, v)
            bit.update(r + 1, -v)
            bit2.update(l, v * (l % 2 == 1 and -1 or 1))
            bit2.update(r + 1, -v * (r % 2 == 1 and -1 or 1))
        else:
            l, r = query[1:]
            if bit.range_query(l, r) % 2 != 0:
                print("NO")
                continue
            if bit2.range_query(l, r) == 0:
                print("YES")
            else:
                print("NO")

solve()



## CODE


import sys
input = sys.stdin.readline

class BIT:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * (n + 1)

    def update(self, i, val):
        while i <= self.n:
            self.bit[i] += val
            i += i & -i

    def query(self, i):
        res = 0
        while i > 0:
            res += self.bit[i]
            i -= i & -i
        return res

    def range_query(self, l, r):
        return self.query(r) - self.query(l - 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    bit = BIT(n)
    bit2 = BIT(n)
    for i in range(n):
        bit.update(i + 1, a[i])
        bit2.update(i + 1, a[i] * (i % 2 == 1 and -1 or 1))

    for _ in range(q):
        query = list(map(int, input().split()))
        if query[0] == 1:
            l, r, v = query[1:]
            bit.update(l, v)
            bit.update(r + 1, -v)
            bit2.update(l, v * (l % 2 == 1 and -1 or 1))
            bit2.update(r + 1, -v * (r % 2 == 1 and -1 or 1))
        else:
            l, r = query[1:]
            if bit.range_query(l, r) % 2 != 0:
                print("NO")
                continue
            if bit2.range_query(l, r) == 0:
                print("YES")
            else:
                print("NO")

solve()


### Explanation
We use two Binary Indexed Trees (BITs) to keep track of the prefix sums and the alternating prefix sums of the array. The first BIT is used to check if the sum of the elements in the query range is even. The second BIT is used to check if the alternating sum of the elements in the query range is zero.

For each query of type 1, we update the corresponding ranges in both BITs.

For each query of type 2, we first check if the sum of the elements in the query range is even by querying the first BIT. If it's not even, we immediately print "NO". Otherwise, we query the second BIT to check if the alternating sum of the elements in the query range is zero. If it's zero, we print "YES"; otherwise, we print "NO".
## Token
[572, 556, 1128]
 ### 

## Question


(K)
Bobo is playing a game called **Brotato**. The game consists of $n$ levels, each of which he can either pass or fail. Each level has a probability $p$ of failure and a probability $1-p$ of passing. If Bobo fails a level, he must normally restart from the first level.

Bobo is quite frustrated about the fact that each time he dies, he has to start over from the very beginning. Therefore, Bobo decided to cheat. Now, Bobo has $k$ special items that allow him to continue from the same level after a failure rather than restarting from the beginning.

Given this setup, determine the minimum expected number of attempts for levels needed for Bobo to complete all $n$ levels.
**Input**

The first line contains two integers $n,k$ ($1 \le n\leq 10^5, 0 \le k\leq 10^9)$, denoting the number of levels and the number of items, respectively.

The second line contains a number $p$ $(0&lt;p\leq 0.5)$. It is guaranteed that $p$ has at most $4$ decimal places.

**It is guaranteed that $np\leq 20$.**
**Output**

Output a number in a line denoting the answer.

Your answer is considered correct if its absolute or relative error doesn't exceed $10^{-9}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $\frac{|b-a|}{\max(b,1)} \le 10^{-9}$.
Example Input1:
5 0
0.5
Example Output1:
62.0000000000
Example Input2:
5 1
0.5
Example Output2:
47.0000000000
Example Input3：
10000 0
0.002
Example Output3：
247489700298.2536834329
Example Input4：
100000 10
0.0002
Example Output4：
38767507133.2322179824


## Solution


import sys

def solve():
    n, k = map(int, sys.stdin.readline().split())
    p = float(sys.stdin.readline())

    dp = [0.0] * (n + 1)
    for i in range(1, n + 1):
        if i - 1 <= k:
            dp[i] = dp[i - 1] + 1 / (1 - p)
        else:
            dp[i] = dp[i - 1] + 1 / (1 - p) + p * dp[i - 1 - k]

    print(dp[n])

if __name__ == "__main__":
    solve()



## CODE


import sys

def solve():
    n, k = map(int, sys.stdin.readline().split())
    p = float(sys.stdin.readline())

    dp = [0.0] * (n + 1)
    for i in range(1, n + 1):
        if i - 1 <= k:
            dp[i] = dp[i - 1] + 1 / (1 - p)
        else:
            dp[i] = dp[i - 1] + 1 / (1 - p) + p * dp[i - 1 - k]

    print(dp[n])

if __name__ == "__main__":
    solve()


### Explanation
Dynamic Programming is used to solve this problem. The dp array stores the minimum expected number of attempts for levels needed to complete the first i levels. If the number of levels that can be continued from the same level after a failure is less than or equal to k, then the expected number of attempts for the current level is 1 / (1 - p). Otherwise, the expected number of attempts for the current level is 1 / (1 - p) + p * dp[i - 1 - k], where p * dp[i - 1 - k] represents the expected number of attempts for the levels that need to be restarted from the beginning after a failure.
## Token
[283, 538, 821]
 ### 

## Question


(L)
Welcome to the China Collegiate Programming Contest (CCPC) Zhengzhou onsite! Bobo has noticed that the initials of "Zheng" and "Zhou" are both Z. This motivates him to study the well-known Z-order curve.

To introduce the Z-order curve, we first introduce the Moser–de Bruijn sequence $(B_t)_{t \ge 0}$, the ordered sequence of numbers whose binary representation has nonzero digits only in the even positions. The first few terms of the Moser-de Bruijn sequence are $0, 1, 4, 5, 16, 17, 20, 21$.

Each non-negative integer $z$ can be uniquely decomposed into the sum of $B_x$ and $2B_y$. Therefore, we can write down all natural numbers in an infinitely large table. The Z-order curve is then obtained by connecting all the numbers in numerical order.

| ![](https://espresso.codeforces.com/3763e73d21e60b6c9037b14d5210dc6564fed8b9.png) |
| --- |
Illustration of Z-curve

Bobo now challenges you with the following problem: For a given fragment extracted from the Z-curve from $L$ to $R$, find the smallest integer $l$ such that the Z-curve from $l$ to $l+R-L$ is identical to the given fragment (i.e., the curve from $l$ to $l+R-L$ can be obtained by translating the curve from $L$ to $R$).

**Please note that in this problem, the curve is directed. Specifically, the curve from $1$ to $2$ is NOT identical to the curve from $3$ to $4$.**
**Input**

The first line of the input contains a single integer $T$ ($1 \le T \le 100$), denoting the number of test cases.

The first and only line of each test case contains two integers $L$ and $R$ ($0 \le L &lt; R \le 10^{18}$).
**Output**

For each test case, output the answer in one line.
Example Input1:
4
17 20
0 63
38 40
998244353998244353 998244853998244853
Example Output1:
1
0
6
2145186925057
**Note**

The following figure illustrates the Z-curve for the first and third test cases in the sample.

| ![](https://espresso.codeforces.com/709824a4ad98c5006c72824943a94018c45ea03d.png) |
| --- |
Illustration of test cases in the sample (red: test case 1, green: test case 3)


## Solution


def solve():
    l, r = map(int, input().split())
    x = r - l
    y = 1
    while y <= x:
        y *= 4
    ans = 0
    while y:
        if (l // y) % 4 == (r // y) % 4:
            ans += (l // y) % 4 * y
        else:
            ans += (r // y) % 4 * y
            if (r // y) % 4 == 0:
                ans -= y
        y //= 4
    print(ans)

t = int(input())
for _ in range(t):
    solve()



## CODE


def solve():
    l, r = map(int, input().split())
    x = r - l
    y = 1
    while y <= x:
        y *= 4
    ans = 0
    while y:
        if (l // y) % 4 == (r // y) % 4:
            ans += (l // y) % 4 * y
        else:
            ans += (r // y) % 4 * y
            if (r // y) % 4 == 0:
                ans -= y
        y //= 4
    print(ans)

t = int(input())
for _ in range(t):
    solve()


### Explanation
We can solve this problem by finding the smallest integer `l` such that the Z-curve from `l` to `l + R - L` is identical to the given fragment. We can do this by comparing the Z-curve from `L` to `R` and the Z-curve from `l` to `l + R - L` level by level from the highest level to the lowest level. At each level, we can determine the value of `l` at that level by comparing the values of `L` and `R` at that level. If `L` and `R` have the same value at that level, then `l` should have the same value as `L` at that level. Otherwise, `l` should have the same value as `R` at that level minus 1 if `R` has a value of 0 at that level. We can repeat this process until we have determined the value of `l` at all levels.
## Token
[360, 687, 1047]
 ### 

## Question


(M)
Bobo wants to use a rejection sampling algorithm to construct a random set $T\subset \{1,2,\dots,n\}$ of size $k$. For parameters $p_1,p_2,...,p_n$ $(0\leq p_i\leq 1)$ and integer $k$, the rejection sampler is defined as follows:

1. Initialize $T \gets \emptyset$;
2. For each $i$ $(1\leq i\leq n)$, add $i$ into $T$ with probability $p_i$;
3. Output $T$ if the size of $T$ is exactly $k$; otherwise, repeat the process.

Now you are given integers $a_1,a_2,...,a_n$ and $k$. Bobo needs to set the parameters $p_1,p_2,\ldots,p_n$ satisfying

- $\sum_{i=1}^n p_i=k$;
- for all $S\subseteq \{1,2,\cdots, n\}$ such that $|S|=k$, the probability that the rejection sampler outputs $S$ is proportional to $\prod_{i \in S} a_i$.

Your task is to find out the parameters $p_1,p_2,\dots,p_n$ for Bobo. It is guaranteed that such parameters exist and **are unique**. Your answer will be considered correct if the absolute error of each $p_i$ doesn't exceed $10^{-6}$ compared to the unique answer.
**Input**

The first line of the input contains two integers $n$ and $k$ ($2 \le n \le 10^5$, $1 \le k \le n-1$).

The second line of the input contains $n$ integers $a_1,a_2,\ldots,a_n$ ($1 \le a_i \le 10^9$).
**Output**

Output $n$ lines. The $i$\-th line contains a single real number $p_i$.

Your answer is considered correct if the absolute error of each parameter does not exceed $10^{-6}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $|b-a| \le 10^{-6}$ for all parameters.
Example Input1:
3 2
5 5 5
Example Output1:
0.666666666667
0.666666666667

0.666666666667 

## Solution


import sys

def main():
    n, k = map(int, input().split())
    a = list(map(int, input().split()))

    def check(x):
        p = [ai / (x + ai) for ai in a]
        return sum(p) - k

    l, r = 0, 10**16
    for _ in range(100):
        mid = (l + r) / 2
        if check(mid) > 0:
            l = mid
        else:
            r = mid

    p = [ai / (l + ai) for ai in a]
    for pi in p:
        print(pi)

if __name__ == "__main__":
    main()



## CODE


import sys

def main():
    n, k = map(int, input().split())
    a = list(map(int, input().split()))

    def check(x):
        p = [ai / (x + ai) for ai in a]
        return sum(p) - k

    l, r = 0, 10**16
    for _ in range(100):
        mid = (l + r) / 2
        if check(mid) > 0:
            l = mid
        else:
            r = mid

    p = [ai / (l + ai) for ai in a]
    for pi in p:
        print(pi)

if __name__ == "__main__":
    main()


### Explanation
Binary search is used to find the parameters p1,p2,...,pn. The binary search range is initially set to [0, 10^16]. In each iteration, the mid value is calculated and the function check(mid) is called to determine whether the sum of the probabilities is greater than k. If it is, the left boundary of the range is updated to mid; otherwise, the right boundary is updated to mid. This process is repeated 100 times to achieve the desired precision. The probabilities p1,p2,...,pn are then calculated using the formula ai / (x + ai), where x is the final mid value.
## Token
[293, 623, 916]
 ### 

