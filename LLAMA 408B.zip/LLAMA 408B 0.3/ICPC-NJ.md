## Question
(B)
Grammy's birthday is approaching, and she gets a sequence $A$ from her friends as a gift. The sequence consists of only $0$, $1$, and $2$. Grammy thinks that the sequence is too long, so she decides to modify $A$ to make it shorter.

Formally, Grammy can perform an arbitrary number of operations. Each time she can choose one of the following three operations to perform:

-   Change any $2$ into $0$ or $1$.
-   Choose two adjacent $0$s, erase them, and concatenate the rest of the parts.
-   Choose two adjacent $1$s, erase them, and concatenate the rest of the parts.

Calculate the minimum sequence length Grammy can get.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first and only line contains a string of length $n$ ($1\leq n\leq 2 \times 10^5$) consisting of digits $0$, $1$, and $2$, indicating the initial sequence $A$.

It is guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the minimum sequence length Grammy can get.

Example Input1:
0110101
Example Output1：
3
Example Input2:
01020102
Example Output2：
4
Example Input3:
0000021111
Example Output3：
0
Example Input4:
1012121010
Example Output4：
6
Example Input5:
0100202010
Example Output5：
0


## Solution


def min_length(s):
    stack = []
    for c in s:
        if c == '2':
            stack.append('0')
        elif stack and stack[-1] == c:
            stack.pop()
        else:
            stack.append(c)
    return len(stack)

t = int(input())
for _ in range(t):
    s = input()
    print(min_length(s))



## CODE


def min_length(s):
    stack = []
    for c in s:
        if c == '2':
            stack.append('0')
        elif stack and stack[-1] == c:
            stack.pop()
        else:
            stack.append(c)
    return len(stack)

t = int(input())
for _ in range(t):
    s = input()
    print(min_length(s))


### Explanation
This problem can be solved using a stack-based approach. We iterate over the input string, and for each character, we apply the given operations. If we encounter a '2', we push '0' onto the stack. If we encounter a '0' or '1' and the top of the stack is the same character, we pop the top of the stack (this simulates the operation of erasing two adjacent '0's or '1's). Otherwise, we push the character onto the stack. The minimum length of the sequence is the size of the stack at the end of the iteration.
## Token
[213, 457, 670]
 ### 

## Question

(C)
You are given a tree consisting of $n$ vertices, rooted at vertex $1$. It is guaranteed that every vertex has a smaller index than all of its children. A topological order of this tree is a permutation $p_1,p_2,\dots,p_n$ of $n$ that satisfies the following constraint: For all $1\leq i&lt;j\leq n$, vertex $p_j$ is not the parent of vertex $p_i$.

For each $1 \le i \le n$, calculate the number of topological orders of the given tree satisfying $p_i=i$, modulo $998\,244\,353$.

**Input**

There is only one test case in each test file.

The first line contains an integer $n$ ($2\leq n\leq 5\,000$), denoting the number of vertices of the tree.

The second line contains $(n-1)$ integers $f_2,f_3,\dots,f_n$ ($1\leq f_i&lt; i$), where $f_i$ is the parent of vertex $i$.

**Output**

Output one line containing $n$ integers $a_1, a_2, \cdots, a_n$ separated by a space, where $a_i$ is the number of topological orders satisfying $p_i=i$, modulo $998\,244\,353$.

Example Input1：
4
1 1 2
Example Output1：
3 2 1 2
Example Input2：
9
1 1 2 2 3 3 4 5
Example Output2：
672 420 180 160 152 108 120 170 210

**Note**

For the first sample test case, all topological orders of the tree are $\{1, 2, 3, 4\}$, $\{1, 3, 2, 4\}$ and $\{1, 2, 4, 3\}$. There are $3$ of them satisfying $p_1 = 1$, $2$ of them satisfying $p_2 = 2$, $1$ of them satisfying $p_3 = 3$, and $2$ of them satisfying $p_4 = 4$.


## Solution


MOD = 998244353

def dfs(graph, dp, child_dp, node):
    if not graph[node]:
        dp[node] = 1
        child_dp[node] = 1
        return

    dp[node] = 1
    child_dp[node] = 1
    for child in graph[node]:
        dfs(graph, dp, child_dp, child)
        dp[node] = (dp[node] * dp[child]) % MOD
        child_dp[node] = (child_dp[node] * child_dp[child]) % MOD

    dp[node] = (dp[node] * len(graph[node])) % MOD

def solve(n, parents):
    graph = [[] for _ in range(n)]
    for i, parent in enumerate(parents):
        graph[parent - 1].append(i + 1)

    dp = [0] * n
    child_dp = [0] * n
    dfs(graph, dp, child_dp, 0)

    ans = [0] * n
    ans[0] = dp[0]
    for i in range(1, n):
        parent = parents[i - 1] - 1
        ans[i] = (child_dp[i] * dp[parent] * pow(len(graph[parent]), MOD - 2, MOD)) % MOD

    return ans

n = int(input())
parents = list(map(int, input().split()))
print(*solve(n, parents))



## CODE


MOD = 998244353

def dfs(graph, dp, child_dp, node):
    if not graph[node]:
        dp[node] = 1
        child_dp[node] = 1
        return

    dp[node] = 1
    child_dp[node] = 1
    for child in graph[node]:
        dfs(graph, dp, child_dp, child)
        dp[node] = (dp[node] * dp[child]) % MOD
        child_dp[node] = (child_dp[node] * child_dp[child]) % MOD

    dp[node] = (dp[node] * len(graph[node])) % MOD

def solve(n, parents):
    graph = [[] for _ in range(n)]
    for i, parent in enumerate(parents):
        graph[parent - 1].append(i + 1)

    dp = [0] * n
    child_dp = [0] * n
    dfs(graph, dp, child_dp, 0)

    ans = [0] * n
    ans[0] = dp[0]
    for i in range(1, n):
        parent = parents[i - 1] - 1
        ans[i] = (child_dp[i] * dp[parent] * pow(len(graph[parent]), MOD - 2, MOD)) % MOD

    return ans

n = int(input())
parents = list(map(int, input().split()))
print(*solve(n, parents))


### Explanation
The method used in this code is Dynamic Programming (DP) with Depth-First Search (DFS). We first build the tree structure from the given parent array. Then we perform DFS to calculate the number of topological orders for each subtree. We use two DP arrays: `dp` to store the number of topological orders for each subtree, and `child_dp` to store the number of topological orders for each subtree without considering the current node. Finally, we calculate the answer for each node by combining the results from its children and its parent.
## Token
[423, 583, 1006]
 ### 

## Question


(E)
Given a string $S = s_0s_1\cdots s_{n-1}$ of length $n$, you can shift $S$ to the left for at most $k$ times (including zero times). Calculate the maximum number of "nanjing" substrings contained in the string after the operations.

More formally, let $f(S, d)$ be the string obtained by shifting $S$ to the left $d$ times. That is, $f(S, d) = s_{(d+0)\bmod n}s_{(d+1)\bmod n}\cdots s_{(d+n-1)\bmod n}$. Let $g(f(S, d), l, r) = s_{(d+l)\bmod n}s_{(d+l+1)\bmod n}\cdots s_{(d+r)\bmod n}$. Let $h(d)$ be the number of integer pairs $(l, r)$ such that $0 \le l \le r &lt; n$ and $g(f(S, d), l, r) =$ nanjing. Find an integer $d$ such that $0 \le d \le k$ to maximize $h(d)$ and output this maximized value.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $k$ ($1 \le n \le 2 \times 10^5$, $0 \le k \le 10^9$) indicating the length of the string and the maximum number of left shifts you can perform.

The second line contains a string $s_0s_1\cdots s_{n - 1}$ of length $n$. The string consists of lower-cased English letters.

It's guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of "nanjing" substrings contained in the string.

Example Input1：
21 10
jingicpcnanjingsuanan
Example Output1：
2

Example Input2：
21 0
jingicpcnanjingsuanan
Example Output2：
1

Example Input3：
21 3
nanjingnanjingnanjing
Example Output3：
3

Example Input4：
4 100
icpc
Example Output4：
0

**Note**

For the first sample test case, we can shift the string to the left $6$ times and get the string "pcnanjingsuananjingic". There are two "nanjing" substrings.

For the second sample test case, because $k = 0$, we cannot perform any left shifting. There is one "nanjing" substring in the original string.


## Solution


def kmp(s):
    n = len(s)
    lps = [0] * n
    j = 0
    for i in range(1, n):
        while j > 0 and s[i] != s[j]:
            j = lps[j - 1]
        if s[i] == s[j]:
            j += 1
        lps[i] = j
    return lps

def count_substring(s, target):
    n = len(s)
    m = len(target)
    lps = kmp(target)
    j = 0
    count = 0
    for i in range(n):
        while j > 0 and s[i] != target[j]:
            j = lps[j - 1]
        if s[i] == target[j]:
            j += 1
        if j == m:
            count += 1
            j = lps[j - 1]
    return count

def solve(n, k, s):
    target = 'nanjing'
    s += s
    counts = [0] * n
    for i in range(n):
        counts[i] = count_substring(s[i:i + n], target)
    max_count = max(counts[:k + 1])
    return max_count

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    k = min(k, n)
    result = solve(n, k, s)
    print(result)



## CODE


def kmp(s):
    n = len(s)
    lps = [0] * n
    j = 0
    for i in range(1, n):
        while j > 0 and s[i] != s[j]:
            j = lps[j - 1]
        if s[i] == s[j]:
            j += 1
        lps[i] = j
    return lps

def count_substring(s, target):
    n = len(s)
    m = len(target)
    lps = kmp(target)
    j = 0
    count = 0
    for i in range(n):
        while j > 0 and s[i] != target[j]:
            j = lps[j - 1]
        if s[i] == target[j]:
            j += 1
        if j == m:
            count += 1
            j = lps[j - 1]
    return count

def solve(n, k, s):
    target = 'nanjing'
    s += s
    counts = [0] * n
    for i in range(n):
        counts[i] = count_substring(s[i:i + n], target)
    max_count = max(counts[:k + 1])
    return max_count

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    k = min(k, n)
    result = solve(n, k, s)
    print(result)


### Explanation
We use the KMP (Knuth-Morris-Pratt) algorithm to efficiently count the occurrences of the substring 'nanjing' in the given string. The KMP algorithm is a string searching algorithm that uses the observation that when a mismatch occurs, the information about the mismatch can be used to skip characters in the text and to shift the pattern along the text. 

In the `solve` function, we first concatenate the string with itself to simulate the left shift operation. Then we count the occurrences of 'nanjing' in each substring of length `n` starting from each position `i` in the concatenated string. We store these counts in the `counts` array. Finally, we find the maximum count in the first `k + 1` elements of the `counts` array, which corresponds to the maximum number of 'nanjing' substrings that can be obtained by shifting the string to the left at most `k` times.
## Token
[526, 718, 1244]
 ### 

## Question


(F)
In Pigeland, the subway system is quite advanced. It consists of $n$ sites, numbered from $1$ to $n$, and $k$ directed subway lines, numbered from $1$ to $k$. Subway line $i$ travels through sites $x_{i, 1}, x_{i, 2}, \cdots, x_{i, p_i}$ in order, where $x_{i, j}$ is the $j$\-th site visited by line $i$. It takes $w_{i,j}$ units of time to travel from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$.

When multiple lines meet at the same site, passengers can transfer between lines. If a passenger is at a site on line $x$, while line $y$ also passes through this site, he/she can spend $a_y \times b_x$ units of time to transfer from line $x$ to line $y$, where $a_y$ and $b_x$ are given coefficients for lines $y$ and $x$. After transferring, the passenger is still at the same site, but on line $y$.

You start at site $1$. Find the minimum time needed to reach site $s$ for all $2 \le s \le n$. In particular, you can start by choosing any line at site $1$ with no transfer time cost. It is guaranteed that all sites are reachable from site $1$.

**Input**

There is only one test case in each test file.

The first line contains two integers $n$ and $k$ ($2 \leq n \leq 2 \times 10^5$, $1 \leq k \leq 2 \times 10^5$), indicating the number of sites and the number of subway lines.

The second line contains $k$ integers $a_1, a_2, \cdots, a_k$ ($1 \leq a_i \leq 10^6$).

The third line contains $k$ integers $b_1, b_2, \cdots, b_k$ ($1 \leq b_i \leq 10^6$).

For the following $k$ lines, the $i$\-th line first contains an integer $p_i$ ($2 \leq p_i \leq n$), indicating the number of sites line $i$ travels through. Then $(2p_i - 1)$ integers $x_{i, 1}, w_{i, 1}, x_{i, 2}, \ldots, x_{i, p_i - 1}, w_{i, p_i - 1}, x_{i, p_i}$ follow ($1 \leq x_{i,j} \leq n$, $1 \leq w_{i,j} \leq 10^9$), where $x_{i, j}$ is the $j$\-th site visited by line $i$, and $w_{i,j}$ is the travel time from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$. The sites traveled through by a subway line are distinct.

It is guaranteed that $\sum\limits_{i=1}^k (p_i - 1) \leq 2 \times 10^5$.

**Output**

Output one line containing $(n - 1)$ integers $d_2, d_3, \cdots, d_n$ separated by a space, where $d_i$ is the minimum time cost from site $1$ to site $i$.

Example Input1：
6 3
1 5 1
5 5 1
3 1 2 2 3 3
3 5 1 2 1 4
3 3 4 5 4 6
Example Output1：
2 5 21 14 18

Example Input2：
6 3
1 5 1
5 5 1
5 1 2 2 100 3 100 6 1 4
5 1 100 2 4 3 100 5 1 4
2 3 1 5
Example Output2：
2 31 43 37 136


## Solution


import heapq

def main():
    n, k = map(int, input().split())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))

    graph = [[] for _ in range(n + 1)]
    for i in range(k):
        p, *info = map(int, input().split())
        for j in range(0, 2 * p - 2, 2):
            u, w, v = info[j], info[j + 1], info[j + 2]
            graph[u].append((v, w, i))

    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    pq = [(0, 1, None)]

    while pq:
        d, u, line = heapq.heappop(pq)
        if d > dist[u]:
            continue

        for v, w, i in graph[u]:
            if line is None:
                new_dist = d + w
            elif line == i:
                new_dist = d + w
            else:
                new_dist = d + w + a[i] * b[line]

            if new_dist < dist[v]:
                dist[v] = new_dist
                heapq.heappush(pq, (new_dist, v, i))

    print(*dist[2:])

if __name__ == "__main__":
    main()



## CODE


import heapq

def main():
    n, k = map(int, input().split())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))

    graph = [[] for _ in range(n + 1)]
    for i in range(k):
        p, *info = map(int, input().split())
        for j in range(0, 2 * p - 2, 2):
            u, w, v = info[j], info[j + 1], info[j + 2]
            graph[u].append((v, w, i))

    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    pq = [(0, 1, None)]

    while pq:
        d, u, line = heapq.heappop(pq)
        if d > dist[u]:
            continue

        for v, w, i in graph[u]:
            if line is None:
                new_dist = d + w
            elif line == i:
                new_dist = d + w
            else:
                new_dist = d + w + a[i] * b[line]

            if new_dist < dist[v]:
                dist[v] = new_dist
                heapq.heappush(pq, (new_dist, v, i))

    print(*dist[2:])

if __name__ == "__main__":
    main()


### Explanation
This problem can be solved using Dijkstra's algorithm with a priority queue. The key idea is to maintain the minimum distance to each node and update it whenever a shorter path is found. The priority queue is used to efficiently select the node with the minimum distance to explore next.

In this implementation, we first read the input and construct the graph. Then, we initialize the distance array and the priority queue. We start with node 1 and a distance of 0.

In the main loop, we pop the node with the minimum distance from the priority queue and explore its neighbors. For each neighbor, we calculate the new distance and update the distance array if a shorter path is found. We also push the neighbor into the priority queue.

Finally, we print the minimum distances to nodes 2 to n.

Note that we use a tuple (d, u, line) in the priority queue, where d is the distance, u is the node, and line is the line number. This allows us to efficiently handle the transfer time between lines.
## Token
[519, 1022, 1541]
 ### 

## Question


(G)
Given a binary tree with $n$ vertices, your task is to find a special vertex $s$ in the tree with at most $p = \lfloor \log_2 n \rfloor$ queries. That is to say, $p$ is the largest integer such that $2^p \le n$.

Each query consists of two different vertices $u$ and $v$. The interactor will output an integer $t$ ($0 \le t \le 2$) as the answer. Let $d(a, b)$ be the number of edges on the simple path from vertex $a$ to vertex $b$.

-   If $t = 0$, then vertex $u$ is nearer to the special vertex. That is, $d(u, s) &lt; d(v, s)$.
-   If $t = 1$, then the distances from $u$ and $v$ to the special vertex are the same. That is, $d(u, s) = d(v, s)$.
-   If $t = 2$, then vertex $v$ is nearer to the special vertex. That is, $d(u, s) &gt; d(v, s)$.

Note that the interactor is adaptive, meaning that the answer for each test case is not pre-determined. The interactor can determine the special vertex according to your queries, as long as its answer does not conflict with the previous queries and answers.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($2 \le n \le 10^5$) indicating the number of vertices in the binary tree.

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($0 \le x_i, y_i \le n$), indicating the left and right child of the $i$\-th vertex. If $x_i = 0$, then the $i$\-th vertex has no left child; if $y_i = 0$, then the $i$\-th vertex has no right child.

It is guaranteed that the sum of $n$ for all test cases will not exceed $2 \times 10^5$.

**Interaction**

To ask a query, output one line. First output ? followed by a space, then print two different integers $u$ and $v$ ($1 \le u, v \le n$) separated by a space. After flushing your output, your program should read a single integer $t$ indicating the answer to your query.

If you want to guess the special vertex, output one line. First output ! followed by a space, then print an integer $s$ ($1 \le s \le n$) indicating the special vertex. After flushing your output, your program should continue processing the next test case, or exit immediately if there are no more test cases. Note that your guess does not count as a query.

To flush your output, you can use:

-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java.
-   stdout.flush() in Python.

Example Input1：
2
5
0 0
1 5
2 4
0 0
0 0

1

0

2
0 2
0 0

2
Example Output1：







? 5 1

? 1 4

! 2



? 2 1

! 1


## Solution


import math
import sys

def query(u, v):
    print(f"? {u} {v}", flush=True)
    return int(input())

def guess(s):
    print(f"! {s}", flush=True)

def dfs(node, depth, tree, max_depth):
    if node == 0:
        return -1, -1
    if tree[node-1][0] == 0 and tree[node-1][1] == 0:
        return node, depth
    left_node, left_depth = dfs(tree[node-1][0], depth + 1, tree, max_depth)
    right_node, right_depth = dfs(tree[node-1][1], depth + 1, tree, max_depth)
    if left_depth == -1 and right_depth == -1:
        return node, depth
    if left_depth == -1:
        return right_node, right_depth
    if right_depth == -1:
        return left_node, left_depth
    if left_depth > right_depth:
        return left_node, left_depth
    return right_node, right_depth

def find_special_vertex(n, tree):
    max_depth = math.floor(math.log2(n))
    node, depth = dfs(1, 0, tree, max_depth)
    while True:
        if depth <= max_depth:
            guess(node)
            break
        parent = 1
        for i in range(n):
            if tree[i][0] == node or tree[i][1] == node:
                parent = i + 1
                break
        result = query(node, parent)
        if result == 0:
            node = parent
            depth -= 1
        elif result == 1:
            guess(node)
            break
        else:
            node = parent
            depth -= 1
            result = query(tree[parent-1][0], tree[parent-1][1])
            if result == 0:
                node = tree[parent-1][0]
            elif result == 2:
                node = tree[parent-1][1]
            depth += 1

t = int(input())
for _ in range(t):
    n = int(input())
    tree = []
    for _ in range(n):
        tree.append(list(map(int, input().split())))
    find_special_vertex(n, tree)



## CODE


import math
import sys

def query(u, v):
    print(f"? {u} {v}", flush=True)
    return int(input())

def guess(s):
    print(f"! {s}", flush=True)

def dfs(node, depth, tree, max_depth):
    if node == 0:
        return -1, -1
    if tree[node-1][0] == 0 and tree[node-1][1] == 0:
        return node, depth
    left_node, left_depth = dfs(tree[node-1][0], depth + 1, tree, max_depth)
    right_node, right_depth = dfs(tree[node-1][1], depth + 1, tree, max_depth)
    if left_depth == -1 and right_depth == -1:
        return node, depth
    if left_depth == -1:
        return right_node, right_depth
    if right_depth == -1:
        return left_node, left_depth
    if left_depth > right_depth:
        return left_node, left_depth
    return right_node, right_depth

def find_special_vertex(n, tree):
    max_depth = math.floor(math.log2(n))
    node, depth = dfs(1, 0, tree, max_depth)
    while True:
        if depth <= max_depth:
            guess(node)
            break
        parent = 1
        for i in range(n):
            if tree[i][0] == node or tree[i][1] == node:
                parent = i + 1
                break
        result = query(node, parent)
        if result == 0:
            node = parent
            depth -= 1
        elif result == 1:
            guess(node)
            break
        else:
            node = parent
            depth -= 1
            result = query(tree[parent-1][0], tree[parent-1][1])
            if result == 0:
                node = tree[parent-1][0]
            elif result == 2:
                node = tree[parent-1][1]
            depth += 1

t = int(input())
for _ in range(t):
    n = int(input())
    tree = []
    for _ in range(n):
        tree.append(list(map(int, input().split())))
    find_special_vertex(n, tree)


### Explanation
This solution uses a depth-first search (DFS) to find the deepest leaf node in the binary tree. If the depth of the deepest leaf node is greater than the maximum allowed depth (log2(n)), it uses queries to move up the tree until it finds a node with a depth less than or equal to the maximum allowed depth. If the depth of the deepest leaf node is less than or equal to the maximum allowed depth, it directly guesses the deepest leaf node as the special vertex. The solution uses queries to determine which child node to move to when moving down the tree.
## Token
[611, 870, 1481]
 ### 

## Question


(I)
Given two integers $n$, $m$ and an integer sequence $a_1, a_2, \cdots, a_{nm}$ of length $n \times m$, we're going to fill a grid of $n$ rows and $m$ columns with the integers from the sequence. More specifically, let $(i, j)$ be the cell on the $i$\-th row and the $j$\-th column, we'll put the $((i - 1) \times m + j)$\-th element of the sequence (that is, $a_{(i - 1) \times m + j}$) into that cell.

We say an integer $k$ is a "bingo integer" of the sequence, if after filling all the cells, at least one of the two following conditions is satisfied.

-   There is at least one row, where all integers in the cells of that row are less than or equal to $k$.
-   There is at least one column, where all integers in the cells of that column are less than or equal to $k$.

It is easy to see that a sequence may have multiple bingo integers, however in this problem, we're only interested in the smallest bingo integer.

Calculate the sum of the smallest bingo integers for all $(nm)!$ permutations of the given sequence. As the answer may be large, output the answer modulo $998\,244\,353$.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $m$ ($1 \le n, m \le 2 \times 10^5$, $1 \le n \times m \le 2 \times 10^5$), indicating the number of rows and columns of the grid.

The second line contains $n \times m$ integers $a_1, a_2, \cdots, a_{nm}$ ($0 \le a_i &lt; 998\,244\,353$) indicating the given sequence.

It's guaranteed that the sum of $n \times m$ of all test cases will not exceed $4 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the answer.

Example Input1：
2 2
1 3 2 4
Example Output1：
56

Example Input2：
3 1
10 10 10
Example Output2：
60

Example Input3：
1 3
20 10 30
Example Output3：
60

Example Input4：
3 4
1 1 4 5 1 4 1 9 1 9 8 10
Example Output4：
855346687

**Note**

For the first sample test case, if $1$ and $2$ are not on the same row or column, then the smallest bingo integer will be $3$, otherwise the smallest bingo integer will be $2$. There are $8$ permutations where $1$ and $2$ are not on the same row or column, so the answer is $8 \times 3 + (4! - 8) \times 2 = 56$.

For the second sample test case, the smallest bingo integer is always $10$, so the answer is $3! \times 10 = 60$.


## Solution


import sys
input = sys.stdin.readline

mod = 998244353

def ksm(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % mod
        a = a * a % mod
        b >>= 1
    return res

def init(n):
    fac = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = fac[i - 1] * i % mod
    return fac

def C(n, m, fac):
    return fac[n] * ksm(fac[m], mod - 2) % mod * ksm(fac[n - m], mod - 2) % mod

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    fac = init(n * m)
    ans = 0
    for i in range(n * m):
        if n * m - i < max(n, m):
            break
        ans = (ans + a[i] * (C(n * m, i, fac) - C(n * m - max(n, m), i - max(n, m), fac))) % mod
    print((ans + mod) % mod)

T = int(input())
for _ in range(T):
    solve()



## CODE


import sys
input = sys.stdin.readline

mod = 998244353

def ksm(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % mod
        a = a * a % mod
        b >>= 1
    return res

def init(n):
    fac = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = fac[i - 1] * i % mod
    return fac

def C(n, m, fac):
    return fac[n] * ksm(fac[m], mod - 2) % mod * ksm(fac[n - m], mod - 2) % mod

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    fac = init(n * m)
    ans = 0
    for i in range(n * m):
        if n * m - i < max(n, m):
            break
        ans = (ans + a[i] * (C(n * m, i, fac) - C(n * m - max(n, m), i - max(n, m), fac))) % mod
    print((ans + mod) % mod)

T = int(input())
for _ in range(T):
    solve()


### Explanation
We use the inclusion-exclusion principle to calculate the answer. First, we sort the sequence in ascending order. Then, for each number in the sequence, we calculate the number of permutations where this number is the smallest bingo integer. We use the combination formula to calculate this. We subtract the number of permutations where this number is not the smallest bingo integer, which is the number of permutations where the smallest bingo integer is larger than this number. We use the combination formula again to calculate this. Finally, we multiply the number of permutations by the number itself and add it to the answer. We use the modular arithmetic to avoid overflow.
## Token
[437, 828, 1265]
 ### 

## Question


(J)
On a social media platform, users can leave comments under others' posts to express their thoughts. However, these comments are not visible to everyone. Specifically, for user $C$ to see user $A$'s comments under user $B$'s post, he/she has to be friends with both $A$ and $B$ at the same time. If a user leaves a comment under his/her own post, all his/her friends can see this comment.

As an active user on this platform, you would like to see as many comments as possible. There are $k$ users (not counting you) on the platform, numbered from $1$ to $k$. There are also $m$ comments on the platform, but you might not be able to see them all because you only have $n$ friends. As you need to participate in the 2024 ICPC Asia Nanjing Regional Contest, you don't have time to make too many new friends. What's the maximum number of comments you can see if you make at most two new friends on the platform?

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains three integers $n$, $m$, and $k$ ($1 \le n \le k \le 2 \times 10^5$, $1 \le m \le 2 \times 10^5$) indicating the number of your friends, the number of comments, and the number of users (not counting you) on the platform.

The second line contains $n$ distinct integers $f_1, f_2, \cdots, f_n$ ($1 \le f_i \le k$) indicating your friends on the platform.

For the following $m$ lines, the $i$\-th line contains two integers $a_i$ and $b_i$ ($1 \le a_i, b_i \le k$) indicating a comment written by user $a_i$ under user $b_i$'s post.

It's guaranteed that neither the sum of $k$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of comments you can see if you make at most two new friends on the platform.

Example Input1：
4 12 7
5 7 3 6
3 6
2 2
1 4
2 4
1 3
7 6
4 1
5 4
1 1
1 1
2 1
3 7
Example Output1：
9

Example Input2：
2 7 6
2 4
1 2
3 2
2 5
5 4
2 6
4 6
2 6
Example Output2：
5

Example Input3：
1 1 2
1
1 2
Example Output3：
1

Example Input4：
2 1 2
1 2
1 2
Example Output4：
1

Example Input5：
2 1 100
24 11
11 24
Example Output5：
1

**Note**

For the first sample test case, you can make friends with user $1$ and $4$.

For the second sample test case, you can make friends with user $5$ and $6$.

For the third sample test case, you can make friends with user $2$.

For the fourth and fifth sample test cases, you don't need to make new friends because you can already see all comments.


## Solution


import sys
input = sys.stdin.readline

def solve():
    n, m, k = map(int, input().split())
    friends = set(map(int, input().split()))
    comments = {}
    for _ in range(m):
        a, b = map(int, input().split())
        if a not in comments:
            comments[a] = []
        if b not in comments:
            comments[b] = []
        comments[a].append(b)

    count = 0
    for a in comments:
        for b in comments[a]:
            if a in friends and b in friends:
                count += 1

    max_count = count
    for i in range(1, k + 1):
        if i not in friends:
            new_count = count
            for a in comments:
                for b in comments[a]:
                    if (a == i and b in friends) or (b == i and a in friends):
                        new_count += 1
            max_count = max(max_count, new_count)

    for i in range(1, k + 1):
        if i not in friends:
            for j in range(i + 1, k + 1):
                if j not in friends:
                    new_count = count
                    for a in comments:
                        for b in comments[a]:
                            if (a == i and b in friends) or (b == i and a in friends) or (a == j and b in friends) or (b == j and a in friends) or (a == i and b == j) or (a == j and b == i):
                                new_count += 1
                    max_count = max(max_count, new_count)

    print(max_count)

t = int(input())
for _ in range(t):
    solve()



## CODE


import sys
input = sys.stdin.readline

def solve():
    n, m, k = map(int, input().split())
    friends = set(map(int, input().split()))
    comments = {}
    for _ in range(m):
        a, b = map(int, input().split())
        if a not in comments:
            comments[a] = []
        if b not in comments:
            comments[b] = []
        comments[a].append(b)

    count = 0
    for a in comments:
        for b in comments[a]:
            if a in friends and b in friends:
                count += 1

    max_count = count
    for i in range(1, k + 1):
        if i not in friends:
            new_count = count
            for a in comments:
                for b in comments[a]:
                    if (a == i and b in friends) or (b == i and a in friends):
                        new_count += 1
            max_count = max(max_count, new_count)

    for i in range(1, k + 1):
        if i not in friends:
            for j in range(i + 1, k + 1):
                if j not in friends:
                    new_count = count
                    for a in comments:
                        for b in comments[a]:
                            if (a == i and b in friends) or (b == i and a in friends) or (a == j and b in friends) or (b == j and a in friends) or (a == i and b == j) or (a == j and b == i):
                                new_count += 1
                    max_count = max(max_count, new_count)

    print(max_count)

t = int(input())
for _ in range(t):
    solve()


### Explanation
This solution works by iterating over all possible combinations of making 0, 1, or 2 new friends and counting the maximum number of comments that can be seen. It uses a set to efficiently check if a user is a friend, and a dictionary to store the comments made by each user. The time complexity is O(t \* (m + k^2)), where t is the number of test cases, m is the number of comments, and k is the number of users.
## Token
[483, 888, 1371]
 ### 

## Question


(K)
There are $w$ cells arranged in a row, numbered from $1$ to $w$ from left to right. Among the cells, $n$ of them are red, $m$ of them are black, and the remaining $(w - n - m)$ cells are white.

You need to cover all the red cells with some strips. Each strip must cover $k$ continuous cells. Find a way to cover all red cells while satisfying all the following constraints:

-   Each red cell is covered by a strip.
-   No black cell is covered by a strip.
-   No two strips cover the same cell. That is, each cell is covered by at most one strip.
-   The number of strips used is as small as possible.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains four integers $n$, $m$, $k$ and $w$ ($1 \le n, m \le 10^5$, $1 \le k \le w \le 10^9$, $n + m \le w$), indicating the number of red cells, the number of black cells, the length of each strip and the total number of cells.

The second line contains $n$ integers $a_1, a_2, \cdots, a_n$ ($1 \le a_i \le w$), indicating that cell $a_i$ is red.

The third line contains $m$ integers $b_1, b_2, \cdots, b_m$ ($1 \le b_i \le w$), indicating that cell $b_i$ is black.

It's guaranteed that the given $(n + m)$ cells are distinct. It's also guaranteed that neither the sum of $n$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case:

If it is possible to cover all the red cells while satisfying all constraints, first output one line containing one integer $c$ indicating the smallest number of strips used. Then output another line containing $c$ integers $l_1, l_2, \cdots, l_c$ ($1 \le l_i \le w - k + 1$) separated by a space, where $l_i$ is the left-most cell covered by the $i$\-th strip. If there are multiple valid answers, you can output any of them.

If it is not possible to do so, just output \-1 in one line.

Example Input1：
5 2 3 16
7 11 2 9 14
13 5
Example Output1：
4
6 2 14 9

Example Input2：
3 2 4 11
6 10 2
1 11
Example Output2：
-1

Example Input3：
2 1 2 6
1 5
3
Example Output3：
2
1 4

Example Input4：
2 1 2 6
1 5
2
Example Output4：
-1


## Solution


import sys

def solve():
    n, m, k, w = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))
    b = list(map(int, sys.stdin.readline().split()))

    a.sort()
    b.sort()

    res = []
    i, j = 0, 0
    while i < n:
        start = a[i]
        while j < m and b[j] < start:
            j += 1
        if j < m and b[j] < start + k:
            return -1
        end = start + k - 1
        while i < n and a[i] <= end:
            i += 1
        res.append(start)

    return len(res), res

t = int(sys.stdin.readline())
for _ in range(t):
    ans = solve()
    if ans == -1:
        print(-1)
    else:
        print(ans[0])
        print(' '.join(map(str, ans[1])))




## CODE


import sys

def solve():
    n, m, k, w = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))
    b = list(map(int, sys.stdin.readline().split()))

    a.sort()
    b.sort()

    res = []
    i, j = 0, 0
    while i < n:
        start = a[i]
        while j < m and b[j] < start:
            j += 1
        if j < m and b[j] < start + k:
            return -1
        end = start + k - 1
        while i < n and a[i] <= end:
            i += 1
        res.append(start)

    return len(res), res

t = int(sys.stdin.readline())
for _ in range(t):
    ans = solve()
    if ans == -1:
        print(-1)
    else:
        print(ans[0])
        print(' '.join(map(str, ans[1])))



### Explanation
We use a greedy algorithm to solve this problem. First, we sort the red and black cells. Then we try to cover the red cells with strips from left to right. For each red cell, we check if there is a black cell within the strip that covers the red cell. If there is, we return -1. Otherwise, we add the start position of the strip to the result list and move to the next red cell. We repeat this process until all red cells are covered. The number of strips used is the length of the result list.
## Token
[339, 771, 1110]
 ### 

## Question


(M)
Neuvillette is the Chief Justice of Fontaine, known as the Iudex, and he is renowned for his unassailable impartiality. As a playable character in the world-famous game Genshin Impact, he is known for his powerful charged attack that can hit enemies within a specific range.

Since he is very powerful, many players use him while challenging almost every quest. However, not everybody in Teyvat is happy about this, especially other ADC (Attack Damage Carry) characters, including Kamisato Ayaka, Keqing, etc. Together, they decide to persuade Mihoyo to nerf Neuvillette in the game. To do so, they must submit a report about Neuvillette's total damage in several scenarios.

Created from Genshin Impact official material

Each battle scenario happens on a two-dimensional plane. Neuvillette stands on $(0,0)$ facing $(x_0, y_0)$ initially, making a charged attack which lasts for $t$ units of time, and rotates $1$ rad counter-clockwise per unit of time. That is to say, Neuvillette turns a circle counter-clockwise in $2 \pi$ units of time.

Consider a ray from $(0,0)$ towards the direction Neuvillette faces. The attack range is the set of points whose distance to the ray is at most $d$. If the target, whose shape is a convex polygon, has common points with the attack range, it will suffer $1$ continued damage per unit of time.

As an experienced programmer, you are summoned by Ayaka. This time, your task is to calculate the damage the target incurs in the first $t$ units of time.

**Input**

There is only one test case in each test file.

The first line contains five integers $n$, $x_0$, $y_0$, $d$, and $t$ ($3 \le n \le 100$, $-10^4 \le x_0, y_0 \le 10^4$, $x_0^2 + y_0^2 &gt; 0$, $1 \le d, t \le 10^4$).

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($-10^4 \le x_i, y_i \le 10^4$), indicating the coordinates of the $i$\-th vertex of the convex polygon.

All $n$ vertices are given in counter-clockwise order, and any three of them are not collinear. It is also guaranteed that the shape has no common points with the circle centered at $(0,0)$ with radius $d$. That is to say, there does not exist a point inside or on the boundary of the convex polygon, while at the same time inside or on the boundary of the circle.

**Output**

Output one line containing one real number, indicating the damage the target incurs in the first $t$ units of time.

Your answer will be considered correct if its absolute or relative error does not exceed $10^{-6}$. Formally speaking, suppose that your output is $a$ and the jury's answer is $b$, your output is accepted if and only if $\frac{|a - b|}{\max(1, |b|)} \le 10^{-6}$.

Example Input1：
3 1 0 1 1
1 2
2 1
2 2
Example Output1：
1.000000000000

Example Input2：
3 1 0 1 2
1 2
2 1
2 2
Example Output2：
1.570796326795

Example Input3：
3 1 0 1 10000
1 2
2 1
2 2
Example Output3：
2500.707752257475
## Solution


import math

def cross(x1, y1, x2, y2):
    return x1 * y2 - x2 * y1

def dot(x1, y1, x2, y2):
    return x1 * x2 + y1 * y2

def get_angle(x, y):
    if y > 0:
        return math.acos(x / math.sqrt(x * x + y * y))
    elif y < 0:
        return 2 * math.pi - math.acos(x / math.sqrt(x * x + y * y))
    elif x > 0:
        return 0
    else:
        return math.pi

def get_intersection(x1, y1, x2, y2, d):
    a = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)
    b = 2 * (x1 * (x2 - x1) + y1 * (y2 - y1))
    c = x1 * x1 + y1 * y1 - d * d
    delta = b * b - 4 * a * c
    if delta < 0:
        return None
    t = (-b - math.sqrt(delta)) / (2 * a)
    if t < 0 or t > 1:
        t = (-b + math.sqrt(delta)) / (2 * a)
        if t < 0 or t > 1:
            return None
    return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

def get_damage(n, x0, y0, d, t, vertices):
    damage = 0
    angle = get_angle(x0, y0)
    for i in range(n):
        x1, y1 = vertices[i]
        x2, y2 = vertices[(i + 1) % n]
        intersection1 = get_intersection(0, 0, x1, y1, d)
        intersection2 = get_intersection(0, 0, x2, y2, d)
        if intersection1 is None and intersection2 is None:
            continue
        if intersection1 is None:
            intersection1 = intersection2
        if intersection2 is None:
            intersection2 = intersection1
        start_angle = get_angle(intersection1[0], intersection1[1])
        end_angle = get_angle(intersection2[0], intersection2[1])
        if start_angle > end_angle:
            end_angle += 2 * math.pi
        if angle < start_angle:
            damage += min(end_angle, angle + t) - start_angle
        elif angle < end_angle:
            damage += min(end_angle, angle + t) - angle
    return damage

n, x0, y0, d, t = map(float, input().split())
vertices = []
for _ in range(int(n)):
    x, y = map(float, input().split())
    vertices.append((x, y))
damage = get_damage(int(n), x0, y0, d, t, vertices)
print(damage)



## CODE


import math

def cross(x1, y1, x2, y2):
    return x1 * y2 - x2 * y1

def dot(x1, y1, x2, y2):
    return x1 * x2 + y1 * y2

def get_angle(x, y):
    if y > 0:
        return math.acos(x / math.sqrt(x * x + y * y))
    elif y < 0:
        return 2 * math.pi - math.acos(x / math.sqrt(x * x + y * y))
    elif x > 0:
        return 0
    else:
        return math.pi

def get_intersection(x1, y1, x2, y2, d):
    a = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)
    b = 2 * (x1 * (x2 - x1) + y1 * (y2 - y1))
    c = x1 * x1 + y1 * y1 - d * d
    delta = b * b - 4 * a * c
    if delta < 0:
        return None
    t = (-b - math.sqrt(delta)) / (2 * a)
    if t < 0 or t > 1:
        t = (-b + math.sqrt(delta)) / (2 * a)
        if t < 0 or t > 1:
            return None
    return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

def get_damage(n, x0, y0, d, t, vertices):
    damage = 0
    angle = get_angle(x0, y0)
    for i in range(n):
        x1, y1 = vertices[i]
        x2, y2 = vertices[(i + 1) % n]
        intersection1 = get_intersection(0, 0, x1, y1, d)
        intersection2 = get_intersection(0, 0, x2, y2, d)
        if intersection1 is None and intersection2 is None:
            continue
        if intersection1 is None:
            intersection1 = intersection2
        if intersection2 is None:
            intersection2 = intersection1
        start_angle = get_angle(intersection1[0], intersection1[1])
        end_angle = get_angle(intersection2[0], intersection2[1])
        if start_angle > end_angle:
            end_angle += 2 * math.pi
        if angle < start_angle:
            damage += min(end_angle, angle + t) - start_angle
        elif angle < end_angle:
            damage += min(end_angle, angle + t) - angle
    return damage

n, x0, y0, d, t = map(float, input().split())
vertices = []
for _ in range(int(n)):
    x, y = map(float, input().split())
    vertices.append((x, y))
damage = get_damage(int(n), x0, y0, d, t, vertices)
print(damage)


### Explanation
This solution uses geometric calculations to determine the damage incurred by the target. It first calculates the angle of the initial direction of Neuvillette's attack. Then, for each edge of the convex polygon, it calculates the intersection points of the edge with the circle centered at the origin with radius d. If there are intersection points, it calculates the angles of these points and determines the range of angles during which the edge is within the attack range. Finally, it calculates the total damage by summing up the time during which each edge is within the attack range. The solution uses the cross product and dot product of vectors to determine the orientation of the edges and the intersection points. The get_angle function is used to calculate the angle of a point, and the get_intersection function is used to calculate the intersection points of an edge with the circle. The get_damage function calculates the total damage incurred by the target.
## Token
[866, 923, 1789]
 ### 

