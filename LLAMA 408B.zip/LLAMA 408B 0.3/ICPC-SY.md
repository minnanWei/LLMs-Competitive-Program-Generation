## Question
(B)
The little white rabbit has a magical palette with a grid of $n$ rows and $m$ columns. Before starting to mix the colors, the little white rabbit will squeeze a kind of pigment to the left of each row, denoted by $a_1, a_2, \ldots, a_n$, and also squeeze a kind of pigment above each column, denoted by $b_1, b_2, \ldots, b_m$.

There are a total of $n \times m$ kinds of selectable pigments, represented by integers $0, 1, 2, \ldots, nm-1$ for different pigments. Then, in the cell of the $i$\-th row and the $j$\-th column, the little white rabbit will mix a color $c_{i,j} = a_ib_j \bmod nm$ using the pigment $a_i$ to the left of the $i$\-th row and the pigment $b_j$ above the $j$\-th column.

The little white rabbit hopes that each of the $n \times m$ cells has a different color, and you need to find out whether it can be achieved.

**Input**

The first line of the input contains an integer $T$ ($1 \le T \le 10^4$), indicating the number of test cases. For each test case:

The only line contains two integers $n$ and $m$ ($1 \le n, m \le 10^6$, $1 \le n \times m \le 10^6$), indicating the number of rows and the number of columns.

It is guaranteed that the sum of $n \times m$ over all test cases does not exceed $10^6$.

**Output**

For each test case, if no solution exists, output "No" (without quotes) in one line. Otherwise, output three lines:

-   The first line contains one string "Yes" (without quotes).
-   The second line contains $n$ integers $a_1, a_2, \ldots, a_n$ ($0 \le a_i &lt; nm$).
-   The third line contains $m$ integers $b_1, b_2, \ldots, b_m$ ($0 \le b_i &lt; nm$).

Example Input1：
2 3
Example Output1：
Yes
1 2
1 3 5
Example Input2：
2 2
Example Output2：
No

**Note**

For the first sample case, $[c_{1,1}, c_{1,2}, c_{1,3}, c_{2,1}, c_{2,2}, c_{2,3}] = [1, 3, 5, 2, 0, 4]$, which are pairwise different.


## Solution


import math

def solve(n, m):
    if n == 1 and m == 1:
        return "Yes\n0\n0"
    if n == 1:
        return "No"
    if m == 1:
        return "No"

    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a

    def find_primitive_root(n):
        if n == 2:
            return 1
        phi = n
        factors = []
        p = 2
        while p * p <= n:
            if n % p == 0:
                while n % p == 0:
                    n //= p
                factors.append(p)
            p += 1
        if n > 1:
            factors.append(n)
        for res in range(2, phi + 1):
            ok = True
            for f in factors:
                if pow(res, phi // f, phi) == 1:
                    ok = False
                    break
            if ok:
                return res
        return -1

    g = find_primitive_root(n)
    if g == -1:
        return "No"

    a = [pow(g, i, n) for i in range(n)]
    b = [i * n for i in range(m)]

    return "Yes\n" + " ".join(map(str, a)) + "\n" + " ".join(map(str, b))

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    print(solve(n, m))



## CODE


import math

def solve(n, m):
    if n == 1 and m == 1:
        return "Yes\n0\n0"
    if n == 1:
        return "No"
    if m == 1:
        return "No"

    def gcd(a, b):
        while b:
            a, b = b, a % b
        return a

    def find_primitive_root(n):
        if n == 2:
            return 1
        phi = n
        factors = []
        p = 2
        while p * p <= n:
            if n % p == 0:
                while n % p == 0:
                    n //= p
                factors.append(p)
            p += 1
        if n > 1:
            factors.append(n)
        for res in range(2, phi + 1):
            ok = True
            for f in factors:
                if pow(res, phi // f, phi) == 1:
                    ok = False
                    break
            if ok:
                return res
        return -1

    g = find_primitive_root(n)
    if g == -1:
        return "No"

    a = [pow(g, i, n) for i in range(n)]
    b = [i * n for i in range(m)]

    return "Yes\n" + " ".join(map(str, a)) + "\n" + " ".join(map(str, b))

t = int(input())
for _ in range(t):
    n, m = map(int, input().split())
    print(solve(n, m))


### Explanation
We use the concept of primitive roots to solve this problem. A primitive root modulo n is a number g such that the powers of g modulo n generate all the numbers from 1 to n-1 that are relatively prime to n. We first find a primitive root modulo n, then we can construct the array a by taking the powers of the primitive root modulo n. The array b is constructed by multiplying the numbers from 0 to m-1 by n. This ensures that the numbers c_{i,j} = a_i*b_j modulo n*m are all distinct. If n or m is 1, we return "No" because it's impossible to construct the arrays a and b in this case. If n and m are both greater than 1, we return "Yes" and the constructed arrays a and b.
## Token
[517, 702, 1219]
 ### 

## Question


(D)
A permutation of $1$ to $n$ in this problem is a $1$\-based sequence of $n$ integers in which every integer from $1$ to $n$ appears exactly once. Alice and Bob are playing a game on $A = [a_1, a_2, \ldots, a_n]$ and $B = [b_1, b_2, \ldots, b_n]$, two permutations of $1$ to $n$. They take turns to perform operations, with Alice going first, and the one with no possible operation loses.

In each turn, Alice can only operate on the permutation $A$, while Bob can only operate on the permutation $B$. A valid operation consists of choosing two indices $i$ and $j$ on the operable permutation ($1 \leq i, j \leq n$) and swapping their corresponding elements, under the constraint that $\sum_{i=1}^{n}{a_i b_i} = a_1 b_1 + a_2 b_2 + \cdots + a_n b_n$, the dot product of these two permutations, must strictly increase after the swap. Namely, a player loses if he or she cannot perform any swap to increase the dot product, and the other player wins the game.

As Alice and Bob are both clever enough to adopt the best strategy, the winner of such a game can be determined from the start. Therefore, they decide to play the game $n$ times with modifications to make it less boring. Please help them to predict the winners of these $n$ games.

More specifically, two initial permutations $A = [a_1, a_2, \ldots, a_n]$, $B = [b_1, b_2, \ldots, b_n]$, and $(n - 1)$ modifications $[(t_1, l_1, r_1, d_1), (t_2, l_2, r_2, d_2), \ldots, (t_{n - 1}, l_{n - 1}, r_{n - 1}, d_{n - 1})]$ will be given. The first game will start from the given permutations $A$ and $B$, and for $k = 1, 2, \ldots, n - 1$, the $(k + 1)$\-th game will start from the permutations for the $k$\-th game after shifting the interval between indices $l_k$ and $r_k$ of the permutation $t_k$ left $d_k$ times.

Please note that shifting an interval $[p_l, p_{l + 1}, \ldots, p_r]$ left once will give $[p_{l + 1}, p_{l + 2}, \ldots, p_r, p_l]$. For instance, shifting the interval $[2, 4]$ of $[1, 2, 3, 4, 5]$ left once will give $[1, 3, 4, 2, 5]$, and twice will give $[1, 4, 2, 3, 5]$. Besides, shifting the interval $[1, 5]$ of $[3, 1, 4, 5, 2]$ left $4$ times will give $[2, 3, 1, 4, 5]$.

**Input**

The first line of the input contains an integer $T$ ($1 \leq T \leq 10^5$), indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($1 \leq n \leq 5 \times 10^5$), indicating the length of the permutations.

The second line contains $n$ distinct integers $a_1, a_2, \ldots, a_n$ ($1 \leq a_i \leq n$), indicating the permutation $A$.

The third line contains $n$ distinct integers $b_1, b_2, \ldots, b_n$ ($1 \leq b_i \leq n$), indicating the permutation $B$.

In the next $(n - 1)$ lines, the $i$\-th line contains a character $t_i$ ($t_i \in \{\texttt{A}, \texttt{B}\}$), and three integers $l_i$, $r_i$ ($1 \leq l_i \leq r_i \leq n$), and $d_i$ ($1 \leq d_i \leq n$).

It is guaranteed that the sum of $n$ over all test cases does not exceed $5 \times 10^5$.

**Output**

For each test case, output a string of length $n$ in one line, where the $i$\-th character of the string is A if Alice wins the $i$\-th game, or B otherwise (i.e., Bob wins the $i$\-th game).


Example Input：
5
3
1 2 3
1 2 3
A 1 1 1
B 1 1 1
3
1 2 3
2 1 3
A 1 2 1
B 2 2 1
3
1 2 3
2 1 3
A 1 3 1
B 1 2 1
3
1 2 3
3 2 1
A 2 2 1
B 2 3 1
10
1 2 3 4 5 6 7 8 9 10
4 2 3 9 6 1 5 8 7 10
A 2 9 10
B 2 7 9
A 1 10 8
B 4 6 7
B 3 10 6
A 2 5 5
A 8 9 4
B 3 9 3
A 2 7 2
Example Output：
BBB
ABB
AAB
AAB
AABBBBAAAA
**Note**

For the third test case of the sample case:

-   The first game starts with $A = [1, 2, 3]$, $B = [2, 1, 3]$;
-   The second game starts with $A = [2, 3, 1]$, $B = [2, 1, 3]$;
-   The third game starts with $A = [2, 3, 1]$, $B = [1, 2, 3]$.


## Solution


import sys

def read_int():
    return int(sys.stdin.readline())

def read_ints():
    return map(int, sys.stdin.readline().split())

def read_string():
    return sys.stdin.readline().strip()

def solve():
    n = read_int()
    a = list(read_ints())
    b = list(read_ints())
    ans = [''] * n
    pos_a = [0] * (n + 1)
    pos_b = [0] * (n + 1)
    for i in range(n):
        pos_a[a[i]] = i
        pos_b[b[i]] = i
    ans[0] = 'A' if sum(a[i] * b[i] for i in range(n)) < sum(a[i] * b[n - i - 1] for i in range(n)) else 'B'
    for i in range(n - 1):
        t, l, r, d = read_string(), *read_ints()
        l -= 1
        r -= 1
        d %= (r - l + 1)
        if t == 'A':
            for j in range(l, r + 1):
                a[j], a[(j + d) % (r - l + 1) + l] = a[(j + d) % (r - l + 1) + l], a[j]
            for j in range(l, r + 1):
                pos_a[a[j]] = j
        else:
            for j in range(l, r + 1):
                b[j], b[(j + d) % (r - l + 1) + l] = b[(j + d) % (r - l + 1) + l], b[j]
            for j in range(l, r + 1):
                pos_b[b[j]] = j
        ans[i + 1] = 'A' if sum(a[j] * b[j] for j in range(n)) < sum(a[j] * b[n - j - 1] for j in range(n)) else 'B'
    print(''.join(ans))

t = read_int()
for _ in range(t):
    solve()



## CODE


import sys

def read_int():
    return int(sys.stdin.readline())

def read_ints():
    return map(int, sys.stdin.readline().split())

def read_string():
    return sys.stdin.readline().strip()

def solve():
    n = read_int()
    a = list(read_ints())
    b = list(read_ints())
    ans = [''] * n
    pos_a = [0] * (n + 1)
    pos_b = [0] * (n + 1)
    for i in range(n):
        pos_a[a[i]] = i
        pos_b[b[i]] = i
    ans[0] = 'A' if sum(a[i] * b[i] for i in range(n)) < sum(a[i] * b[n - i - 1] for i in range(n)) else 'B'
    for i in range(n - 1):
        t, l, r, d = read_string(), *read_ints()
        l -= 1
        r -= 1
        d %= (r - l + 1)
        if t == 'A':
            for j in range(l, r + 1):
                a[j], a[(j + d) % (r - l + 1) + l] = a[(j + d) % (r - l + 1) + l], a[j]
            for j in range(l, r + 1):
                pos_a[a[j]] = j
        else:
            for j in range(l, r + 1):
                b[j], b[(j + d) % (r - l + 1) + l] = b[(j + d) % (r - l + 1) + l], b[j]
            for j in range(l, r + 1):
                pos_b[b[j]] = j
        ans[i + 1] = 'A' if sum(a[j] * b[j] for j in range(n)) < sum(a[j] * b[n - j - 1] for j in range(n)) else 'B'
    print(''.join(ans))

t = read_int()
for _ in range(t):
    solve()


### Explanation
We maintain two arrays `pos_a` and `pos_b` to store the positions of each element in arrays `a` and `b`. After each operation, we update the positions of the elements in the corresponding array. We then calculate the dot product of arrays `a` and `b` and compare it with the dot product of arrays `a` and `b` when they are sorted in descending order. If the dot product is less than the maximum possible dot product, Alice wins; otherwise, Bob wins. We store the result in the `ans` array and print it at the end.
## Token
[596, 1547, 2143]
 ### 

## Question


(E)
Little Q is testing a self-designed puzzle game involving a $2 \times 2$ grid where each cell can either be on or off. When a cell is toggled, its state changes from off to on or from on to off. The following four operations can be performed at a certain cost:
-   Toggle a single cell with cost $a_0$;
-   Toggle a row of cells with cost $a_1$;
-   Toggle a column of cells with cost $a_2$;
-   Toggle all cells with cost $a_3$.
Little Q has realized that the game has started, but the screen somehow malfunctions, blocking him from seeing the current state of any cell. The only feedback he can receive is a special prompt sound triggered if, after an operation, all cells are on.
Knowing all $m$ possible initial grids of the game in advance, Little Q wants to find a sequence of operations, ensuring that regardless of the initial grid when he starts playing, he will always hear the prompt sound after some operations in the order of the sequence.
Please calculate the minimum total cost of such sequence of operations.

**Input**

The first line of the input contains five integers $T$ ($1 \le T \le 10^4$), $a_0$, $a_1$, $a_2$, and $a_3$ ($1 \le a_0,a_1,a_2,a_3 \le 10^6$), indicating the number of games and the costs of each operation. For each game:

The first line contains an integer $m$ ($1 \le m \le 16$), indicating the number of possible initial grids of the game.

Then $m$ grids follow. For each grid:

-   There will first be an empty line if it is not the first grid in the game.
-   For the following two lines, the $i$\-th line contains a string $s_{i,1}s_{i,2}$ of length $2$ consisting of characters 0 and 1, describing a $2 \times 2$ grid as a possible initial grid. Let $(i, j)$ be the cell on the $i$\-th row and the $j$\-th column. If $s_{i, j}$ is 0, then the cell $(i, j)$ is off, or otherwise the cell $(i, j)$ is on.

It is guaranteed that the given grids in a game are pairwise different.

**Output**

For each game, output a line containing an integer, indicating the minimum total cost.

Example Input：
2 1000 100 10 1
4
10
00


01
00


00
10


00
01
1
11
11
Example Output：
1121
2


## Solution


import sys

def read_ints():
    return map(int, sys.stdin.readline().strip().split())

def read_strings(n):
    grids = []
    for _ in range(n):
        sys.stdin.readline()
        grid = [sys.stdin.readline().strip() for _ in range(2)]
        grids.append(grid)
    return grids

def calculate_cost(grids, a0, a1, a2, a3):
    min_cost = float('inf')
    for i in range(1 << 4):
        cost = 0
        result = set()
        for grid in grids:
            state = 0
            for j in range(2):
                for k in range(2):
                    if grid[j][k] == '1':
                        state |= (1 << (j * 2 + k))
            state ^= i
            result.add(state)
            cost += get_cost(state, a0, a1, a2, a3)
        if len(result) == 1:
            min_cost = min(min_cost, cost)
    return min_cost

def get_cost(state, a0, a1, a2, a3):
    if state == 0:
        return 0
    if state == 15:
        return a3
    if state in [5, 10]:
        return min(a1, 2 * a0)
    if state in [3, 6, 9, 12]:
        return min(a2, 2 * a0)
    return min(a0 + min(a1, a2), 3 * a0)

T, a0, a1, a2, a3 = read_ints()
for _ in range(T):
    n = int(sys.stdin.readline().strip())
    grids = read_strings(n)
    print(calculate_cost(grids, a0, a1, a2, a3))



## CODE


import sys

def read_ints():
    return map(int, sys.stdin.readline().strip().split())

def read_strings(n):
    grids = []
    for _ in range(n):
        sys.stdin.readline()
        grid = [sys.stdin.readline().strip() for _ in range(2)]
        grids.append(grid)
    return grids

def calculate_cost(grids, a0, a1, a2, a3):
    min_cost = float('inf')
    for i in range(1 << 4):
        cost = 0
        result = set()
        for grid in grids:
            state = 0
            for j in range(2):
                for k in range(2):
                    if grid[j][k] == '1':
                        state |= (1 << (j * 2 + k))
            state ^= i
            result.add(state)
            cost += get_cost(state, a0, a1, a2, a3)
        if len(result) == 1:
            min_cost = min(min_cost, cost)
    return min_cost

def get_cost(state, a0, a1, a2, a3):
    if state == 0:
        return 0
    if state == 15:
        return a3
    if state in [5, 10]:
        return min(a1, 2 * a0)
    if state in [3, 6, 9, 12]:
        return min(a2, 2 * a0)
    return min(a0 + min(a1, a2), 3 * a0)

T, a0, a1, a2, a3 = read_ints()
for _ in range(T):
    n = int(sys.stdin.readline().strip())
    grids = read_strings(n)
    print(calculate_cost(grids, a0, a1, a2, a3))


### Explanation
This solution uses a brute-force approach to find the minimum cost. It iterates over all possible initial states (i.e., all possible combinations of 0s and 1s in the 2x2 grid) and calculates the cost of reaching the target state (all 1s) from each initial state. The cost is calculated by considering all possible operations (toggling a single cell, a row, a column, or all cells) and choosing the one with the minimum cost. The solution also takes into account the fact that some operations can be combined to reduce the overall cost.
## Token
[526, 681, 1207]
 ### 

## Question


(G)
You are given a simple polygon, but before giving you the $n$ vertices of the polygon, Little Q has shuffled them.

Now you can ask Little Q no more than $(n-2)$ queries, each of which consists of two integers $p$ and $q$ ($0 \le p/q \le 1\,000, 1 \le q \le 1\,000$). He will tell you the total length of the points on the line $x=p/q$ that lie inside or on the boundary of the polygon, which can be represented as $r/s$ with two integers $r$ and $s$ ($r \ge 0, s \ge 1, \gcd(r,s) = 1$). Here $\gcd(r,s)$ is the greatest common divisor of $r$ and $s$.

You need to find the area of the polygon, which can also be represented as $u/v$ with two integers $u$ and $v$ ($u \ge 0, v \ge 1, \gcd(u,v) = 1$).

The polygon and the order of the vertices are determined before the start of the interaction and do not depend on your queries. In other words, the interactor is not adaptive.

**Input**

The first line of the input contains an integer $T$ ($1 \le T \le 1\,000$), indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($3 \le n \le 1\,000$), indicating the number of vertices of the polygon.

Then $n$ lines follow, each containing two integers $x$ and $y$ ($0 \le x,y \le 1\,000$) that give the coordinates $(x, y)$ of the vertices of the polygon in shuffled order.

The polygon is simple, i.e., its vertices are distinct and no two edges of the polygon intersect or touch, except that consecutive edges touch at their common vertex. In addition, no two consecutive edges are collinear.

It is guaranteed that the sum of $n$ over all test cases does not exceed $1\,000$.



**Interaction**

If you want to ask a query, output one line. First output ? followed by a space, then output two integers $p$ and $q$ ($0 \le p/q \le 1\,000, 1 \le q \le 1\,000$). After flushing your output, your program should read two integers $r$ and $s$ ($r \ge 0, s \ge 1, \gcd(r,s) = 1$), indicating the answer to your query.

If you want to guess the area of the polygon, output one line. First output ! followed by a space, then output two integers $u$ and $v$ ($u \ge 0, v \ge 1, \gcd(u,v) = 1$), indicating that the area of the polygon is $u/v$. After flushing your output, your program should continue processing the next test case, or exit immediately if there are no more test cases. Note that your guess does not count as a query.

To flush your output, you can use:

-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java and Kotlin.
-   sys.stdout.flush() in Python.

Example Input：
2
4
0 0
1 3
1 1
3 0

2 1

3
0 0
999 1000
1000 999

1999 999000
Example Output：
2
4
0 0
1 3
1 1
3 0

2 1

3
0 0
999 1000
1000 999

1999 999000

**Note**

For the first sample case, there are three candidate polygons, shown in the figure below. Only the leftmost one meets the answer $2$ to the query $x=1$, and thus the area is $3$. The other two have the answer $3$ to the query $x=1$.

![](https://espresso.codeforces.com/bfe10f6dc813746a1129d86068ec1874aa595fb8.png)

For the second sample case, there is only one candidate polygon, and thus the area is $1999/2$.

Note that the order of the vertices shown in the sample case may not be consistent with the actual provided.

The blank lines in the sample case are added for readability. In your output, extra spaces or blank lines will be ignored.


## Solution


import sys
import math

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def get_area(n, points):
    x_coords = sorted(set([point[0] for point in points]))
    area = 0
    for i in range(len(x_coords) - 1):
        query_x = (x_coords[i] + x_coords[i + 1]) / 2
        query_x = int(query_x * 1000)
        print("?", query_x, 1000, flush=True)
        r, s = map(int, input().split())
        area += r / s * (x_coords[i + 1] - x_coords[i])
    return area

t = int(input())
for _ in range(t):
    n = int(input())
    points = []
    for _ in range(n):
        x, y = map(int, input().split())
        points.append((x, y))
    area = get_area(n, points)
    u = int(area * 1000000)
    v = 1000000
    g = gcd(u, v)
    u //= g
    v //= g
    print("!", u, v, flush=True)



## CODE


import sys
import math

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def get_area(n, points):
    x_coords = sorted(set([point[0] for point in points]))
    area = 0
    for i in range(len(x_coords) - 1):
        query_x = (x_coords[i] + x_coords[i + 1]) / 2
        query_x = int(query_x * 1000)
        print("?", query_x, 1000, flush=True)
        r, s = map(int, input().split())
        area += r / s * (x_coords[i + 1] - x_coords[i])
    return area

t = int(input())
for _ in range(t):
    n = int(input())
    points = []
    for _ in range(n):
        x, y = map(int, input().split())
        points.append((x, y))
    area = get_area(n, points)
    u = int(area * 1000000)
    v = 1000000
    g = gcd(u, v)
    u //= g
    v //= g
    print("!", u, v, flush=True)


### Explanation
The code uses a simple algorithm to calculate the area of the polygon. It first sorts the x-coordinates of the points and then queries the length of the polygon at the midpoint of each pair of consecutive x-coordinates. The area is then calculated by summing up the product of the length and the width of each strip. The result is then simplified by dividing both the numerator and the denominator by their greatest common divisor.
## Token
[359, 1093, 1452]
 ### 

## Question


(H)
Byteland has $n$ cities, and there is a bidirectional road between any two cities. There are exactly $(n-2)$ roads with scenery, and if properly built scenery on one more road, one can always travel from one city to the others only through roads with scenery.

Little Q is initially located in the city $1$ with a guide map in his hand, showing some of the roads in Byteland, and starts his journey in Byteland. Assuming he is currently in the city $u$:

-   If he can walk along a road on the guide map to a city $v$ that he has not yet visited, he will choose the smallest such $v$ and walk along the road to city $v$. Note that city $1$ is visited initially;
-   Otherwise, he will return along the road he took to reach city $u$ for the first time, unless he is already in city $1$, in which case the journey ends immediately.

Little Q wants to visit all the sceneries while traveling on no more than one different road without sceneries. You need to help him calculate how many different guide maps can satisfy his requirements. Two guide maps are considered different if and only if there is a road on one map that does not appear on the other.

Since the answer may be large, output it modulo $998\,244\,353$.

**Input**

The first line contains an integer $n$ ($2 \le n \le 2 \times 10^5$), indicating the number of cities.

Then $(n-2)$ lines follow, the $i$\-th of which contains two integers $u$ and $v$ ($1 \le u, v \le n$), indicating that the $i$\-th scenery is on the road between the $u$\-th and the $v$\-th cities. It is guaranteed that if properly built scenery on one more road, one can always travel from one city to the others only through roads with scenery.

**Output**

Output a line containing an integer, indicating the number of different guide maps modulo $998\,244\,353$.

Example Input1：
4
1 4
2 3
Example Output1：
6

Example Input2：
2
Example Output2：
2

**Note**

For the first sample case, one of the feasible guide maps shows $4$ roads $(1,4)$, $(2,3)$, $(1,2)$, and $(1,3)$. Little Q will visit the cities $1 \rightarrow 2 \rightarrow 3 \rightarrow 2 \rightarrow 1 \rightarrow 4 \rightarrow 1$ in order following this guide map and visit the sceneries on roads $(1,4)$ and $(2,3)$ while traveling on only one road $(1,2)$ without sceneries.

For the second sample case, there is no road with scenery, and thus a feasible guide map can not only include but also exclude the only existing road $(1,2)$.


## Solution


import sys
input = sys.stdin.readline

mod = 998244353

def find(x):
    if fa[x] == x:
        return x
    fa[x] = find(fa[x])
    return fa[x]

def dfs(x, fa):
    sz[x] = 1
    for y in g[x]:
        if y != fa:
            dfs(y, x)
            sz[x] += sz[y]

n = int(input())
fa = list(range(n + 1))
g = [[] for _ in range(n + 1)]
sz = [0] * (n + 1)

for _ in range(n - 2):
    x, y = map(int, input().split())
    g[x].append(y)
    g[y].append(x)
    fa[find(x)] = find(y)

dfs(1, 0)

ans = 0
for i in range(2, n + 1):
    ans = (ans + sz[i] * (n - sz[i])) % mod

ans = (ans * 2) % mod
if n > 2:
    ans = (ans + n) % mod
else:
    ans = (ans + 2) % mod

print(ans)



## CODE


import sys
input = sys.stdin.readline

mod = 998244353

def find(x):
    if fa[x] == x:
        return x
    fa[x] = find(fa[x])
    return fa[x]

def dfs(x, fa):
    sz[x] = 1
    for y in g[x]:
        if y != fa:
            dfs(y, x)
            sz[x] += sz[y]

n = int(input())
fa = list(range(n + 1))
g = [[] for _ in range(n + 1)]
sz = [0] * (n + 1)

for _ in range(n - 2):
    x, y = map(int, input().split())
    g[x].append(y)
    g[y].append(x)
    fa[find(x)] = find(y)

dfs(1, 0)

ans = 0
for i in range(2, n + 1):
    ans = (ans + sz[i] * (n - sz[i])) % mod

ans = (ans * 2) % mod
if n > 2:
    ans = (ans + n) % mod
else:
    ans = (ans + 2) % mod

print(ans)


### Explanation
The problem is to calculate the number of different guide maps that can satisfy Little Q's requirements. We can use a union-find algorithm to find the connected components of the graph, and then use a depth-first search (DFS) algorithm to calculate the size of each component. The answer is then calculated based on the sizes of the components.

First, we initialize the union-find data structure and the adjacency list of the graph. Then, we read the input and add edges to the graph and update the union-find data structure.

Next, we perform a DFS from node 1 to calculate the size of each component. We use the `sz` array to store the size of each component.

Finally, we calculate the answer based on the sizes of the components. For each component, we add the product of its size and the size of the remaining nodes to the answer. We multiply the answer by 2 to account for the two possible directions of the edge. If there are more than two nodes, we add the number of nodes to the answer to account for the case where the guide map includes all edges. Otherwise, we add 2 to the answer to account for the two possible guide maps.
## Token
[511, 734, 1245]
 ### 

## Question


(I)
Little Q has planted a tree, which initially has only one root node $1$, which is also a leaf node. Every morning, each leaf node $u$ will sprout two branches:

-   One branch connects node $u$ and node $2u$, with a length of $a_{2u}$;
-   The other branch connects node $u$ and node $2u+1$, with a length of $a_{2u+1}$.

After that, node $u$ is no longer a leaf node, and nodes $2u$ and $2u+1$ become new leaf nodes. This tree will grow for $n$ days, ultimately forming a tree with $\left(2^{n+1}-1\right)$ nodes, of which $2^n$ nodes are leaf nodes.

During these $n$ days, every afternoon, Little Q can choose one of the branches that have already grown to "prune", modifying its length to any positive integer (possibly less than or greater than the original one), or he can choose not to prune any branches at all.

Little Q hopes that after the tree has fully grown, the sum of the lengths of the branches on the simple path from the root node to each leaf node will be pairwise different. You need to find the minimum number of branches that need to be pruned, or indicate that it is impossible to achieve this.

**Input**

The first line of the input contains an integer $T$ ($1 \leq T \leq 1\,000$) indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($1 \le n \le 10$), indicating the number of days the tree grows.

The second line contains $\left(2^{n+1}-2\right)$ integers $a_2, a_3, \ldots, a_{2^{n+1}-1}$ ($1 \le a_i \le 10^8$), indicating the length of the branches.

It is guaranteed that the number of test cases with $n$ greater than $7$ does not exceed $10$.

**Output**

For each test case, output a line containing an integer, indicating the minimum number of branches that need to be pruned if it is possible to meet the requirement, or $-1$ otherwise.

Example Input1：
2
1 2 4 3 2 1
Example Output1：
1

Example Input2：
2
1 2 3 3 2 1
Example Output2：
2

Example Input3：
2
1 2 3 3 1 1
Example Output3：
-1


## Solution


import sys
input = sys.stdin.readline

def dfs(u(dep), cur):
    if u >= 2**(n+1) - 1:
        s.add(cur)
        return
    dfs(2*u+1, cur+a[2*u+1])
    dfs(2*u+2, cur+a[2*u+2])

T = int(input())
for _ in range(T):
    n = int(input())
    a = [0] + list(map(int, input().split()))
    s = set()
    dfs(0, 0)
    if len(s) < 2**n:
        print(-1)
    else:
        ans = 0
        for i in range(n):
            s.clear()
            for j in range(2**(i+1)-1, 2**(i+2)-1):
                dfs(j, 0)
            if len(s) < 2**(n-i):
                ans += 1
                a[2**(i+1)] = 10**9
        print(ans)



## CODE


import sys
input = sys.stdin.readline

def dfs(u(dep), cur):
    if u >= 2**(n+1) - 1:
        s.add(cur)
        return
    dfs(2*u+1, cur+a[2*u+1])
    dfs(2*u+2, cur+a[2*u+2])

T = int(input())
for _ in range(T):
    n = int(input())
    a = [0] + list(map(int, input().split()))
    s = set()
    dfs(0, 0)
    if len(s) < 2**n:
        print(-1)
    else:
        ans = 0
        for i in range(n):
            s.clear()
            for j in range(2**(i+1)-1, 2**(i+2)-1):
                dfs(j, 0)
            if len(s) < 2**(n-i):
                ans += 1
                a[2**(i+1)] = 10**9
        print(ans)


### Explanation
This problem can be solved by simulating the process of tree growth and pruning. We use a depth-first search (DFS) function to traverse the tree and calculate the sum of the lengths of the branches on the simple path from the root node to each leaf node. We store these sums in a set to ensure they are pairwise different. If the size of the set is less than the expected number of leaf nodes, it means that some sums are equal, and we need to prune some branches. We iterate through the levels of the tree, starting from the root, and for each level, we check if the sums of the lengths of the branches are pairwise different. If not, we prune a branch by changing its length to a large value and increment the answer. Finally, we print the minimum number of branches that need to be pruned.
## Token
[401, 663, 1064]
 ### 

## Question


(J)
The 2024 League of Legends World Championship culminated in an epic clash between two titans of professional League of Legends on November 2, 2024. Bilibili Gaming, after dominating the LPL with two domestic titles in 2024, undoubtedly carried the hopes of China's premier league that had endured three years without lifting the Summoner's Cup. In their way stood T1, who had qualified as LCK's fourth seed but proved their championship mettle through their tournament run. And there he was — Faker, the man revered as "the highest mountain and the longest river" — still standing at the center of LoL's greatest stage as if time itself had learned to bow before him. With four crowns already weighing heavy in his legacy, Faker somehow made the hunt for a fifth feel less like ambition and more like destiny. Now, beneath the towering dome of London's O2 Arena, the stakes were immense for both teams: BLG aimed to end the LPL's drought and cement their remarkable 2024 campaign, while T1 sought to defend their title and further establish their dynasty.

In an electrifying best-of-five series that pushed both teams to their limits, T1 emerged victorious over BLG with a hard-fought 3-2 triumph, clinching their fifth world championship. True to the tournament's official slogan "Make Them Believe", T1 mounted an incredible comeback from a 1-2 deficit, reaffirming once again why they remain a seemingly insurmountable obstacle for LPL teams in the international arena.

As we trace back through the journey of these two finalist teams, it all started in that fateful knockout stage, where eight teams competed in a single-elimination tournament: LNG Esports, Weibo Gaming, Hanwha Life Esports, Bilibili Gaming, Top Esports, T1, Gen.G, and FlyQuest. In an eight-team single-elimination tournament format, teams were seeded into the bracket based on their performance in the Swiss stage to face off in head-to-head matches where the loser is immediately eliminated. The tournament progresses through three rounds: Quarterfinals with eight teams, Semifinals with four teams, and the Finals with two teams, ultimately crowning a single champion.

![](https://espresso.codeforces.com/ded80cb9295790e3e0ab8ebf1971ef80a8c2ce2b.png) Figure: Eight-Team Single-Elimination Tournament Bracket

Although Worlds 2024 has irretrievably passed into history, we can still craft our own version of the story. For this problem, you will simulate a hypothetical knockout stage using the same eight-team single-elimination format. You will be given the names and the strength values of the eight teams in order from top to bottom of the Quarterfinals bracket (shown in the leftmost column in Figure), and both the names and the strength values are guaranteed to be pairwise different. When two teams compete, the team with the higher strength value always wins, while the losing team is eliminated. For two teams competing in the Finals, the team that wins is designated as the champion, while the other team is designated as the runner-up.

Your task is to find the champion team and the runner-up team in the hypothetical knockout stage.

**Input**

The input contains eight lines, the $i$\-th of which contains a string $S_i$ ($1 \leq |S_i| \leq 3$) and an integer $t_i$ ($1 \leq t_i \leq 100$), indicating the name and the strength value of the $i$\-th team from top to bottom of the Quarterfinals bracket.

It is guaranteed that all team names contain only uppercase English letters or decimal digits, and both the names and the strength values are pairwise different.

**Output**

Output "A beats B" (without quotes) in one line, where A is the name of the champion team and B is the name of the runner-up team.

Example Input1：
LNG 55
WBG 65
HLE 70
BLG 75
TES 48
T1 80
GEN 60
FLY 50
Example Output1：
T1 beats BLG

Example Input2：
LNG 55
WBG 65
HLE 70
BLG 81
TES 48
T1 80
GEN 60
FLY 50
Example Output2：
BLG beats T1

## Solution


def find_champion(teams):
    # Simulate the quarterfinals
    winners = []
    for i in range(0, 8, 2):
        if teams[i][1] > teams[i+1][1]:
            winners.append(teams[i])
        else:
            winners.append(teams[i+1])

    # Simulate the semifinals
    semifinal_winners = []
    for i in range(0, 4, 2):
        if winners[i][1] > winners[i+1][1]:
            semifinal_winners.append(winners[i])
        else:
            semifinal_winners.append(winners[i+1])

    # Simulate the finals
    if semifinal_winners[0][1] > semifinal_winners[1][1]:
        champion = semifinal_winners[0]
        runner_up = semifinal_winners[1]
    else:
        champion = semifinal_winners[1]
        runner_up = semifinal_winners[0]

    return champion, runner_up

# Read the input
teams = []
for _ in range(8):
    name, strength = input().split()
    teams.append((name, int(strength)))

# Find the champion and runner-up
champion, runner_up = find_champion(teams)

# Print the result
print(f"{champion[0]} beats {runner_up[0]}")



## CODE


def find_champion(teams):
    # Simulate the quarterfinals
    winners = []
    for i in range(0, 8, 2):
        if teams[i][1] > teams[i+1][1]:
            winners.append(teams[i])
        else:
            winners.append(teams[i+1])

    # Simulate the semifinals
    semifinal_winners = []
    for i in range(0, 4, 2):
        if winners[i][1] > winners[i+1][1]:
            semifinal_winners.append(winners[i])
        else:
            semifinal_winners.append(winners[i+1])

    # Simulate the finals
    if semifinal_winners[0][1] > semifinal_winners[1][1]:
        champion = semifinal_winners[0]
        runner_up = semifinal_winners[1]
    else:
        champion = semifinal_winners[1]
        runner_up = semifinal_winners[0]

    return champion, runner_up

# Read the input
teams = []
for _ in range(8):
    name, strength = input().split()
    teams.append((name, int(strength)))

# Find the champion and runner-up
champion, runner_up = find_champion(teams)

# Print the result
print(f"{champion[0]} beats {runner_up[0]}")


### Explanation
This code simulates a single-elimination tournament with 8 teams. The teams are inputted with their names and strength values. The code then simulates the quarterfinals, semifinals, and finals, with the team having the higher strength value winning each match. The champion and runner-up teams are then determined and printed out. The code uses a simple and straightforward approach to simulate the tournament, with each round being simulated separately.
## Token
[393, 1030, 1423]
 ### 

