## Question
(A)
You want to build a computer to achieve a specific functionality: Given an integer $x$, determine whether $x$ lies within the interval $[L, R]$. To accomplish this, you designed a directed acyclic graph (DAG) with edge weights of $0$ and $1$, which contains a starting node with an indegree of $0$ and an ending node with an outdegree of $0$. By starting from the starting node and following a path to the ending node, the sequence of the traversed edge weights forms a binary representation of an integer within the range $[L, R]$ without leading zeros. Every integer within the range $[L, R]$ must correspond to exactly one unique path in this graph. In this way, you can determine whether an integer lies within the range $[L, R]$ by checking if its binary representation can be constructed by traversing this DAG.
Clearly, you could separate the corresponding path for each integer into individual chains. However, you realized that for a large range, such a DAG would require too many nodes, and the computer you built with only 256 MiB of memory cannot store it. Therefore, you need to compress this DAG, allowing different paths to share nodes, in order to reduce the number of nodes and edges. Formally, you need to construct a DAG with no more than $100$ nodes, where each node has an outdegree of at most $200$. The DAG must have edge weights of $0$ and $1$, with exactly one starting node with an in-degree of $0$ and one ending node with an out-degree of $0$. Every integer in the range $[L, R]$ must correspond to **exactly** one unique path from the start to the end in this DAG, and no path should represent any integer outside the range $[L, R]$. Note that none of the binary sequences formed by any path in the graph should have leading zeros. There may be two edges with different weights between two nodes.
**Input**
A single line containing two positive integers $L, R$ ($1 \le L \le R \le 10^6$).

**Output**
The first line should output the number of nodes $n$ ($1 \le n \le 100$).
For the next $n$ lines, the $i$\-th line should start with an integer $k$ ($0 \le k \le 200$), representing the number of outgoing edges from node $i$. Then output $2 \cdot k$ integers $a_{i,k}, v_{i,k}$ ($1 \le a_{i,k} \le n$, $a_{i,k} \neq i$, $v_{i,k} \in \{0, 1\}$), which means that node $i$ has a directed edge with weight $v_{i,k}$ to node $a_{i,k}$. You must ensure that the output represents a directed acyclic graph that satisfies the requirements.

Example Input：
5 7
Example Output：
8
3 2 1 3 1 4 1
1 5 0
1 6 1
1 7 1
1 8 1
1 8 0
1 8 1
0


## Solution


def solve(L, R):
    nodes = []
    edges = []

    def add_node():
        nodes.append(len(nodes))
        edges.append([])

    def add_edge(u, v, w):
        edges[u].append((v, w))

    add_node()  # start node
    add_node()  # end node

    max_len = max(len(bin(L)[2:]), len(bin(R)[2:]))

    def build_tree(node, depth):
        if depth == max_len:
            add_edge(node, 1, 0)
            return
        add_node()
        add_edge(node, len(nodes) - 1, 0)
        build_tree(len(nodes) - 1, depth + 1)
        add_node()
        add_edge(node, len(nodes) - 1, 1)
        build_tree(len(nodes) - 1, depth + 1)

    build_tree(0, 0)

    def delete_invalid(node, depth, val):
        if depth == max_len:
            if val < L or val > R:
                for i in range(len(edges[node])):
                    if edges[node][i][0] == 1:
                        edges[node].pop(i)
                        break
            return
        for i in range(len(edges[node])):
            if edges[node][i][1] == 0:
                delete_invalid(edges[node][i][0], depth + 1, val)
            else:
                delete_invalid(edges[node][i][0], depth + 1, val | (1 << (max_len - depth - 1)))

    delete_invalid(0, 0, 0)

    # compress nodes
    node_mapping = {}
    new_nodes = []
    new_edges = []

    def dfs(node):
        if node in node_mapping:
            return
        node_mapping[node] = len(new_nodes)
        new_nodes.append(node)
        for v, w in edges[node]:
            dfs(v)

    dfs(0)

    for node in new_nodes:
        new_edges.append([])
        for v, w in edges[node]:
            new_edges[-1].append((node_mapping[v], w))

    print(len(new_nodes))
    for i in range(len(new_nodes)):
        print(len(new_edges[i]), end=' ')
        for v, w in new_edges[i]:
            print(v + 1, w, end=' ')
        print()

L, R = map(int, input().split())
solve(L, R)



## CODE


def solve(L, R):
    nodes = []
    edges = []

    def add_node():
        nodes.append(len(nodes))
        edges.append([])

    def add_edge(u, v, w):
        edges[u].append((v, w))

    add_node()  # start node
    add_node()  # end node

    max_len = max(len(bin(L)[2:]), len(bin(R)[2:]))

    def build_tree(node, depth):
        if depth == max_len:
            add_edge(node, 1, 0)
            return
        add_node()
        add_edge(node, len(nodes) - 1, 0)
        build_tree(len(nodes) - 1, depth + 1)
        add_node()
        add_edge(node, len(nodes) - 1, 1)
        build_tree(len(nodes) - 1, depth + 1)

    build_tree(0, 0)

    def delete_invalid(node, depth, val):
        if depth == max_len:
            if val < L or val > R:
                for i in range(len(edges[node])):
                    if edges[node][i][0] == 1:
                        edges[node].pop(i)
                        break
            return
        for i in range(len(edges[node])):
            if edges[node][i][1] == 0:
                delete_invalid(edges[node][i][0], depth + 1, val)
            else:
                delete_invalid(edges[node][i][0], depth + 1, val | (1 << (max_len - depth - 1)))

    delete_invalid(0, 0, 0)

    # compress nodes
    node_mapping = {}
    new_nodes = []
    new_edges = []

    def dfs(node):
        if node in node_mapping:
            return
        node_mapping[node] = len(new_nodes)
        new_nodes.append(node)
        for v, w in edges[node]:
            dfs(v)

    dfs(0)

    for node in new_nodes:
        new_edges.append([])
        for v, w in edges[node]:
            new_edges[-1].append((node_mapping[v], w))

    print(len(new_nodes))
    for i in range(len(new_nodes)):
        print(len(new_edges[i]), end=' ')
        for v, w in new_edges[i]:
            print(v + 1, w, end=' ')
        print()

L, R = map(int, input().split())
solve(L, R)


### Explanation
The solution first builds a binary tree that represents all possible binary numbers with a given maximum length. Then it deletes the invalid nodes that do not fall within the given range. Finally, it compresses the nodes to remove any redundant nodes and outputs the compressed graph. The graph is represented as an adjacency list, where each node is associated with a list of its outgoing edges. The edges are represented as pairs of the destination node and the edge weight. The node IDs are 1-indexed in the output.
## Token
[622, 778, 1400]
 ### 

## Question


(B)
A simple polygon is a closed curve in the Euclidean plane consisting of straight line segments meeting endto-end. Two line segments meet at every endpoint, and there are no other points of intersection between the line segments.
Simple polygons can be categorized into two types: convex and concave. A convex polygon is defined as a polygon where, for any two points inside it, all points on the line segment between these two points also lie inside the polygon, either within its interior or on its boundary. A simple polygon that is not convex is called a concave polygon. As shown in the figure below, the left one is a convex polygon, while the right one is a concave polygon.

Now, given n points such that all points are distinct and no three points are collinear, your task is to select some of these n points (maybe all of them) and connect them in any order to form a concave polygon with a strictly positive area. You need to determine the maximum possible area of the concave polygon that can be formed.

**Input**
The first line contains an integer T \ (1 \leq T \leq 10^{4}), indicating the number of test cases.
For each test case, the first line contains a positive integer n （3 \leq n \leq 10^{5}, indicating the number ofpoints.
The next n lines each contain two integers x_i, y_i（-10^{9} \leq x_i, y_i \leq 10^{9}, representing the coordinates ofeach point. It is guaranteed that all points are distinct, and no three points are collinear.
The sum of n over all test cases does not exceed 2 \times 10^{5}.


**Output**
For each test case, if it is not possible to form a concave polygon with a strictly positive area, output −1;otherwise, output a positive integer representing twice the maximum area of the concave polygon that can be formed. It can be proven that this answer is always a positive integer.

Example Input:
2
6
-2 0
1 -2
5 2
0 4
1 2
3 1
4
0 0
1 0
0 1
1 1
Example Output:
40
-1


## Solution


import sys

def cross_product(p1, p2, p3):
    return (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0])

def convex_hull(points):
    n = len(points)
    if n < 3:
        return []

    hull = []
    l = 0
    for i in range(1, n):
        if points[i][0] < points[l][0]:
            l = i

    p = l
    q = 0
    while True:
        hull.append(points[p])
        q = (p + 1) % n

        for i in range(n):
            if cross_product(points[p], points[i], points[q]) < 0:
                q = i

        p = q
        if p == l:
            break

    return hull

def polygon_area(points):
    n = len(points)
    area = 0
    for i in range(n):
        j = (i + 1) % n
        area += points[i][0] * points[j][1]
        area -= points[j][0] * points[i][1]
    return abs(area)

def solve():
    n = int(input())
    points = []
    for _ in range(n):
        x, y = map(int, input().split())
        points.append((x, y))

    hull = convex_hull(points)
    if len(hull) == n:
        print(-1)
    else:
        print(polygon_area(hull))

if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        solve()



## CODE


import sys

def cross_product(p1, p2, p3):
    return (p2[0] - p1[0]) * (p3[1] - p1[1]) - (p2[1] - p1[1]) * (p3[0] - p1[0])

def convex_hull(points):
    n = len(points)
    if n < 3:
        return []

    hull = []
    l = 0
    for i in range(1, n):
        if points[i][0] < points[l][0]:
            l = i

    p = l
    q = 0
    while True:
        hull.append(points[p])
        q = (p + 1) % n

        for i in range(n):
            if cross_product(points[p], points[i], points[q]) < 0:
                q = i

        p = q
        if p == l:
            break

    return hull

def polygon_area(points):
    n = len(points)
    area = 0
    for i in range(n):
        j = (i + 1) % n
        area += points[i][0] * points[j][1]
        area -= points[j][0] * points[i][1]
    return abs(area)

def solve():
    n = int(input())
    points = []
    for _ in range(n):
        x, y = map(int, input().split())
        points.append((x, y))

    hull = convex_hull(points)
    if len(hull) == n:
        print(-1)
    else:
        print(polygon_area(hull))

if __name__ == "__main__":
    t = int(input())
    for _ in range(t):
        solve()


### Explanation
To find the maximum possible area of a concave polygon, we use the concept of convex hull. The convex hull of a set of points is the smallest convex polygon that contains all the points. We use the Graham's scan algorithm to find the convex hull. After finding the convex hull, we calculate its area using the Shoelace formula. If the number of points in the convex hull is equal to the total number of points, it means that all points lie on the convex hull and it's not possible to form a concave polygon with a strictly positive area, so we output -1. Otherwise, we output twice the area of the convex hull.
## Token
[519, 566, 1085]
 ### 

## Question


(C)
In some regions, people are more accustomed to giving directions using cardinal directions, such as: go south to the second intersection, then head east to the first intersection. However, due to the complex road network planning in Harbin, many streets do not align perfectly with cardinal directions. Thus, if you provide directions using absolute directions to someone who has lived in Harbin for a long time, they may struggle to understand your intended route.

In Harbin, people are more accustomed to using relative directions to give guidance. For the same location, a Harbin resident might first instruct you to face south, and then say: walk straight along the road to the second intersection, then turn left, and then straight to the first intersection.

To address this difference, you decide to write a program that converts the direction-giving style using cardinal directions into the style preferred by Harbin residents. Of course, using a real map of Harbin would be too complicated, so in this problem, you can assume the map is an infinitely large grid.

**Input**

The first line contains an integer $T$ ($1 \le T \le 10^4$), indicating the number of test cases.

For each test case, the first line contains an integer $n$ ($1 \le n \le 10$), indicating the number of direction instructions.

The next $n$ lines each describe an instruction in absolute position, consisting of a character $d$ ($d\in\{\texttt{N}, \texttt{S}, \texttt{W}, \texttt{E}\}$) and an integer $x$ ($1 \le x \le 10$), indicating "go to the $x$\-th intersection in the $d$ direction." Here, $\texttt{N}$ represents north, $\texttt{S}$ represents south, $\texttt{W}$ represents west, and $\texttt{E}$ represents east.

It is guaranteed that two consecutive instructions will not have the same direction or opposite directions (north and south are opposite, as are west and east).

**Output**

For each test case, the first line outputs an integer $m$ ($1 \le m \le 20$) and a character $f$ ($f \in \{\texttt{N}, \texttt{S}, \texttt{W}, \texttt{E}\}$), representing the number of instructions in Harbin style and the initial facing direction, with the same meanings for directions as in the input.

Next, output $m$ lines. Each line starts with a character $g \in \{\texttt{Z}, \texttt{L}, \texttt{R}\}$, where $\texttt{Z}$ means to go straight, $\texttt{L}$ means to turn left, and $\texttt{R}$ means to turn right. If the character is $\texttt{Z}$, the line must also include an integer $y$ ($1 \le y \le 100$), representing going straight to the $y$\-th intersection. The first output instruction must start with $\texttt{Z}$. Consecutive instructions cannot have the same character $g$, and $\texttt{L}$ and $\texttt{R}$ instructions cannot be adjacent.

In this problem, you do not need to minimize $m$. If there are multiple ways to reach the same destination, any valid solution is acceptable.

Example Input：
1
2
S 2
E 1
Example Output：
3 S
Z 2
L
Z 1


## Solution


def convert_directions():
    num_test_cases = int(input())
    for _ in range(num_test_cases):
        num_instructions = int(input())
        instructions = []
        for _ in range(num_instructions):
            direction, distance = input().split()
            instructions.append((direction, int(distance)))

        initial_direction = instructions[0][0]
        converted_instructions = []
        current_direction = initial_direction
        for direction, distance in instructions:
            if direction == current_direction:
                converted_instructions.append(("Z", distance))
            elif (direction == "N" and current_direction == "E") or \
                 (direction == "E" and current_direction == "S") or \
                 (direction == "S" and current_direction == "W") or \
                 (direction == "W" and current_direction == "N"):
                converted_instructions.append(("L",))
                converted_instructions.append(("Z", distance))
                current_direction = direction
            elif (direction == "N" and current_direction == "W") or \
                 (direction == "E" and current_direction == "N") or \
                 (direction == "S" and current_direction == "E") or \
                 (direction == "W" and current_direction == "S"):
                converted_instructions.append(("R",))
                converted_instructions.append(("Z", distance))
                current_direction = direction

        print(len(converted_instructions), initial_direction)
        for instruction in converted_instructions:
            if len(instruction) == 1:
                print(instruction[0])
            else:
                print(instruction[0], instruction[1])

convert_directions()



## CODE


def convert_directions():
    num_test_cases = int(input())
    for _ in range(num_test_cases):
        num_instructions = int(input())
        instructions = []
        for _ in range(num_instructions):
            direction, distance = input().split()
            instructions.append((direction, int(distance)))

        initial_direction = instructions[0][0]
        converted_instructions = []
        current_direction = initial_direction
        for direction, distance in instructions:
            if direction == current_direction:
                converted_instructions.append(("Z", distance))
            elif (direction == "N" and current_direction == "E") or \
                 (direction == "E" and current_direction == "S") or \
                 (direction == "S" and current_direction == "W") or \
                 (direction == "W" and current_direction == "N"):
                converted_instructions.append(("L",))
                converted_instructions.append(("Z", distance))
                current_direction = direction
            elif (direction == "N" and current_direction == "W") or \
                 (direction == "E" and current_direction == "N") or \
                 (direction == "S" and current_direction == "E") or \
                 (direction == "W" and current_direction == "S"):
                converted_instructions.append(("R",))
                converted_instructions.append(("Z", distance))
                current_direction = direction

        print(len(converted_instructions), initial_direction)
        for instruction in converted_instructions:
            if len(instruction) == 1:
                print(instruction[0])
            else:
                print(instruction[0], instruction[1])

convert_directions()


### Explanation
The solution uses a simple state machine to keep track of the current direction and convert the instructions accordingly. The initial direction is determined by the first instruction, and subsequent instructions are converted based on the current direction. The converted instructions are stored in a list and printed out at the end. The solution assumes that the input is valid and does not contain any errors.
## Token
[410, 836, 1246]
 ### 

## Question


(D)
You are given a character grid with $2$ rows and $n$ columns, where each cell contains a lowercase letter. You can start at any position in the grid and move several steps, with each step either to the right or downward, stopping at any cell. Concatenating the characters from the cells visited in order forms a string.

A string $S$ is called a double string if and only if there exists a non-empty string $T$ such that $S = TT$. For example, $\texttt{aa}$ and $\texttt{xyzxyz}$ are double strings, while $\texttt{a}$ and $\texttt{xyzyz}$ are not.

Given the character grid, find the length of the longest double string you can obtain.

**Input**

The first line contains an integer $n$ ($1 \le n \le 2 \times 10^5$), representing the number of columns in the character grid.

The next two lines contain two strings of length $n$ consisting only of lowercase English letters, representing the character grid.

**Output**

Output a single integer, representing the length of the longest double string you can obtain.

Example Input1：
5
abcab
acabc
Example Output1：
6

Example Input2：
6
babbaa
babaaa
Example Output2：
6

Example Input3：
2
ne
fu
Example Output3：
0

**Note**

In the first example, the longest double string can be obtained as follows (not unique):

$$
\begin{aligned} \underline{\texttt{abc}}\texttt{ab}\\ \texttt{ac}\underline{\texttt{abc}} \end{aligned}
$$


## Solution


def longest_double_string(n, grid):
    max_length = 0
    for i in range(n, 0, -1):
        seen = {}
        for j in range(n - i + 1):
            first = grid[0][j:j+i] + grid[1][j:j+i]
            if first[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[first[1:]] = True

            second = grid[0][j:j+i] + grid[1][j+1:j+i+1]
            if second[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[second[1:]] = True

            third = grid[0][j+1:j+i+1] + grid[1][j:j+i]
            if third[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[third[1:]] = True
    return max_length

n = int(input())
grid = [input(), input()]
print(longest_double_string(n, grid))



## CODE


def longest_double_string(n, grid):
    max_length = 0
    for i in range(n, 0, -1):
        seen = {}
        for j in range(n - i + 1):
            first = grid[0][j:j+i] + grid[1][j:j+i]
            if first[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[first[1:]] = True

            second = grid[0][j:j+i] + grid[1][j+1:j+i+1]
            if second[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[second[1:]] = True

            third = grid[0][j+1:j+i+1] + grid[1][j:j+i]
            if third[:i] in seen:
                max_length = max(max_length, 2 * i)
            seen[third[1:]] = True
    return max_length

n = int(input())
grid = [input(), input()]
print(longest_double_string(n, grid))


### Explanation
This solution iterates through the grid from the longest possible string to the shortest. For each length `i`, it checks all possible substrings of length `i` and their shifted versions. It stores the substrings in a dictionary `seen` to keep track of the substrings we have seen so far. If a substring matches a substring we have seen before, it means we have found a double string of length `2 * i`, so we update the maximum length. The maximum length found is the length of the longest double string.
## Token
[357, 454, 811]
 ### 

## Question


(E)
Marble race is a fun way to play with marbles, and today you want to give it a try.

There are $n$ starting points on the negative half of the $x$\-axis, with the $i$\-th point located at $x_i$. There are $m$ marbles in total, where $m$ is an odd number, and the $i$\-th marble has a speed of $v_i$. In a race, each marble randomly chooses a starting point with equal probability, and different marbles can choose the same starting point. Then, all the marbles start moving simultaneously towards the positive direction of the $x$\-axis. Let $c_i$ be the starting point chosen by the $i$\-th marble. At time $t$, the coordinate of the $i$\-th marble is given by $x_{c_i} + v_i \cdot t$.

You are a unique marble race enthusiast and do not care which marble is the fastest. Instead, you want to find out the exact time when the **median** of all the $m$ marble coordinates reaches the origin (i.e., $x = 0$). The median of a sequence of length $m$ (where $m$ is odd) is defined as the element at the position $\frac{m+1}{2}$ when sorted in ascending order (indexing starts from $1$). Since the race has not yet started and the starting points are not yet determined, you are interested in the expected value of this time. To avoid floating-point errors, you only need to output the result modulo $10^9+7$ (see the output format for details).

**Input**

The first line contains two positive integers $n$ and $m$ ($1 \le n, m \le 500$, and $m$ is odd), representing the number of starting points and the number of marbles.

The second line contains $n$ integers $x_1, x_2, \ldots, x_n$ ($-10^9 \le x_i &lt; 0$), representing the coordinates of each starting point. It is guaranteed that all $x_i$ are distinct.

The third line contains $m$ integers $v_1, v_2, \ldots, v_m$ ($1 \le v_i \le 10^9$), representing the speed of each marble.

**Output**

Output a single integer, representing the expected time modulo $10^9+7$.

Formally, let $M=10^9+7$. It can be shown that the answer can be expressed as an irreducible fraction $\frac p q$, where $p$ and $q$ are integers and $q \not\equiv 0\pmod M$. Output the integer equal to $p\cdot q^{-1}\pmod M$, where $q^{-1}$ denotes the modular multiplicative inverse of $q$ modulo $M$. In other words, output such an integer $x$ that $0\le x &lt; M$ and $x\cdot q\equiv p\pmod M$. It can be proved that there is exactly one $x$ which meets the condition.

Example Input1：
2 3
-4 -5
1 2 3
Example Output1:
250000004

Example Input2：
3 3
-4 -5 -6
1 2 3
Example Output2：
500000006

Example Input3：
5 5
-4 -5 -6 -10 -2
1 2 3 2 4
Example Output3：
434986672

**Note**

For the first example, the speeds of the three marbles are $1, 2, 3$, respectively. Consider the initial positions of the three marbles:

-   $-4, -4, -4$: At $t=2$, the coordinates of the three marbles are $-2, 0, 2$, and the median is at the origin.
-   $-4, -4, -5$: At $t=2$, the coordinates are $-2, 0, 1$, and the median is at the origin.
-   $-4, -5, -4$: At $t=2.5$, the coordinates are $-1.5, 0, 3.5$, and the median is at the origin.
-   For $(-4, -5, -5)$, $(-5, -4, -4)$, $(-5, -4, -5)$, $(-5, -5, -4)$, $(-5, -5, -5)$, the median is at the origin at times $t=2.5$, $t=2$, $t=2$, $t=2.5$, $t=2.5$, respectively.

In summary, the expected time is $\frac{2 + 2 + 2.5 + 2.5 + 2 + 2 + 2.5 + 2.5}{8} = \frac{9}{4}$, so you need to output $9 \cdot 4^{-1} \bmod (10^9+7) = 250000004$.


## Solution


import sys

M = 10**9 + 7

def pow_mod(a, n):
    res = 1
    while n:
        if n & 1:
            res = res * a % M
        a = a * a % M
        n >>= 1
    return res

def inv(a):
    return pow_mod(a, M - 2)

def main():
    n, m = map(int, input().split())
    x = list(map(int, input().split()))
    v = list(map(int, input().split()))

    ans = 0
    for i in range(n):
        for j in range(m):
            cnt = 0
            for k in range(m):
                if v[j] > v[k]:
                    cnt += 1
                if v[j] == v[k] and j < k:
                    cnt += 1
            if cnt == m // 2:
                ans += -x[i] * inv(v[j]) % M
                ans %= M

    ans = ans * inv(n ** m) % M
    print(ans)

if __name__ == "__main__":
    main()



## CODE


import sys

M = 10**9 + 7

def pow_mod(a, n):
    res = 1
    while n:
        if n & 1:
            res = res * a % M
        a = a * a % M
        n >>= 1
    return res

def inv(a):
    return pow_mod(a, M - 2)

def main():
    n, m = map(int, input().split())
    x = list(map(int, input().split()))
    v = list(map(int, input().split()))

    ans = 0
    for i in range(n):
        for j in range(m):
            cnt = 0
            for k in range(m):
                if v[j] > v[k]:
                    cnt += 1
                if v[j] == v[k] and j < k:
                    cnt += 1
            if cnt == m // 2:
                ans += -x[i] * inv(v[j]) % M
                ans %= M

    ans = ans * inv(n ** m) % M
    print(ans)

if __name__ == "__main__":
    main()


### Explanation
We first consider each possible pair of starting point and marble speed, and calculate the time when the marble will reach the origin. If this marble is the median, we add the time to the answer. We use the modular multiplicative inverse to avoid floating-point errors. Finally, we divide the answer by the total number of possible combinations of starting points and marble speeds, which is n^m.
## Token
[334, 1210, 1544]
 ### 

## Question


(G)
You want to organize an online meeting on MeLink with $n$ participants numbered form $1$ to $n$. Each of these $n$ participants knows at least one other participant besides themselves, and the acquaintance relationship is mutual.

The organization process of the meeting is as follows: First, one person creates the meeting and joins it. Then, members who have already joined the meeting can invite some of their acquaintances who are not yet in the meeting, until all $n$ participants are present. However, there are $k$ participants who are currently busy debugging code; these people can be invited to the meeting but cannot create the meeting or invite others.

You want to determine if it is possible to get all $n$ participants into the meeting. If it is possible, determine an inviting plan.

**Input**

The first line contains three integers $n, m, k$ ($2 \le n \le 2 \times 10^5$, $1 \le m \le \min\{5 \times 10^5, \frac{n(n-1)}{2}\}$, $0 \le k \le n$), representing the number of participants, the number of acquaintance relationships, and the number of participants currently busy.

The second line contains $k$ integers $a_1, \ldots, a_k$ ($1 \le a_i \le n$), where the $i$\-th integer represents that participant $a_i$ is busy. These integers are all distinct. If $k=0$, this line will be empty, but not omitted.

The next $m$ lines each contain two integers $p_i$ and $q_i$ ($1 \le p_i, q_i \le n$, $p_i \neq q_i$), indicating that $p_i$ and $q_i$ know each other. The acquaintance relationships are mutual. It is guaranteed that the same acquaintance relationship will not appear more than once, and that every participant knows at least one other person.

**Output**

If it is impossible to organize a meeting with all $n$ participants, output $\texttt{No}$ in the first line.

If it is possible, output $\texttt{Yes}$ in the first line. Then, in the second line, output an integer $t$ ($1 \le t \le n$), representing the number of steps required to organize the meeting.

In the following $t$ lines, each line describes one step of organizing the meeting. In the $j$\-th line, first output an integer $x_j$ ($1 \leq x_j \leq n$). If $j=1$, $x_j$ represents the participant who creates the meeting; otherwise, $x_j$ must be a participant who has already joined the meeting. All $x_j$ must be distinct. Next, output an integer $y_j$ ($1 \leq y_j \leq n$), representing the number of participants invited by $x_j$ in this step. Finally, output $y_j$ integers $z_l$ ($1 \leq z_l \leq n$), representing the participants invited by $x_j$. All $z_l$ must be distinct, and no participant can be invited more than once during the entire process.

You do not need to minimize $t$; any valid plan is acceptable.

Example Input1：
4 5 2
3 4
1 2
1 3
2 3
3 4
2 4
Example Output1：
Yes
2
1 2 2 3
2 1 4

Example Input2：
4 5 3
2 4 3
1 2
1 3
2 3
3 4
2 4
Example Output2：
No


## Solution


from sys import stdin, stdout

def find(x):
    if fa[x] == x:
        return x
    fa[x] = find(fa[x])
    return fa[x]

def bfs(start):
    q = [start]
    flag[start] = 1
    step = []
    while q:
        x = q[0]
        q.pop(0)
        tmp = []
        for y in g[x]:
            if not flag[y]:
                flag[y] = 1
                q.append(y)
                tmp.append(y)
        if tmp:
            step.append([x, len(tmp)] + tmp)
    return step

n, m, k = map(int, stdin.readline().split())
a = list(map(int, stdin.readline().split()))
g = [[] for _ in range(n + 1)]
fa = [i for i in range(n + 1)]
flag = [0 for _ in range(n + 1)]

for i in range(m):
    x, y = map(int, stdin.readline().split())
    g[x].append(y)
    g[y].append(x)
    x, y = find(x), find(y)
    if x != y:
        fa[x] = y

for i in range(1, n + 1):
    g[i].sort(key=lambda x: 0 if x in a else 1)

for i in range(1, n + 1):
    if i not in a:
        f = find(i)
        step = bfs(i)
        if sum(flag) == n:
            stdout.write("Yes\n")
            stdout.write(str(len(step)) + "\n")
            for s in step:
                stdout.write(" ".join(map(str, s)) + "\n")
            exit()

stdout.write("No\n")


## CODE


from sys import stdin, stdout

def find(x):
    if fa[x] == x:
        return x
    fa[x] = find(fa[x])
    return fa[x]

def bfs(start):
    q = [start]
    flag[start] = 1
    step = []
    while q:
        x = q[0]
        q.pop(0)
        tmp = []
        for y in g[x]:
            if not flag[y]:
                flag[y] = 1
                q.append(y)
                tmp.append(y)
        if tmp:
            step.append([x, len(tmp)] + tmp)
    return step

n, m, k = map(int, stdin.readline().split())
a = list(map(int, stdin.readline().split()))
g = [[] for _ in range(n + 1)]
fa = [i for i in range(n + 1)]
flag = [0 for _ in range(n + 1)]

for i in range(m):
    x, y = map(int, stdin.readline().split())
    g[x].append(y)
    g[y].append(x)
    x, y = find(x), find(y)
    if x != y:
        fa[x] = y

for i in range(1, n + 1):
    g[i].sort(key=lambda x: 0 if x in a else 1)

for i in range(1, n + 1):
    if i not in a:
        f = find(i)
        step = bfs(i)
        if sum(flag) == n:
            stdout.write("Yes\n")
            stdout.write(str(len(step)) + "\n")
            for s in step:
                stdout.write(" ".join(map(str, s)) + "\n")
            exit()

stdout.write("No\n")

### Explanation
This code first uses union-find to find the connected components of the graph. Then it performs a BFS from each unbusy person in each component to find a valid inviting plan. If it finds a plan that invites all participants, it outputs the plan. Otherwise, it outputs "No". The BFS is modified to prioritize inviting busy people last, to ensure that they do not invite others.
## Token
[460, 893, 1353]
 ### 

## Question


(I)
You are a magician in a high-dimensional space, and you have an initial $n$\-dimensional hypercube with edge lengths $a_1, a_2, \dots, a_n$. For a $d$\-dimensional hypercube, the edge length sum is defined as $\sum_{i=1}^d a_i$, and its hypervolume is $\prod_{i=1}^d a_i$.

You want to obtain a hypercube with edge length sum $S$ and hypervolume $M$. To achieve this, you can perform both dimensional reduction and dimensional expansion operations on the current hypercube.

-   Dimensional Reduction: Remove a dimension.
-   Dimensional Expansion: Add a new dimension, with its edge length being any positive integer.

Both operations are very exhausting, so you want to determine the minimum number of operations required to obtain a hypercube with edge length sum $S$ and hypervolume $M$.

**Input**

The first line contains three integers $n, S, M$ ($1\le n \le 10^5$, $1 \le S, M \le 10^{10}$).

The second line contains $n$ integers, representing the initial edge lengths $a_i$ of the hypercube ($1 \le a_i \le 10^{10}$).

**Output**

Output a single integer representing the minimum number of operations required. If it is impossible to obtain a hypercube that meets the conditions, output $-1$.

Example Input1：
2 5 6
1 2
Example Output1：
2

Example Input2：
3 6 5
1 2 3
Example Output2:
3

Example Input3：
2 114514 735134400
114 514
Example Output3：
20

**Note**

For the first sample, one possible approach: first delete the dimension with edge length $1$, and then add a dimension with edge length $3$.


## Solution


import math

def prime_factors(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)
    if n > 1:
        factors.append(n)
    return factors

def min_operations(n, S, M, a):
    a_sum = sum(a)
    a_volume = math.prod(a)

    if a_volume > M or a_sum > S:
        return -1

    factors = prime_factors(M)
    factors.sort(reverse=True)

    new_a = []
    remaining_M = M
    remaining_S = S

    for ai in a:
        if remaining_M % ai == 0:
            new_a.append(ai)
            remaining_M //= ai
            remaining_S -= ai
        else:
            break

    for f in factors:
        while remaining_M % f == 0 and remaining_S >= f:
            new_a.append(f)
            remaining_M //= f
            remaining_S -= f

    while remaining_M > 1 and remaining_S >= remaining_M:
        new_a.append(remaining_M)
        remaining_S -= remaining_M
        remaining_M = 1

    if remaining_M > 1:
        return -1

    if remaining_S > 0:
        if len(new_a) < n:
            return -1
        while remaining_S > 0:
            if new_a[-1] == 1:
                return -1
            new_a[-1] -= 1
            remaining_S -= 1

    return len(new_a) - n

n, S, M = map(int, input().split())
a = list(map(int, input().split()))
print(min_operations(n, S, M, a))



## CODE


import math

def prime_factors(n):
    i = 2
    factors = []
    while i * i <= n:
        if n % i:
            i += 1
        else:
            n //= i
            factors.append(i)
    if n > 1:
        factors.append(n)
    return factors

def min_operations(n, S, M, a):
    a_sum = sum(a)
    a_volume = math.prod(a)

    if a_volume > M or a_sum > S:
        return -1

    factors = prime_factors(M)
    factors.sort(reverse=True)

    new_a = []
    remaining_M = M
    remaining_S = S

    for ai in a:
        if remaining_M % ai == 0:
            new_a.append(ai)
            remaining_M //= ai
            remaining_S -= ai
        else:
            break

    for f in factors:
        while remaining_M % f == 0 and remaining_S >= f:
            new_a.append(f)
            remaining_M //= f
            remaining_S -= f

    while remaining_M > 1 and remaining_S >= remaining_M:
        new_a.append(remaining_M)
        remaining_S -= remaining_M
        remaining_M = 1

    if remaining_M > 1:
        return -1

    if remaining_S > 0:
        if len(new_a) < n:
            return -1
        while remaining_S > 0:
            if new_a[-1] == 1:
                return -1
            new_a[-1] -= 1
            remaining_S -= 1

    return len(new_a) - n

n, S, M = map(int, input().split())
a = list(map(int, input().split()))
print(min_operations(n, S, M, a))


### Explanation
The approach used in the code is to first check if the initial hypercube's hypervolume is greater than M or its edge length sum is greater than S. If so, it is impossible to obtain a hypercube that meets the conditions, so return -1.

Next, we calculate the prime factors of M and sort them in descending order. We then try to use the initial hypercube's edge lengths to construct the new hypercube's edge lengths, and use the prime factors to fill in the remaining edge lengths. We also make sure that the sum of the new edge lengths does not exceed S.

If there are remaining factors in M, we add them as new edge lengths if possible. If the remaining factors cannot be used as new edge lengths, we return -1.

Finally, if there is still a remaining sum S, we try to reduce the last edge length by 1 until the remaining sum is 0. If the last edge length becomes 1 and there is still a remaining sum, we return -1.

The minimum number of operations required is then the difference between the number of new edge lengths and the initial number of edge lengths.
## Token
[620, 512, 1132]
 ### 

## Question


(J)
A new energy vehicle is equipped with $n$ batteries, where the $i$\-th battery has a capacity of $a_i$ units. Each unit of electricity allows the vehicle to travel exactly $1$ kilometer. The vehicle can only go forward, not in reverse. You can choose which battery to use for each kilometer driven.

Initially, all batteries are fully charged. During the journey, the vehicle will pass through $m$ charging stations. The $j$\-th charging station is located at $x_j$ kilometers from the starting point and can only recharge the $t_j$\-th battery. Each charging station provides an unlimited amount of electricity.

Your task is to determine the maximum distance the new energy vehicle can travel.

**Input**

The first line contains an integer $T$ ($1\le T\le 10^4$), representing the number of test cases.

For each test case, the first line contains two integers $n, m$ ($1\le n,m\le 10^5$), representing the number of batteries and the number of charging stations, respectively.

The second line contains $n$ integers $a_1,a_2,\ldots,a_n$ ($1\le a_i\le 10^9$), representing the capacity of each battery.

The next $m$ lines each contain two integers $x_j, t_j$ ($1\le x_j\le 10^9$, $1\le t_j\le n$), representing the position of each charging station and the battery it can recharge.

For each test case, it is guaranteed that $1\le x_1&lt;x_2&lt;\ldots&lt;x_m\le 10^9$. Either the sum of $n$ or the sum of $m$ over all test cases does not exceed $2\cdot 10^5$.

**Output**

For each test case, output an integer in a single line, representing the maximum distance the vehicle can travel.

Example Input：
2
3 1
3 3 3
8 1
2 2
5 2
1 2
2 1
Example Output：
12
9


## Solution


import sys

def solve():
    n, m = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))

    s = sum(a)
    v = [0] * n
    ans = 0

    for _ in range(m):
        x, y = map(int, sys.stdin.readline().split())
        y -= 1
        if x <= s:
            s -= x - ans
            ans = x
            s += a[y]
            a[y] = 0
        else:
            ans += s
            print(ans)
            return
    ans += s
    print(ans)

if __name__ == "__main__":
    T = int(input())
    for _ in range(T):
        solve()



## CODE


import sys

def solve():
    n, m = map(int, sys.stdin.readline().split())
    a = list(map(int, sys.stdin.readline().split()))

    s = sum(a)
    v = [0] * n
    ans = 0

    for _ in range(m):
        x, y = map(int, sys.stdin.readline().split())
        y -= 1
        if x <= s:
            s -= x - ans
            ans = x
            s += a[y]
            a[y] = 0
        else:
            ans += s
            print(ans)
            return
    ans += s
    print(ans)

if __name__ == "__main__":
    T = int(input())
    for _ in range(T):
        solve()


### Explanation
This problem is about finding the maximum distance a new energy vehicle can travel. To solve this problem, we need to keep track of the remaining capacity of the batteries and the distance we have traveled so far. When we encounter a charging station, we update the remaining capacity and the distance. If we can't reach the next charging station, we print the maximum distance we can travel. The greedy strategy is used here, which means we always try to travel as far as possible with the current batteries.
## Token
[273, 551, 824]
 ### 

## Question


(K)
You have given up programming and moved to the Sanjiang Plain to start farming. During your time working in the fields, you have adopted a regular daily schedule, and now you work **exactly** $m$ units of time each day. It is now harvest season, and you need to harvest and process $n$ types of crops. For crop type $i$, processing it for one unit of time will yield a profit of $w_i$. To make your daily work less monotonous, for each crop type $i$, the time spent processing it each day can range between $[l_i, r_i]$ inclusive as an integer.

At some day, the weather forecast says that there will be a heavy rain tomorrow and you can't work, so you need to adjust your schedule to quickly gather your crops today. Specifically, you can choose at most one type of crop and remove its daily time range restriction, allowing the time spent processing this crop to be any integer in the range $[0, m]$. The time ranges for all other crops remain unchanged. You have to work **exactly** $m$ units of time as well.

You want to determine the maximum profit you can earn today.

**Input**

The first line contains two integers $n$ and $m$ ($1 \le n \le 10^5$, $1 \le m \le 10^{11}$), representing the number of crop types and the length of the workday in units of time, respectively.

The next $n$ lines each contain three integers $w_i$, $l_i$, and $r_i$ ($1 \le w_i \le 10^6$, $1 \le l_i \le r_i \le 10^6$), indicating the profits and time constraints of the crops.

It is guaranteed that $\sum_{i=1}^n l_i \le m \le \sum_{i=1}^n r_i$.

**Output**

Output a single integer representing the maximum profit you can earn today.

Example Input：
5 17
2 3 4
6 1 5
8 2 4
4 3 3
7 5 5
Example Output：
109


## Solution


import sys

def calculate_max_profit(n, m, crops):
    total_min_time = sum(crop[1] for crop in crops)
    total_max_time = sum(crop[2] for crop in crops)
    total_profit = sum(crop[0] * crop[1] for crop in crops)

    crops.sort(key=lambda x: x[0], reverse=True)

    max_profit = float('-inf')
    prefix_sum_min_time = [0] * (n + 1)
    prefix_sum_profit = [0] * (n + 1)

    for i in range(n):
        prefix_sum_min_time[i + 1] = prefix_sum_min_time[i] + crops[i][1]
        prefix_sum_profit[i + 1] = prefix_sum_profit[i] + crops[i][0] * crops[i][1]

    for i in range(n):
        time_diff = m - total_min_time + crops[i][1]
        profit = prefix_sum_profit[n] - prefix_sum_profit[i + 1] + crops[i][0] * time_diff

        if time_diff >= crops[i][2]:
            max_profit = max(max_profit, profit)
        else:
            remaining_time = time_diff - crops[i][2]
            index = binary_search(crops, i + 1, n, remaining_time, prefix_sum_min_time)
            if index == -1:
                max_profit = max(max_profit, profit)
            else:
                max_profit = max(max_profit, profit - (prefix_sum_profit[index] - prefix_sum_profit[i + 1]) + (crops[i][0] * (prefix_sum_min_time[index] - prefix_sum_min_time[i + 1])))

    return max_profit


def binary_search(crops, start, end, target, prefix_sum_min_time):
    while start < end:
        mid = (start + end) // 2
        time_diff = prefix_sum_min_time[mid] - prefix_sum_min_time[start]
        if time_diff <= target:
            start = mid + 1
        else:
            end = mid
    return start if prefix_sum_min_time[start] - prefix_sum_min_time[start - 1] > target else -1


n, m = map(int, sys.stdin.readline().strip().split())
crops = []
for _ in range(n):
    w, l, r = map(int, sys.stdin.readline().strip().split())
    crops.append((w, l, r))

result = calculate_max_profit(n, m, crops)
print(result)



## CODE


import sys

def calculate_max_profit(n, m, crops):
    total_min_time = sum(crop[1] for crop in crops)
    total_max_time = sum(crop[2] for crop in crops)
    total_profit = sum(crop[0] * crop[1] for crop in crops)

    crops.sort(key=lambda x: x[0], reverse=True)

    max_profit = float('-inf')
    prefix_sum_min_time = [0] * (n + 1)
    prefix_sum_profit = [0] * (n + 1)

    for i in range(n):
        prefix_sum_min_time[i + 1] = prefix_sum_min_time[i] + crops[i][1]
        prefix_sum_profit[i + 1] = prefix_sum_profit[i] + crops[i][0] * crops[i][1]

    for i in range(n):
        time_diff = m - total_min_time + crops[i][1]
        profit = prefix_sum_profit[n] - prefix_sum_profit[i + 1] + crops[i][0] * time_diff

        if time_diff >= crops[i][2]:
            max_profit = max(max_profit, profit)
        else:
            remaining_time = time_diff - crops[i][2]
            index = binary_search(crops, i + 1, n, remaining_time, prefix_sum_min_time)
            if index == -1:
                max_profit = max(max_profit, profit)
            else:
                max_profit = max(max_profit, profit - (prefix_sum_profit[index] - prefix_sum_profit[i + 1]) + (crops[i][0] * (prefix_sum_min_time[index] - prefix_sum_min_time[i + 1])))

    return max_profit


def binary_search(crops, start, end, target, prefix_sum_min_time):
    while start < end:
        mid = (start + end) // 2
        time_diff = prefix_sum_min_time[mid] - prefix_sum_min_time[start]
        if time_diff <= target:
            start = mid + 1
        else:
            end = mid
    return start if prefix_sum_min_time[start] - prefix_sum_min_time[start - 1] > target else -1


n, m = map(int, sys.stdin.readline().strip().split())
crops = []
for _ in range(n):
    w, l, r = map(int, sys.stdin.readline().strip().split())
    crops.append((w, l, r))

result = calculate_max_profit(n, m, crops)
print(result)


### Explanation
The problem is solved by iterating over each crop type and calculating the maximum possible profit when the daily time range restriction is removed for that crop type.

First, the total minimum and maximum time spent processing all crops are calculated, as well as the total profit when all crops are processed for their minimum time.

The crops are then sorted in descending order of their profits.

A prefix sum array is used to store the cumulative sum of the minimum time spent processing each crop, and another prefix sum array is used to store the cumulative sum of the profit earned from each crop.

For each crop, the time difference between the total available time and the total minimum time spent processing all crops (including the current crop) is calculated.

The maximum possible profit is then calculated by subtracting the prefix sum of the profit earned from the crops after the current crop from the total profit, and adding the product of the time difference and the profit per unit time of the current crop.

If the time difference is greater than or equal to the maximum time spent processing the current crop, the maximum possible profit is updated.

Otherwise, a binary search is performed to find the index of the crop that can be processed for the remaining time. If such a crop is found, the maximum possible profit is updated by subtracting the prefix sum of the profit earned from the crops between the current crop and the found crop, and adding the product of the profit per unit time of the current crop and the prefix sum of the minimum time spent processing the crops between the current crop and the found crop.

Finally, the maximum possible profit is returned.
## Token
[858, 557, 1415]
 ### 

## Question


(L)
There is a tree (a connected undirected graph with $n$ nodes and $n-1$ edges) consisting of $n$ nodes, with nodes numbered from $1$ to $n$. Clearly, there is a unique simple path between any two nodes in the tree.

Xiaohong and Xiaolan are playing a game on this tree. In each game, both players **independently and uniformly** select a random simple path from all $\frac{n(n-1)}{2}$ simple paths (regardless of direction) that exist in the tree. Note that they may choose the same path. Let $X$ denote the number of edges that are common to both selected paths, and the score of the game is $X^2$.

Your task is to find the expected value of the score $E(X^2)$ when Xiaohong and Xiaolan play the game once, and output the result modulo $998244353$ (see the output format for details).

**Input**

The first line contains a positive integer $T$ ($1\le T \le 10^4$), representing the number of test cases.

For each test case, the first line contains a positive integer $n$ ($2\le n \le 10^5$), representing the number of nodes in the tree.

The next $n-1$ lines each contain two positive integers $u, v$ ($1\le u,v \le n$), indicating that there is an edge between nodes $u$ and $v$. The input is guaranteed to be a tree.

The sum of all $n$ over all test cases does not exceed $10^6$.

**Output**

For each test case, output a single integer, representing the answer modulo $998244353$.

Formally, let $M=998244353$. It can be shown that the answer can be expressed as an irreducible fraction $\frac p q$, where $p$ and $q$ are integers and $q \not\equiv 0\pmod M$. Output the integer equal to $p\cdot q^{-1}\pmod M$, where $q^{-1}$ denotes the modular multiplicative inverse of $q$ modulo $M$. In other words, output such an integer $x$ that $0\le x &lt; M$ and $x\cdot q\equiv p\pmod M$. It can be proved that there is exactly one $x$ which meets the condition.

Example Input：
2
3
1 2
2 3
5
1 2
1 5
3 2
4 2
Example Output：
443664158
918384806

**Note**

For the first test case in the example, the answer without taking the modulo is $\frac{10}{9}$.

Among the $9$ possible cases:

-   In $2$ cases, the number of common edges between the two paths is $0$;
-   In $6$ cases, the number of common edges between the two paths is $1$;
-   In $1$ case, the number of common edges between the two paths is $2$.

Therefore, the answer is $E(X^2) = \frac{2 \cdot 0^2 + 6 \cdot 1^2 + 1 \cdot 2^2}{9} = \frac{10}{9}$.


## Solution


from sys import stdin

def read_int():
    return int(stdin.readline())

def read_ints():
    return map(int, stdin.readline().split())

mod = 998244353

def add(a, b):
    return (a + b) % mod

def mul(a, b):
    return (a * b) % mod

def pow_mod(a, b):
    res = 1
    while b:
        if b & 1:
            res = mul(res, a)
        a = mul(a, a)
        b >>= 1
    return res

def inv(a):
    return pow_mod(a, mod - 2)

def dfs(g, u, fa, sz, ans):
    sz[u] = 1
    for v in g[u]:
        if v == fa:
            continue
        dfs(g, v, u, sz, ans)
        sz[u] += sz[v]
    ans[0] = add(ans[0], mul(sz[u] - 1, sz[u] - 1))
    for v in g[u]:
        if v == fa:
            continue
        t = n - sz[v]
        ans[0] = add(ans[0], mul(t, t))

T = read_int()
for _ in range(T):
    n = read_int()
    g = [[] for _ in range(n)]
    for _ in range(n - 1):
        u, v = read_ints()
        u -= 1
        v -= 1
        g[u].append(v)
        g[v].append(u)
    sz = [0] * n
    ans = [0]
    dfs(g, 0, -1, sz, ans)
    ans[0] = mul(ans[0], inv(mul(n, n - 1)))
    ans[0] = mul(ans[0], 2)
    print(ans[0])



## CODE


from sys import stdin

def read_int():
    return int(stdin.readline())

def read_ints():
    return map(int, stdin.readline().split())

mod = 998244353

def add(a, b):
    return (a + b) % mod

def mul(a, b):
    return (a * b) % mod

def pow_mod(a, b):
    res = 1
    while b:
        if b & 1:
            res = mul(res, a)
        a = mul(a, a)
        b >>= 1
    return res

def inv(a):
    return pow_mod(a, mod - 2)

def dfs(g, u, fa, sz, ans):
    sz[u] = 1
    for v in g[u]:
        if v == fa:
            continue
        dfs(g, v, u, sz, ans)
        sz[u] += sz[v]
    ans[0] = add(ans[0], mul(sz[u] - 1, sz[u] - 1))
    for v in g[u]:
        if v == fa:
            continue
        t = n - sz[v]
        ans[0] = add(ans[0], mul(t, t))

T = read_int()
for _ in range(T):
    n = read_int()
    g = [[] for _ in range(n)]
    for _ in range(n - 1):
        u, v = read_ints()
        u -= 1
        v -= 1
        g[u].append(v)
        g[v].append(u)
    sz = [0] * n
    ans = [0]
    dfs(g, 0, -1, sz, ans)
    ans[0] = mul(ans[0], inv(mul(n, n - 1)))
    ans[0] = mul(ans[0], 2)
    print(ans[0])


### Explanation
This solution calculates the expected value of the score E(X^2) when Xiaohong and Xiaolan play the game once.

The dfs function calculates the size of each subtree and the expected value of the score for each node.

The expected value of the score for each node is calculated as the sum of the expected values of the scores for each edge connected to the node.

The expected value of the score for each edge is calculated as the product of the sizes of the two subtrees connected by the edge, minus the size of the current subtree.

Finally, the expected value of the score for the root node is calculated and printed.

The solution uses modular arithmetic to avoid overflow and ensure accurate results.

The time complexity of the solution is O(n), where n is the number of nodes in the tree.

The space complexity of the solution is O(n), where n is the number of nodes in the tree.
## Token
[593, 809, 1402]
 ### 

## Question


(M)
While learning about the ceiling function, a student wrote the following pseudocode:

1: function f(a, b)
2: i ← b
3: while i ≥ 2 do
4: if a mod i = 0 then
5: return a/i
6: end if
7: i ← i − 1
8: end while
9: return a
10: end function

You know that this is incorrect, but you are curious about the characteristics of the function f(a, b)
defined by this student. Specifically, you want to calculate the value of \sum_{i=1}^{n} f(n, i)

**Input**
The first line contains an integer T $$ 1 \leq T \leq 10^{3} $$, indicating the number of test cases.
For each test case, there is one line containing an integer n $$ 1 \leq n \leq 10^{9} $$.

Example Input：
3
5
451
114514
Example Output：
21
10251
7075858
## Solution


def sum_of_f(n):
    total = 0
    for i in range(1, n + 1):
        for j in range(min(i, n), 1, -1):
            if n % j == 0:
                total += n // j
                break
        else:
            total += n
    return total

t = int(input())
for _ in range(t):
    n = int(input())
    print(sum_of_f(n))



## CODE


def sum_of_f(n):
    total = 0
    for i in range(1, n + 1):
        for j in range(min(i, n), 1, -1):
            if n % j == 0:
                total += n // j
                break
        else:
            total += n
    return total

t = int(input())
for _ in range(t):
    n = int(input())
    print(sum_of_f(n))


### Explanation
This code calculates the value of ∑f(n, i) from i = 1 to n for each test case. The function sum_of_f(n) uses two nested loops to iterate over all possible values of i and j. The inner loop checks if n is divisible by j, and if so, adds n // j to the total and breaks the loop. If n is not divisible by any j, it simply adds n to the total. The outer loop repeats this process for all values of i from 1 to n. The result is then printed for each test case.
## Token
[227, 317, 544]
 ### 

