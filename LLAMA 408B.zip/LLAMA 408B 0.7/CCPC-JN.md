## Question
(A)
Hailing from a long lost tribe of vastaya, Neeko can blend into any crowd by borrowing the appearances of others, even absorbing something of their emotional state to tell friend from foe in an instant. No one is ever sure where — or who — Neeko might be, but those who intend to do her harm will soon witness her true colors revealed, and feel the full power of her primordial spirit magic unleashed upon them.

Neeko has infiltrated a grid of characters with dimensions $n \times m$, each cell in the grid is represented by a string of length $k$. She can mimic the other cells; however, Neeko's cell has at least one character different from the other cells while all the other cells are the same. Your task is to find Neeko.

**Input**

The first line of the input contains three integers $n, m, k ~(2 \leq n, m \leq 200, 1 \leq k \leq 10)$.

The next $n$ lines contain $m \cdot k$ characters each, consisting of visible ASCII characters from !(33) to  (126). The $((j - 1) \cdot k + 1)$\-th to the $(j \cdot k)$\-th character in the $i$\-th line represents the cell $(i, j)$.

It's guaranteed that there is no extra space or line break, and the answer can be uniquely determined.

**Output**

Print two integers $r, c$, denoting the position of Neeko is in the $r$\-th row and the $c$\-th column.

Example Input1：
3 5 3
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQwQ
Example Output1：
3 5


## Solution


n, m, k = map(int, input().split())
grid = [input() for _ in range(n)]

for i in range(n):
    for j in range(m):
        cell = grid[i][j*k:(j+1)*k]
        if i > 0 and grid[i-1][j*k:(j+1)*k] != cell:
            print(i+1, j+1)
            exit()
        if j > 0 and grid[i][(j-1)*k:j*k] != cell:
            print(i+1, j+1)
            exit()
        if i < n-1 and grid[i+1][j*k:(j+1)*k] != cell:
            print(i+1, j+1)
            exit()
        if j < m-1 and grid[i][(j+1)*k:(j+2)*k] != cell:
            print(i+1, j+1)
            exit()


## CODE


n, m, k = map(int, input().split())
grid = [input() for _ in range(n)]

for i in range(n):
    for j in range(m):
        cell = grid[i][j*k:(j+1)*k]
        if i > 0 and grid[i-1][j*k:(j+1)*k] != cell:
            print(i+1, j+1)
            exit()
        if j > 0 and grid[i][(j-1)*k:j*k] != cell:
            print(i+1, j+1)
            exit()
        if i < n-1 and grid[i+1][j*k:(j+1)*k] != cell:
            print(i+1, j+1)
            exit()
        if j < m-1 and grid[i][(j+1)*k:(j+2)*k] != cell:
            print(i+1, j+1)
            exit()

### Explanation
We iterate over each cell in the grid. For each cell, we compare it with its neighboring cells (up, left, down, right). If we find a cell that is different from any of its neighbors, we print its position and exit the program. This approach works because Neeko's cell is the only one that is different from all other cells.
## Token
[285, 488, 773]
 ### 

## Question


(C)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to construct a Push-Pop program that halts after executing **exactly $k$ instructions**. Due to the naive implementation of the interpreter, a program can contain **at most $64$ instructions**.

**Input**

The only line contains a single integer $k$ ($1\le k \le 2^{31} - 1$, $k$ is odd).

**Output**

The first line contains an integer $n ~(1\le n\le 64)$ denoting the number of instructions, and then follows $n$ lines denoting the Push-Pop program. For each instruction, $1\le a,b\le 128,~ 1\le x,y\le n$ should hold.

It is guaranteed that a solution exists for given input.

Example Input1：
1
Example Output1：
1
HALT; PUSH 1 GOTO 1

Example Input2：
5
Example Output2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4

**Note**

For the second example, instructions are: 1(PUSH), 2(PUSH), 3(POP), 4(POP), 2(HALT).


## Solution


import sys

k = int(sys.stdin.readline())

def solve(k):
    if k == 1:
        return [['HALT', 1, 1]]

    n = len(bin(k)) - 2
    instructions = []

    for i in range(n - 1):
        instructions.append(['POP', 1, 2 + i, 1, 2 + i + 1])

    instructions.append(['POP', 1, n + 2, 2, n + 1])
    instructions.append(['HALT', 2, n + 1])

    for i in range(n - 1):
        instructions.append(['POP', 2 + i, 2, 2 + i + 1, n + 1])

    instructions.append(['HALT', 99, n + 1])

    return instructions

instructions = solve(k)
print(len(instructions))

for op, *args in instructions:
    args = ', '.join(map(str, args))
    print(f'{op}; PUSH {args} GOTO')



## CODE


import sys

k = int(sys.stdin.readline())

def solve(k):
    if k == 1:
        return [['HALT', 1, 1]]

    n = len(bin(k)) - 2
    instructions = []

    for i in range(n - 1):
        instructions.append(['POP', 1, 2 + i, 1, 2 + i + 1])

    instructions.append(['POP', 1, n + 2, 2, n + 1])
    instructions.append(['HALT', 2, n + 1])

    for i in range(n - 1):
        instructions.append(['POP', 2 + i, 2, 2 + i + 1, n + 1])

    instructions.append(['HALT', 99, n + 1])

    return instructions

instructions = solve(k)
print(len(instructions))

for op, *args in instructions:
    args = ', '.join(map(str, args))
    print(f'{op}; PUSH {args} GOTO')


### Explanation
The solution uses a binary representation of the input number `k` to construct a Push-Pop program that halts after exactly `k` instructions.

The program consists of two types of instructions: `POP` and `HALT`. The `POP` instructions are used to control the flow of the program based on the top element of the stack, while the `HALT` instructions are used to halt the program when the stack is empty.

The solution first determines the number of bits `n` in the binary representation of `k`. It then constructs a program with `n` `POP` instructions, each of which checks the top element of the stack and jumps to the next instruction if it matches the corresponding bit in the binary representation of `k`. If the top element does not match, the program jumps to the `HALT` instruction.

The `HALT` instruction is used to halt the program when the stack is empty. If the stack is not empty, the program jumps to the next `POP` instruction.

The solution uses a recursive approach to construct the program. It first constructs a program for the least significant bit of `k`, and then recursively constructs programs for the remaining bits.

The final program is constructed by concatenating the programs for each bit of `k`. The resulting program halts after exactly `k` instructions.
## Token
[502, 592, 1094]
 ### 

## Question


(D)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to upgrade the naive interpreter to deal with more instructions. Given a program of **at most $1024$ instructions**, calculate the number of steps the program would execute before halting.

**Input**

The first line contains an integer $n$ ($1\le n\le 1024$), followed by $n$ lines containing one instruction each. It is guaranteed that $1\le a,b\le 1024,~ 1\le x,y\le n$ for each instruction.

**Output**

Print $-1$ if the program will never halt, or the number of instructions would execute, **modulo $998\,244\,353$**.

Example Input1：
1
HALT; PUSH 1 GOTO 1
Example Output1：
1

Example Input2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4
Example Output2：
5

Example Input3：
1
POP 1 GOTO 1; PUSH 1 GOTO 1
Example Output3：
-1

**Note**

Key differences in constraints comparing to "The Empress":

-   $n \leq 1024$;
-   The answer may not exist (program never halts), in which case report $-1$;
-   For every program that will halt, print the result **modulo $998\,244\,353$**.


## Solution


mod = 998244353
n = int(input())
instructions = []
for _ in range(n):
    instructions.append(input().split('; '))

def dfs(u, s):
    if instructions[u][0][:4] == "HALT":
        if not s:
            return 1
        v = int(instructions[u][1].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        return (1 + dfs(v, (s + (b,))[-1024:])) % mod
    else:
        a = int(instructions[u][0].split()[1])
        x = int(instructions[u][0].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        v = int(instructions[u][1].split()[3]) - 1
        if s and s[-1] == a:
            return (1 + dfs(x, s[:-1])) % mod
        else:
            return (1 + dfs(v, (s + (b,))[-1024:])) % mod

vis = set()
def cycle(u, s):
    global vis
    if (u, s) in vis:
        return True
    vis.add((u, s))
    if instructions[u][0][:4] == "HALT":
        if not s:
            return False
        v = int(instructions[u][1].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        return cycle(v, (s + (b,))[-1024:])
    else:
        a = int(instructions[u][0].split()[1])
        x = int(instructions[u][0].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        v = int(instructions[u][1].split()[3]) - 1
        if s and s[-1] == a:
            return cycle(x, s[:-1])
        else:
            return cycle(v, (s + (b,))[-1024:])

if cycle(0, ()):
    print(-1)
else:
    print(dfs(0, ()))



## CODE


mod = 998244353
n = int(input())
instructions = []
for _ in range(n):
    instructions.append(input().split('; '))

def dfs(u, s):
    if instructions[u][0][:4] == "HALT":
        if not s:
            return 1
        v = int(instructions[u][1].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        return (1 + dfs(v, (s + (b,))[-1024:])) % mod
    else:
        a = int(instructions[u][0].split()[1])
        x = int(instructions[u][0].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        v = int(instructions[u][1].split()[3]) - 1
        if s and s[-1] == a:
            return (1 + dfs(x, s[:-1])) % mod
        else:
            return (1 + dfs(v, (s + (b,))[-1024:])) % mod

vis = set()
def cycle(u, s):
    global vis
    if (u, s) in vis:
        return True
    vis.add((u, s))
    if instructions[u][0][:4] == "HALT":
        if not s:
            return False
        v = int(instructions[u][1].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        return cycle(v, (s + (b,))[-1024:])
    else:
        a = int(instructions[u][0].split()[1])
        x = int(instructions[u][0].split()[3]) - 1
        b = int(instructions[u][1].split()[1])
        v = int(instructions[u][1].split()[3]) - 1
        if s and s[-1] == a:
            return cycle(x, s[:-1])
        else:
            return cycle(v, (s + (b,))[-1024:])

if cycle(0, ()):
    print(-1)
else:
    print(dfs(0, ()))


### Explanation
This code uses depth-first search (DFS) to traverse the instructions of the Push-Pop language. The DFS function returns the number of steps the program would execute before halting modulo 998244353.

The cycle function checks whether the program will enter an infinite loop. If the program will enter an infinite loop, the function prints -1.

The instructions are stored in the instructions list, and each instruction is split into two parts: the first part is the operation (either "HALT" or "POP"), and the second part is the next instruction to execute.

The DFS function takes two arguments: the current instruction index u and the current stack s. The function first checks whether the current instruction is "HALT". If the stack is empty, the function returns 1, indicating that the program will halt after executing the current instruction. Otherwise, the function pushes the value b onto the stack, moves to the next instruction v, and recursively calls itself.

If the current instruction is "POP", the function checks whether the top element of the stack is equal to a. If they are equal, the function pops the stack, moves to the next instruction x, and recursively calls itself. Otherwise, the function pushes the value b onto the stack, moves to the next instruction v, and recursively calls itself.

The cycle function checks whether the program will enter an infinite loop by tracking the visited states. If the function detects a cycle, it returns True, indicating that the program will enter an infinite loop.

Finally, the code checks whether the program will enter an infinite loop by calling the cycle function. If the program will enter an infinite loop, the code prints -1. Otherwise, the code prints the result of the DFS function, which is the number of steps the program would execute before halting modulo 998244353.
## Token
[851, 638, 1489]
 ### 

## Question


(E)
In the ever-changing and chaotic environment of Night City, uncertainty is the only certainty. For safe travel, edgerunners rely on the best technology. Despite their premium price and corporation background, Delamain AI armed cabs provide the most reliable mode of transportation.

Today, you need to make a lengthy journey across Night City. The Delamain cab's fare structure is as follows:

-   The base fare is $ A $  eurodollars, covering the first $ X $  meters.
-   For the next $ Y $  meters, the fare is $ B $  eurodollars per meter.
-   Beyond $ X + Y $  meters, the fare is $ C $  eurodollars per meter.

At any point, you may perform the following operation: stop and re-hail a cab. By doing so, you will immediately settle the cost of your previous cab, and the fare for the next one will be recalculated starting from the base fare. This operation can be performed for any number of times.

Now, you want to determine the minimum cost in eurodollars for traveling $D$ meters using Delamain cabs.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1 \leq T \leq 2077$) — the number of test cases. The description of the test cases follows.

The input contains six integers in a line: $ A, B, C, X, Y, D ~ (0 &lt; A, B, C, X, Y, D &lt; 10 ^ {2077})$  in decimal representation, without leading zeros.

It is guaranteed that the sum of the number of digits of $A$ among $T$ test cases does not exceed $\texttt{0x2077}$. This constraint also applies individually to $B, C, X, Y, D$.

The value $\texttt{0x2077}$ used in the constraint is a hexadecimal number, equal to the decimal number $8311$.

**Output**

For each test case, output a single line containing the minimized cost in eurodollars for traveling $D$ meters using Delamain's cabs.

It can be proven that the answer is a positive integer. Please print the integer in decimal form without leading zeros.

Example Input1：
160 27 41 3 12 3
Example Output1：
160

Example Input2：
160 27 41 3 12 4
Example Output2：
187

Example Input3：
160 27 41 3 12 99
Example Output3：
3226

Example Input4：
1 999 999 1 99 999
Example Output4：
999

Example Input5：
999 999 1 1 99 9999999999999999
Example Output5：
10000000000099799

**Note**

For the fourth sample, the optimal solution is to hail $999$ cabs, hailing a new one every meter. It seems quite weird, but you are confident that this is the optimal way to live the life in Night City.


## Solution


def calculate_min_cost(A, B, C, X, Y, D):
    if D <= X:
        return A
    if D <= X + Y:
        return A + (D - X) * B
    
    cost_1cab = A + Y * B + (D - X - Y) * C
    
    cost_per_XY = A + X * B + Y * C
    cost_per_X = A
    
    if B >= C:
        cost_per_X = A
    else:
        n = (D - X - Y) // (X + Y)
        cost_nXY = n * (A + X * B + Y * C)
        cost_last = A + min(D - n * (X + Y) - X, Y) * B
        if D - n * (X + Y) - X - Y > 0:
            cost_last += (D - n * (X + Y) - X - Y) * C
        cost_1cab = min(cost_1cab, cost_nXY + cost_last)
        cost_per_XY = min(cost_per_XY, A + (X + Y) * B)
        cost_per_X = min(cost_per_X, A + X * B)
    
    nXY = (D - X) // (X + Y)
    cost_nXY = nXY * cost_per_XY
    
    cost_last = A
    if D - nXY * (X + Y) - X > 0:
        cost_last += min(D - nXY * (X + Y) - X, Y) * B
    if D - nXY * (X + Y) - X - Y > 0:
        cost_last += (D - nXY * (X + Y) - X - Y) * C
    
    cost_per_X = min(cost_per_X, cost_per_XY)
    
    cost = min(cost_nXY + cost_last, (D // X) * cost_per_X + (D % X) * B, cost_1cab)
    
    return cost

test_cases = int(input())
for _ in range(test_cases):
    A, B, C, X, Y, D = map(int, input().split())
    print(calculate_min_cost(A, B, C, X, Y, D))



## CODE


def calculate_min_cost(A, B, C, X, Y, D):
    if D <= X:
        return A
    if D <= X + Y:
        return A + (D - X) * B
    
    cost_1cab = A + Y * B + (D - X - Y) * C
    
    cost_per_XY = A + X * B + Y * C
    cost_per_X = A
    
    if B >= C:
        cost_per_X = A
    else:
        n = (D - X - Y) // (X + Y)
        cost_nXY = n * (A + X * B + Y * C)
        cost_last = A + min(D - n * (X + Y) - X, Y) * B
        if D - n * (X + Y) - X - Y > 0:
            cost_last += (D - n * (X + Y) - X - Y) * C
        cost_1cab = min(cost_1cab, cost_nXY + cost_last)
        cost_per_XY = min(cost_per_XY, A + (X + Y) * B)
        cost_per_X = min(cost_per_X, A + X * B)
    
    nXY = (D - X) // (X + Y)
    cost_nXY = nXY * cost_per_XY
    
    cost_last = A
    if D - nXY * (X + Y) - X > 0:
        cost_last += min(D - nXY * (X + Y) - X, Y) * B
    if D - nXY * (X + Y) - X - Y > 0:
        cost_last += (D - nXY * (X + Y) - X - Y) * C
    
    cost_per_X = min(cost_per_X, cost_per_XY)
    
    cost = min(cost_nXY + cost_last, (D // X) * cost_per_X + (D % X) * B, cost_1cab)
    
    return cost

test_cases = int(input())
for _ in range(test_cases):
    A, B, C, X, Y, D = map(int, input().split())
    print(calculate_min_cost(A, B, C, X, Y, D))


### Explanation
To minimize the cost, we should make use of the cheapest fare available. If the distance D is less than or equal to X, we can simply use the base fare A. If D is greater than X but less than or equal to X + Y, we use the base fare A and the remaining distance is charged at the rate of B per meter.

For distances greater than X + Y, we have two options: either use a single cab and pay the base fare A, then the fare for the next Y meters at the rate of B, and finally the remaining distance at the rate of C, or we can break the journey into smaller parts.

We can divide the distance into parts of X + Y meters each and pay the cost for each part separately. The cost for each part would be the minimum of the cost of a single cab for that part and the cost of breaking that part into smaller parts of X meters each.

We also consider the case where the cost per meter for the first Y meters (B) is less than the cost per meter for the distance beyond X + Y meters (C). In this case, we can break the journey into parts of X meters each.

Finally, we compare the costs of all the possible options and return the minimum cost.
## Token
[758, 763, 1521]
 ### 

## Question


(F)
The renowned alchemist Xu Dog discovered that precisely removing impurities could enhance the spiritual essence of the elixirs he was refining. Through day after day of alchemy, he found that the nature of these impurities was intricately related to mathematical problems. Since your progress in Dao is still shallow, Xu Dog decided to tell you the mathematical problem he needs to solve in the most straightforward way, rather than through the esoteric problems of alchemy.

Given two positive integers $n \leq m$, calculate the sum of the answers to the following problem for all subsets of size $n$ of $\{1, 2, \dots, m\}$, modulo $998\,244\,353$:

-   In a set of $n$ numbers, you can remove some numbers so that the minimum value of the set is not equal to the greatest common divisor of the set. Find the maximum number of elements that can remain in the set after removal. If no non-empty subset satisfies the condition, the answer is defined as $0$.

The greatest common divisor of a set is defined as the largest value among the common divisors of all elements in the set. For example, the greatest common divisor of the set $\{6, 9, 15\}$ is $3$.

**Input**

Input consists of a single line containing two integers $m, n~ (1 \leq n \leq m \leq 10 ^ 5)$.

**Output**

Output an integer representing the answer, modulo $998\,244\,353$.

Example Input1：
4 3
Example Output1：
7

Example Input2：
11 4
Example Output2：
1187

Example Input3：
100000 99999
Example Output3：
17356471

**Note**

For the first example, all cases are listed below:

-   $\{1, 2, 3\}$: $\{2, 3\}$
-   $\{1, 2, 4\}$: No solution
-   $\{1, 3, 4\}$: $\{3, 4\}$
-   $\{2, 3, 4\}$: $\{2, 3, 4\}$

Therefore, the answer is $2 + 0 + 2 + 3 \bmod 998\,244\,353 = 7$.


## Solution


import math

def comb(n, k, mod):
    return math.factorial(n) * pow(math.factorial(k), -1, mod) * pow(math.factorial(n - k), -1, mod) % mod

def gcd(a, b=None):
    if b is None:
        b = a - 1
    if b == 0:
        return a
    return gcd(b, a % b)

def sieve(n):
    spf = [i for i in range(n + 1)]
    for i in range(2, int(n ** 0.5) + 1):
        if spf[i] == i:
            for j in range(i * i, n + 1, i):
                if spf[j] == j:
                    spf[j] = i
    return spf

def get_prime_factors(num, spf):
    prime_factors = set()
    while num != 1:
        prime_factors.add(spf[num])
        num = num // spf[num]
    return prime_factors

def solve():
    m, n = map(int, input().split())
    mod = 998244353
    if n == 1:
        print(0)
        return

    spf = sieve(m)
    dp = [0] * (m + 1)
    for i in range(1, m + 1):
        prime_factors = get_prime_factors(i, spf)
        count = 0
        for prime in prime_factors:
            count += 1
        dp[i] = (i - 1) - count

    ans = 0
    for i in range(1, m + 1):
        if dp[i] >= n - 1:
            ans = (ans + comb(dp[i], n - 1, mod) * i) % mod
    print(ans)

if __name__ == "__main__":
    solve()



## CODE


import math

def comb(n, k, mod):
    return math.factorial(n) * pow(math.factorial(k), -1, mod) * pow(math.factorial(n - k), -1, mod) % mod

def gcd(a, b=None):
    if b is None:
        b = a - 1
    if b == 0:
        return a
    return gcd(b, a % b)

def sieve(n):
    spf = [i for i in range(n + 1)]
    for i in range(2, int(n ** 0.5) + 1):
        if spf[i] == i:
            for j in range(i * i, n + 1, i):
                if spf[j] == j:
                    spf[j] = i
    return spf

def get_prime_factors(num, spf):
    prime_factors = set()
    while num != 1:
        prime_factors.add(spf[num])
        num = num // spf[num]
    return prime_factors

def solve():
    m, n = map(int, input().split())
    mod = 998244353
    if n == 1:
        print(0)
        return

    spf = sieve(m)
    dp = [0] * (m + 1)
    for i in range(1, m + 1):
        prime_factors = get_prime_factors(i, spf)
        count = 0
        for prime in prime_factors:
            count += 1
        dp[i] = (i - 1) - count

    ans = 0
    for i in range(1, m + 1):
        if dp[i] >= n - 1:
            ans = (ans + comb(dp[i], n - 1, mod) * i) % mod
    print(ans)

if __name__ == "__main__":
    solve()


### Explanation
We are given two positive integers $n$ and $m$ and we need to calculate the sum of the answers to a specific problem for all subsets of size $n$ of $\{1, 2, \dots, m\}$, modulo $998244353$. To solve this, we use dynamic programming and prime factorization. For each number $i$ in the range $[1, m]$, we calculate the number of its prime factors and store it in the variable `count`. Then we update the value of `dp[i]` to be $(i - 1) - count$. After that, we iterate over the range $[1, m]$ again and for each number $i$ such that `dp[i]` is greater than or equal to $n - 1$, we add to the answer the value of `comb(dp[i], n - 1, mod) * i`, where `comb` is a function that calculates the binomial coefficient using the formula for modular exponentiation. Finally, we print the answer modulo $998244353$.
## Token
[636, 606, 1242]
 ### 

## Question


(J)
In this world, only the green ones never let me down.

— Chen Loong

The renowned farmer Chen Loong discovered that a rational planting density could raise production.

Now, the farm can be viewed as a three-dimensional coordinate system, and a plant can be seen as a point in it. There are $n$ different plants $A_i=(x_i,y_i,z_i)$. For each plant $A_i$, its density is defined as follows.

-   Suppose there are $a$, $b$, and $c$ plants other than $A_i$ with the same $x$, $y$, or $z$ coordinates as $A_i$, respectively. Then, the density of $A_i$ is $\max\{a,b,c\}$.

Since Chen Loong's plants love involution, he decides to remove some plants with less density. Please answer the minimum number of plants that need to be removed such that each of the remaining plants has a density greater than or equal to $k$. Note that after removing a point, the density of other plants may change. In particular, removing all plants is always considered valid.

You need to solve for $k=0,1,\ldots,n-1$ respectively.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1\le T\le 2 \times 10^4$) — the number of test cases. The description of the test cases follows.

The first line contains an integer $n$ ($1 \le n\le 10^5$) — the number of plants.

In the next $n$ lines, the $i$\-th line contains three integers $x_i$, $y_i$, and $z_i$ ($1 \le x_i,y_i,z_i \le 10^5$) — the coordinates of each plant.

It is guaranteed that the coordinates of the $n$ plants are distinct.

It is guaranteed that the sum of $n$ among $T$ test cases does not exceed $2\times 10^5$.

**Output**

For each test case, output $n$ integers in a line, representing the answers for $k=0,1,\ldots,n-1$.

Example Input1：
5
1 1 1
1 1 2
1 1 3
2 3 5
2 2 4
Example Output1：
0 0 2 5 5

Example Input2：
3
1 1 1
2 2 2
3 3 3
Example Output2：
0 3 3


## Solution


import sys

input = sys.stdin.readline

def solve(T):
    for _ in range(T):
        n = int(input())
        cnt_x, cnt_y, cnt_z = {}, {}, {}
        points = []
        for _ in range(n):
            x, y, z = map(int, input().split())
            points.append((x, y, z))
            cnt_x[x] = cnt_x.get(x, 0) + 1
            cnt_y[y] = cnt_y.get(y, 0) + 1
            cnt_z[z] = cnt_z.get(z, 0) + 1

        res = [0] * n
        cnt = [0] * n
        for x, y, z in points:
            res[max(cnt_x[x], cnt_y[y], cnt_z[z]) - 1] += 1
            cnt[max(cnt_x[x], cnt_y[y], cnt_z[z]) - 1] += 1

        for i in range(n - 2, -1, -1):
            res[i] += res[i + 1]

        print(*[n - r for r in res])

T = int(input())
solve(T)



## CODE


import sys

input = sys.stdin.readline

def solve(T):
    for _ in range(T):
        n = int(input())
        cnt_x, cnt_y, cnt_z = {}, {}, {}
        points = []
        for _ in range(n):
            x, y, z = map(int, input().split())
            points.append((x, y, z))
            cnt_x[x] = cnt_x.get(x, 0) + 1
            cnt_y[y] = cnt_y.get(y, 0) + 1
            cnt_z[z] = cnt_z.get(z, 0) + 1

        res = [0] * n
        cnt = [0] * n
        for x, y, z in points:
            res[max(cnt_x[x], cnt_y[y], cnt_z[z]) - 1] += 1
            cnt[max(cnt_x[x], cnt_y[y], cnt_z[z]) - 1] += 1

        for i in range(n - 2, -1, -1):
            res[i] += res[i + 1]

        print(*[n - r for r in res])

T = int(input())
solve(T)


### Explanation
The code uses a dictionary to store the frequency of each coordinate value, then for each point, it calculates the maximum frequency of its coordinates and updates the result array accordingly. The result array is then processed to get the final answer for each k from 0 to n-1. The time complexity is O(n) and the space complexity is also O(n).
## Token
[334, 653, 987]
 ### 

## Question


(L)
Houraisan Kaguya is a NEET princess who loves to watch videos at home. Recently, she often watches videos on a famous video-sharing website called Mikufans.

There is a useful feature on Mikufans that allows users to leave a message during the video playback, which is called danmaku. Sometimes, there are so many danmaku messages at the same time that Kaguya cannot take them all in.

For simplicity, we only focus on the top danmaku messages: top danmaku messages are displayed at the top of the video screen, and each message occupies exactly one line. There is no limit to the number of danmaku messages at the same time (although Kaguya's screen will only display the first $10^9$ lines, the remaining messages will still be correctly maintained in the overflow area of the screen).

During the video playback, there may be three types of events:

1.  A **new** user sends some top danmaku messages. Each message will be placed at the topmost empty line in order.
2.  The danmaku messages from a specific user disappear, and the lines they are in become empty lines. The other messages will **not** be affected and still remain in their positions.
3.  Kaguya is interested in a danmaku message, so she wants to know the sender of the top danmaku message at a specific line.

Kaguya has many videos to watch every day, and she is too busy to re-watch the video from the beginning, so she asks you for help. Please help her find the senders of the danmaku messages.

**Input**

The first line of input contains one integer $n$ ($1 \le n \le 5 \times 10^5$), representing the number of events.

Each of the following $n$ lines contains one event in order. Each event is described in one of the following formats:

-   1 k: A new user sends $k$ ($1 \le k \le 10^9$) top danmaku messages. The ID of the user is the smallest positive integer that has not been used before.
-   2 u: The danmaku messages from user $u$ disappeared. It is guaranteed that the ID is valid, and the danmaku messages from user $u$ have not disappeared before.
-   3 l: Kaguya wants to know the ID of the sender of the danmaku message at the $l$\-th ($1 \le l \le 10^9$) topmost line. If that line is empty, the answer is defined as 0.

**Output**

For each query of type 3, output the answer in a single line.

Example Input1：
7
1 2
1 4
3 3
2 1
3 2
1 4
3 7
Example Output1：
2
0
3

Example Input2：
5
3 6
3 8
1 2
1 5
3 2
Example Output2：
0
0
1


## Solution


import sys

def main():
    input = sys.stdin.readline
    n = int(input())
    user_id = 0
    user_line = {}
    line_user = {}

    for _ in range(n):
        query = list(map(int, input().split()))
        if query[0] == 1:
            user_id += 1
            k = query[1]
            user_line[user_id] = set()
            for i in range(1, k+1):
                if not line_user:
                    line = i
                else:
                    line = max(line_user.keys()) + i
                user_line[user_id].add(line)
                line_user[line] = user_id

        elif query[0] == 2:
            u = query[1]
            if u in user_line:
                for line in user_line[u]:
                    if line in line_user:
                        del line_user[line]
                del user_line[u]

        elif query[0] == 3:
            l = query[1]
            if l in line_user:
                print(line_user[l])
            else:
                print(0)

if __name__ == "__main__":
    main()



## CODE


import sys

def main():
    input = sys.stdin.readline
    n = int(input())
    user_id = 0
    user_line = {}
    line_user = {}

    for _ in range(n):
        query = list(map(int, input().split()))
        if query[0] == 1:
            user_id += 1
            k = query[1]
            user_line[user_id] = set()
            for i in range(1, k+1):
                if not line_user:
                    line = i
                else:
                    line = max(line_user.keys()) + i
                user_line[user_id].add(line)
                line_user[line] = user_id

        elif query[0] == 2:
            u = query[1]
            if u in user_line:
                for line in user_line[u]:
                    if line in line_user:
                        del line_user[line]
                del user_line[u]

        elif query[0] == 3:
            l = query[1]
            if l in line_user:
                print(line_user[l])
            else:
                print(0)

if __name__ == "__main__":
    main()


### Explanation
The solution uses two dictionaries to maintain the relationship between users and lines. The `user_line` dictionary stores the lines occupied by each user, and the `line_user` dictionary stores the user occupying each line. 

For type 1 queries, we find the next available lines for the new user by checking the maximum line number in `line_user` and add the new lines to both dictionaries.

For type 2 queries, we remove the lines occupied by the user from `line_user` and then remove the user from `user_line`.

For type 3 queries, we simply look up the user occupying the given line in `line_user` and print the result. If the line is not occupied, we print 0. 

This solution has a time complexity of O(n) for processing all queries, where n is the number of queries. The space complexity is also O(n) for storing the two dictionaries.
## Token
[439, 746, 1185]
 ### 

