## Question
(B)
Grammy's birthday is approaching, and she gets a sequence $A$ from her friends as a gift. The sequence consists of only $0$, $1$, and $2$. Grammy thinks that the sequence is too long, so she decides to modify $A$ to make it shorter.

Formally, Grammy can perform an arbitrary number of operations. Each time she can choose one of the following three operations to perform:

-   Change any $2$ into $0$ or $1$.
-   Choose two adjacent $0$s, erase them, and concatenate the rest of the parts.
-   Choose two adjacent $1$s, erase them, and concatenate the rest of the parts.

Calculate the minimum sequence length Grammy can get.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first and only line contains a string of length $n$ ($1\leq n\leq 2 \times 10^5$) consisting of digits $0$, $1$, and $2$, indicating the initial sequence $A$.

It is guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the minimum sequence length Grammy can get.

Example Input1:
0110101
Example Output1：
3
Example Input2:
01020102
Example Output2：
4
Example Input3:
0000021111
Example Output3：
0
Example Input4:
1012121010
Example Output4：
6
Example Input5:
0100202010
Example Output5：
0


## Solution


for _ in range(int(input())):
    s = input()
    stack = []
    for i in s:
        if i == '2':
            if stack and stack[-1] != '2':
                stack.pop()
            else:
                stack.append('2')
        elif stack and stack[-1] == i:
            stack.pop()
        else:
            stack.append(i)
    print(len(stack))



## CODE


for _ in range(int(input())):
    s = input()
    stack = []
    for i in s:
        if i == '2':
            if stack and stack[-1] != '2':
                stack.pop()
            else:
                stack.append('2')
        elif stack and stack[-1] == i:
            stack.pop()
        else:
            stack.append(i)
    print(len(stack))


### Explanation
The code uses a stack-based approach to solve the problem. It iterates through each character in the input string. When it encounters a '2', it checks if the stack is not empty and the top of the stack is not '2'. If both conditions are true, it pops the top element from the stack. Otherwise, it pushes the '2' onto the stack. When it encounters a '0' or '1', it checks if the stack is not empty and the top of the stack is the same as the current character. If both conditions are true, it pops the top element from the stack. Otherwise, it pushes the character onto the stack. Finally, it prints the length of the stack, which represents the minimum sequence length Grammy can get.
## Token
[250, 457, 707]
 ### 

## Question

(C)
You are given a tree consisting of $n$ vertices, rooted at vertex $1$. It is guaranteed that every vertex has a smaller index than all of its children. A topological order of this tree is a permutation $p_1,p_2,\dots,p_n$ of $n$ that satisfies the following constraint: For all $1\leq i&lt;j\leq n$, vertex $p_j$ is not the parent of vertex $p_i$.

For each $1 \le i \le n$, calculate the number of topological orders of the given tree satisfying $p_i=i$, modulo $998\,244\,353$.

**Input**

There is only one test case in each test file.

The first line contains an integer $n$ ($2\leq n\leq 5\,000$), denoting the number of vertices of the tree.

The second line contains $(n-1)$ integers $f_2,f_3,\dots,f_n$ ($1\leq f_i&lt; i$), where $f_i$ is the parent of vertex $i$.

**Output**

Output one line containing $n$ integers $a_1, a_2, \cdots, a_n$ separated by a space, where $a_i$ is the number of topological orders satisfying $p_i=i$, modulo $998\,244\,353$.

Example Input1：
4
1 1 2
Example Output1：
3 2 1 2
Example Input2：
9
1 1 2 2 3 3 4 5
Example Output2：
672 420 180 160 152 108 120 170 210

**Note**

For the first sample test case, all topological orders of the tree are $\{1, 2, 3, 4\}$, $\{1, 3, 2, 4\}$ and $\{1, 2, 4, 3\}$. There are $3$ of them satisfying $p_1 = 1$, $2$ of them satisfying $p_2 = 2$, $1$ of them satisfying $p_3 = 3$, and $2$ of them satisfying $p_4 = 4$.


## Solution


import sys
input = sys.stdin.readline

mod = 998244353
N = 5 * (10 ** 3) + 10

def dfs(x):
    for v in e[x]:
        dfs(v)
        dp[x] = (dp[x] * dp[v]) % mod
        sz[x] += sz[v]
    dp[x] = (dp[x] * fac[sz[x]]) % mod

def dfs2(x):
    ans[x] = (dp[x] * inv[sz[x]]) % mod
    for v in e[x]:
        dp[x] = (dp[x] * inv[sz[v]]) % mod
        sz[x] -= sz[v]
        dp[v] = (dp[v] * fac[sz[x]]) % mod
        dfs2(v)
        dp[v] = (dp[v] * inv[sz[x]]) % mod
        sz[x] += sz[v]
        dp[x] = (dp[x] * dp[v]) % mod

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = (res * a) % mod
        b >>= 1
        a = (a * a) % mod
    return res

def invs(x):
    return qpow(x, mod-2)

n = int(input())
e = [[] for _ in range(n+1)]
dp = [1] * (n + 1)
sz = [1] * (n + 1)
ans = [0] * (n + 1)

fac = [1] * N
inv = [1] * N
for i in range(1, n+1):
    fac[i] = (fac[i-1] * i) % mod
    inv[i] = invs(fac[i])

nums = list(map(int, input().split()))
for i in range(2, n+1):
    e[nums[i-2]].append(i)

dfs(1)
dfs2(1)

for i in range(1, n+1):
    print(ans[i], end=' ')



## CODE


import sys
input = sys.stdin.readline

mod = 998244353
N = 5 * (10 ** 3) + 10

def dfs(x):
    for v in e[x]:
        dfs(v)
        dp[x] = (dp[x] * dp[v]) % mod
        sz[x] += sz[v]
    dp[x] = (dp[x] * fac[sz[x]]) % mod

def dfs2(x):
    ans[x] = (dp[x] * inv[sz[x]]) % mod
    for v in e[x]:
        dp[x] = (dp[x] * inv[sz[v]]) % mod
        sz[x] -= sz[v]
        dp[v] = (dp[v] * fac[sz[x]]) % mod
        dfs2(v)
        dp[v] = (dp[v] * inv[sz[x]]) % mod
        sz[x] += sz[v]
        dp[x] = (dp[x] * dp[v]) % mod

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = (res * a) % mod
        b >>= 1
        a = (a * a) % mod
    return res

def invs(x):
    return qpow(x, mod-2)

n = int(input())
e = [[] for _ in range(n+1)]
dp = [1] * (n + 1)
sz = [1] * (n + 1)
ans = [0] * (n + 1)

fac = [1] * N
inv = [1] * N
for i in range(1, n+1):
    fac[i] = (fac[i-1] * i) % mod
    inv[i] = invs(fac[i])

nums = list(map(int, input().split()))
for i in range(2, n+1):
    e[nums[i-2]].append(i)

dfs(1)
dfs2(1)

for i in range(1, n+1):
    print(ans[i], end=' ')


### Explanation
This code uses python to implement a solution for the given problem. This problem is about finding the number of topological orders of a given tree that satisfies a certain constraint.

The solution consists of two main parts: 

1. Calculating the number of topological orders of each subtree rooted at vertex i, represented by dp[i]. This is done by performing a depth-first search (DFS) on the tree.

2. Calculating the number of topological orders of the whole tree that satisfies p_i=i, represented by ans[i]. This is done by performing another DFS on the tree and using the values calculated in the first DFS.

The calculation of dp[i] involves multiplying the number of topological orders of all subtrees of vertex i, and then multiplying the result by the factorial of the number of vertices in the subtree rooted at vertex i.

The calculation of ans[i] involves dividing dp[i] by the factorial of the number of vertices in the subtree rooted at vertex i, and then multiplying the result by the factorial of the number of vertices in the whole tree minus the number of vertices in the subtree rooted at vertex i.

The time complexity of this solution is O(n), where n is the number of vertices in the tree, because it performs two DFS on the tree, each taking O(n) time. The space complexity is also O(n), because it needs to store the values of dp[i] and ans[i] for each vertex i.
## Token
[752, 583, 1335]
 ### 

## Question


(E)
Given a string $S = s_0s_1\cdots s_{n-1}$ of length $n$, you can shift $S$ to the left for at most $k$ times (including zero times). Calculate the maximum number of "nanjing" substrings contained in the string after the operations.

More formally, let $f(S, d)$ be the string obtained by shifting $S$ to the left $d$ times. That is, $f(S, d) = s_{(d+0)\bmod n}s_{(d+1)\bmod n}\cdots s_{(d+n-1)\bmod n}$. Let $g(f(S, d), l, r) = s_{(d+l)\bmod n}s_{(d+l+1)\bmod n}\cdots s_{(d+r)\bmod n}$. Let $h(d)$ be the number of integer pairs $(l, r)$ such that $0 \le l \le r &lt; n$ and $g(f(S, d), l, r) =$ nanjing. Find an integer $d$ such that $0 \le d \le k$ to maximize $h(d)$ and output this maximized value.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $k$ ($1 \le n \le 2 \times 10^5$, $0 \le k \le 10^9$) indicating the length of the string and the maximum number of left shifts you can perform.

The second line contains a string $s_0s_1\cdots s_{n - 1}$ of length $n$. The string consists of lower-cased English letters.

It's guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of "nanjing" substrings contained in the string.

Example Input1：
21 10
jingicpcnanjingsuanan
Example Output1：
2

Example Input2：
21 0
jingicpcnanjingsuanan
Example Output2：
1

Example Input3：
21 3
nanjingnanjingnanjing
Example Output3：
3

Example Input4：
4 100
icpc
Example Output4：
0

**Note**

For the first sample test case, we can shift the string to the left $6$ times and get the string "pcnanjingsuananjingic". There are two "nanjing" substrings.

For the second sample test case, because $k = 0$, we cannot perform any left shifting. There is one "nanjing" substring in the original string.


## Solution


def z_function(s):
    n = len(s)
    z = [0] * n
    l, r = 0, 0
    for i in range(1, n):
        if i <= r:
            z[i] = min(z[i - l], r - i + 1)
        while i + z[i] < n and s[z[i]] == s[i + z[i]]:
            z[i] += 1
        if i + z[i] - 1 > r:
            l, r = i, i + z[i] - 1
    return z

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    s = input()
    s += s
    z = z_function("nanjing" + s)
    ans = 0
    for i in range(7, 7 + n):
        if z[i] == 7:
            ans += 1
    result = ans
    for i in range(1, min(n, k) + 1):
        if z[7 + i - 1] == 7:
            ans -= 1
        if z[7 + n + i - 1] == 7:
            ans += 1
        result = max(result, ans)
    print(result)


## CODE


def z_function(s):
    n = len(s)
    z = [0] * n
    l, r = 0, 0
    for i in range(1, n):
        if i <= r:
            z[i] = min(z[i - l], r - i + 1)
        while i + z[i] < n and s[z[i]] == s[i + z[i]]:
            z[i] += 1
        if i + z[i] - 1 > r:
            l, r = i, i + z[i] - 1
    return z

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    s = input()
    s += s
    z = z_function("nanjing" + s)
    ans = 0
    for i in range(7, 7 + n):
        if z[i] == 7:
            ans += 1
    result = ans
    for i in range(1, min(n, k) + 1):
        if z[7 + i - 1] == 7:
            ans -= 1
        if z[7 + n + i - 1] == 7:
            ans += 1
        result = max(result, ans)
    print(result)

### Explanation
We use the Z-algorithm to calculate the maximum number of "nanjing" substrings contained in the string after shifting. The Z-algorithm is an algorithm for linear-time string matching. We concatenate the string "nanjing" with the input string, and then apply the Z-algorithm. The Z-algorithm returns an array where the i-th element represents the length of the longest substring starting at the i-th position that matches the prefix of the string. We iterate over the array and count the number of occurrences of "nanjing" in the string. We then shift the string to the left by one character and repeat the process. We keep track of the maximum number of occurrences found so far. Finally, we print the maximum number of occurrences found.
## Token
[449, 718, 1167]
 ### 

## Question


(F)
In Pigeland, the subway system is quite advanced. It consists of $n$ sites, numbered from $1$ to $n$, and $k$ directed subway lines, numbered from $1$ to $k$. Subway line $i$ travels through sites $x_{i, 1}, x_{i, 2}, \cdots, x_{i, p_i}$ in order, where $x_{i, j}$ is the $j$\-th site visited by line $i$. It takes $w_{i,j}$ units of time to travel from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$.

When multiple lines meet at the same site, passengers can transfer between lines. If a passenger is at a site on line $x$, while line $y$ also passes through this site, he/she can spend $a_y \times b_x$ units of time to transfer from line $x$ to line $y$, where $a_y$ and $b_x$ are given coefficients for lines $y$ and $x$. After transferring, the passenger is still at the same site, but on line $y$.

You start at site $1$. Find the minimum time needed to reach site $s$ for all $2 \le s \le n$. In particular, you can start by choosing any line at site $1$ with no transfer time cost. It is guaranteed that all sites are reachable from site $1$.

**Input**

There is only one test case in each test file.

The first line contains two integers $n$ and $k$ ($2 \leq n \leq 2 \times 10^5$, $1 \leq k \leq 2 \times 10^5$), indicating the number of sites and the number of subway lines.

The second line contains $k$ integers $a_1, a_2, \cdots, a_k$ ($1 \leq a_i \leq 10^6$).

The third line contains $k$ integers $b_1, b_2, \cdots, b_k$ ($1 \leq b_i \leq 10^6$).

For the following $k$ lines, the $i$\-th line first contains an integer $p_i$ ($2 \leq p_i \leq n$), indicating the number of sites line $i$ travels through. Then $(2p_i - 1)$ integers $x_{i, 1}, w_{i, 1}, x_{i, 2}, \ldots, x_{i, p_i - 1}, w_{i, p_i - 1}, x_{i, p_i}$ follow ($1 \leq x_{i,j} \leq n$, $1 \leq w_{i,j} \leq 10^9$), where $x_{i, j}$ is the $j$\-th site visited by line $i$, and $w_{i,j}$ is the travel time from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$. The sites traveled through by a subway line are distinct.

It is guaranteed that $\sum\limits_{i=1}^k (p_i - 1) \leq 2 \times 10^5$.

**Output**

Output one line containing $(n - 1)$ integers $d_2, d_3, \cdots, d_n$ separated by a space, where $d_i$ is the minimum time cost from site $1$ to site $i$.

Example Input1：
6 3
1 5 1
5 5 1
3 1 2 2 3 3
3 5 1 2 1 4
3 3 4 5 4 6
Example Output1：
2 5 21 14 18

Example Input2：
6 3
1 5 1
5 5 1
5 1 2 2 100 3 100 6 1 4
5 1 100 2 4 3 100 5 1 4
2 3 1 5
Example Output2：
2 31 43 37 136


## Solution


import sys
import heapq

def solve():
    input = sys.stdin.readline
    n, k = map(int, input().split())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    graph = [[] for _ in range(n + 1)]
    for i in range(k):
        line = list(map(int, input().split()))
        for j in range(line[0] - 1):
            u, w, v = line[2 * j + 1], line[2 * j + 2], line[2 * j + 3]
            graph[u].append((v, w, i))
    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    queue = [(0, 1, -1)]
    while queue:
        d, u, line = heapq.heappop(queue)
        if d > dist[u]:
            continue
        for v, w, new_line in graph[u]:
            new_dist = d + w
            if new_line != line:
                new_dist += a[new_line] * b[line]
            if new_dist < dist[v]:
                dist[v] = new_dist
                heapq.heappush(queue, (new_dist, v, new_line))
    print(*dist[2:])

solve()



## CODE


import sys
import heapq

def solve():
    input = sys.stdin.readline
    n, k = map(int, input().split())
    a = list(map(int, input().split()))
    b = list(map(int, input().split()))
    graph = [[] for _ in range(n + 1)]
    for i in range(k):
        line = list(map(int, input().split()))
        for j in range(line[0] - 1):
            u, w, v = line[2 * j + 1], line[2 * j + 2], line[2 * j + 3]
            graph[u].append((v, w, i))
    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    queue = [(0, 1, -1)]
    while queue:
        d, u, line = heapq.heappop(queue)
        if d > dist[u]:
            continue
        for v, w, new_line in graph[u]:
            new_dist = d + w
            if new_line != line:
                new_dist += a[new_line] * b[line]
            if new_dist < dist[v]:
                dist[v] = new_dist
                heapq.heappush(queue, (new_dist, v, new_line))
    print(*dist[2:])

solve()


### Explanation
We use Dijkstra's algorithm to solve this problem. The graph is represented as an adjacency list, where each edge is represented as a tuple of (destination, weight, line). We maintain a priority queue of nodes to visit, where each node is represented as a tuple of (distance, node, line). The distance is the minimum distance from the starting node to the current node, and the line is the line that we used to reach the current node. When we visit a node, we update the distances of its neighbors if we can reach them with a shorter distance. We also update the line that we use to reach each neighbor. Finally, we print the minimum distances to all nodes except the starting node.
## Token
[440, 1022, 1462]
 ### 

## Question


(G)
Given a binary tree with $n$ vertices, your task is to find a special vertex $s$ in the tree with at most $p = \lfloor \log_2 n \rfloor$ queries. That is to say, $p$ is the largest integer such that $2^p \le n$.

Each query consists of two different vertices $u$ and $v$. The interactor will output an integer $t$ ($0 \le t \le 2$) as the answer. Let $d(a, b)$ be the number of edges on the simple path from vertex $a$ to vertex $b$.

-   If $t = 0$, then vertex $u$ is nearer to the special vertex. That is, $d(u, s) &lt; d(v, s)$.
-   If $t = 1$, then the distances from $u$ and $v$ to the special vertex are the same. That is, $d(u, s) = d(v, s)$.
-   If $t = 2$, then vertex $v$ is nearer to the special vertex. That is, $d(u, s) &gt; d(v, s)$.

Note that the interactor is adaptive, meaning that the answer for each test case is not pre-determined. The interactor can determine the special vertex according to your queries, as long as its answer does not conflict with the previous queries and answers.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($2 \le n \le 10^5$) indicating the number of vertices in the binary tree.

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($0 \le x_i, y_i \le n$), indicating the left and right child of the $i$\-th vertex. If $x_i = 0$, then the $i$\-th vertex has no left child; if $y_i = 0$, then the $i$\-th vertex has no right child.

It is guaranteed that the sum of $n$ for all test cases will not exceed $2 \times 10^5$.

**Interaction**

To ask a query, output one line. First output ? followed by a space, then print two different integers $u$ and $v$ ($1 \le u, v \le n$) separated by a space. After flushing your output, your program should read a single integer $t$ indicating the answer to your query.

If you want to guess the special vertex, output one line. First output ! followed by a space, then print an integer $s$ ($1 \le s \le n$) indicating the special vertex. After flushing your output, your program should continue processing the next test case, or exit immediately if there are no more test cases. Note that your guess does not count as a query.

To flush your output, you can use:

-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java.
-   stdout.flush() in Python.

Example Input1：
2
5
0 0
1 5
2 4
0 0
0 0

1

0

2
0 2
0 0

2
Example Output1：







? 5 1

? 1 4

! 2



? 2 1

! 1


## Solution


import math
import sys

def find_special_vertex(n, edges):
    max_depth = math.floor(math.log2(n))
    root = 1

    def query(u, v):
        print(f"? {u} {v}", flush=True)
        return int(input())

    def dfs(node, depth):
        if depth > max_depth:
            return node

        left, right = edges[node-1]
        if left == 0 and right == 0:
            return node

        if left == 0:
            return dfs(right, depth+1)
        elif right == 0:
            return dfs(left, depth+1)
        else:
            res = query(left, right)
            if res == 0:
                return dfs(left, depth+1)
            elif res == 2:
                return dfs(right, depth+1)
            else:
                return dfs(left, depth+1)

    special_vertex = dfs(root, 0)
    print(f"! {special_vertex}", flush=True)

T = int(input())
for _ in range(T):
    n = int(input())
    edges = []
    for _ in range(n):
        u, v = map(int, input().split())
        edges.append((u, v))
    find_special_vertex(n, edges)



## CODE


import math
import sys

def find_special_vertex(n, edges):
    max_depth = math.floor(math.log2(n))
    root = 1

    def query(u, v):
        print(f"? {u} {v}", flush=True)
        return int(input())

    def dfs(node, depth):
        if depth > max_depth:
            return node

        left, right = edges[node-1]
        if left == 0 and right == 0:
            return node

        if left == 0:
            return dfs(right, depth+1)
        elif right == 0:
            return dfs(left, depth+1)
        else:
            res = query(left, right)
            if res == 0:
                return dfs(left, depth+1)
            elif res == 2:
                return dfs(right, depth+1)
            else:
                return dfs(left, depth+1)

    special_vertex = dfs(root, 0)
    print(f"! {special_vertex}", flush=True)

T = int(input())
for _ in range(T):
    n = int(input())
    edges = []
    for _ in range(n):
        u, v = map(int, input().split())
        edges.append((u, v))
    find_special_vertex(n, edges)


### Explanation
The solution uses a depth-first search (DFS) approach to find the special vertex in the binary tree. It starts at the root node and recursively explores the tree, using the query function to determine which child node to visit next. The query function returns an integer indicating which node is closer to the special vertex. The DFS function continues until it reaches a node at a depth greater than the maximum allowed depth (log2(n)), at which point it returns the current node as the special vertex. The solution then prints the special vertex using the "!" command.
## Token
[389, 870, 1259]
 ### 

## Question


(I)
Given two integers $n$, $m$ and an integer sequence $a_1, a_2, \cdots, a_{nm}$ of length $n \times m$, we're going to fill a grid of $n$ rows and $m$ columns with the integers from the sequence. More specifically, let $(i, j)$ be the cell on the $i$\-th row and the $j$\-th column, we'll put the $((i - 1) \times m + j)$\-th element of the sequence (that is, $a_{(i - 1) \times m + j}$) into that cell.

We say an integer $k$ is a "bingo integer" of the sequence, if after filling all the cells, at least one of the two following conditions is satisfied.

-   There is at least one row, where all integers in the cells of that row are less than or equal to $k$.
-   There is at least one column, where all integers in the cells of that column are less than or equal to $k$.

It is easy to see that a sequence may have multiple bingo integers, however in this problem, we're only interested in the smallest bingo integer.

Calculate the sum of the smallest bingo integers for all $(nm)!$ permutations of the given sequence. As the answer may be large, output the answer modulo $998\,244\,353$.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $m$ ($1 \le n, m \le 2 \times 10^5$, $1 \le n \times m \le 2 \times 10^5$), indicating the number of rows and columns of the grid.

The second line contains $n \times m$ integers $a_1, a_2, \cdots, a_{nm}$ ($0 \le a_i &lt; 998\,244\,353$) indicating the given sequence.

It's guaranteed that the sum of $n \times m$ of all test cases will not exceed $4 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the answer.

Example Input1：
2 2
1 3 2 4
Example Output1：
56

Example Input2：
3 1
10 10 10
Example Output2：
60

Example Input3：
1 3
20 10 30
Example Output3：
60

Example Input4：
3 4
1 1 4 5 1 4 1 9 1 9 8 10
Example Output4：
855346687

**Note**

For the first sample test case, if $1$ and $2$ are not on the same row or column, then the smallest bingo integer will be $3$, otherwise the smallest bingo integer will be $2$. There are $8$ permutations where $1$ and $2$ are not on the same row or column, so the answer is $8 \times 3 + (4! - 8) \times 2 = 56$.

For the second sample test case, the smallest bingo integer is always $10$, so the answer is $3! \times 10 = 60$.


## Solution


import sys
input = sys.stdin.readline

mod = 998244353

def ksm(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % mod
        a = a * a % mod
        b >>= 1
    return res

def inv(x):
    return ksm(x, mod - 2)

def C(n, m):
    if n < m or n < 0 or m < 0:
        return 0
    return fac[n] * invfac[m] % mod * invfac[n - m] % mod

N = int(4e5) + 10
fac = [1] * N
invfac = [1] * N
for i in range(1, N):
    fac[i] = fac[i - 1] * i % mod
    invfac[i] = inv(fac[i])

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    ans = 0
    for i in range(n * m):
        ans = (ans + a[i] * (fac[i] * fac[n * m - i - 1] % mod * (C(n * m - i - 1, m - 1) - C(n * m - i - 1, m) + C(n * m - i - 1, n - 1) - C(n * m - i - 1, n)) % mod)) % mod
    print((ans + mod) % mod)

T = int(input())
for _ in range(T):
    solve()



## CODE


import sys
input = sys.stdin.readline

mod = 998244353

def ksm(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % mod
        a = a * a % mod
        b >>= 1
    return res

def inv(x):
    return ksm(x, mod - 2)

def C(n, m):
    if n < m or n < 0 or m < 0:
        return 0
    return fac[n] * invfac[m] % mod * invfac[n - m] % mod

N = int(4e5) + 10
fac = [1] * N
invfac = [1] * N
for i in range(1, N):
    fac[i] = fac[i - 1] * i % mod
    invfac[i] = inv(fac[i])

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    ans = 0
    for i in range(n * m):
        ans = (ans + a[i] * (fac[i] * fac[n * m - i - 1] % mod * (C(n * m - i - 1, m - 1) - C(n * m - i - 1, m) + C(n * m - i - 1, n - 1) - C(n * m - i - 1, n)) % mod)) % mod
    print((ans + mod) % mod)

T = int(input())
for _ in range(T):
    solve()


### Explanation
This code uses the inclusion-exclusion principle and combinatorics to solve the problem. The main idea is to calculate the number of permutations where the smallest bingo integer is `a[i]` for each `i`. This is done by calculating the number of permutations where `a[i]` is in a row or column with all elements less than or equal to `a[i]`, and then subtracting the number of permutations where `a[i]` is in a row or column with all elements less than `a[i]`. The total sum is then calculated by multiplying the number of permutations by `a[i]` and summing over all `i`.
## Token
[504, 828, 1332]
 ### 

## Question


(J)
On a social media platform, users can leave comments under others' posts to express their thoughts. However, these comments are not visible to everyone. Specifically, for user $C$ to see user $A$'s comments under user $B$'s post, he/she has to be friends with both $A$ and $B$ at the same time. If a user leaves a comment under his/her own post, all his/her friends can see this comment.

As an active user on this platform, you would like to see as many comments as possible. There are $k$ users (not counting you) on the platform, numbered from $1$ to $k$. There are also $m$ comments on the platform, but you might not be able to see them all because you only have $n$ friends. As you need to participate in the 2024 ICPC Asia Nanjing Regional Contest, you don't have time to make too many new friends. What's the maximum number of comments you can see if you make at most two new friends on the platform?

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains three integers $n$, $m$, and $k$ ($1 \le n \le k \le 2 \times 10^5$, $1 \le m \le 2 \times 10^5$) indicating the number of your friends, the number of comments, and the number of users (not counting you) on the platform.

The second line contains $n$ distinct integers $f_1, f_2, \cdots, f_n$ ($1 \le f_i \le k$) indicating your friends on the platform.

For the following $m$ lines, the $i$\-th line contains two integers $a_i$ and $b_i$ ($1 \le a_i, b_i \le k$) indicating a comment written by user $a_i$ under user $b_i$'s post.

It's guaranteed that neither the sum of $k$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of comments you can see if you make at most two new friends on the platform.

Example Input1：
4 12 7
5 7 3 6
3 6
2 2
1 4
2 4
1 3
7 6
4 1
5 4
1 1
1 1
2 1
3 7
Example Output1：
9

Example Input2：
2 7 6
2 4
1 2
3 2
2 5
5 4
2 6
4 6
2 6
Example Output2：
5

Example Input3：
1 1 2
1
1 2
Example Output3：
1

Example Input4：
2 1 2
1 2
1 2
Example Output4：
1

Example Input5：
2 1 100
24 11
11 24
Example Output5：
1

**Note**

For the first sample test case, you can make friends with user $1$ and $4$.

For the second sample test case, you can make friends with user $5$ and $6$.

For the third sample test case, you can make friends with user $2$.

For the fourth and fifth sample test cases, you don't need to make new friends because you can already see all comments.


## Solution


from collections import defaultdict

def solve():
    n, m, k = map(int, input().split())
    friends = set(map(int, input().split()))
    comments = defaultdict(lambda: defaultdict(int))

    for _ in range(m):
        a, b = map(int, input().split())
        comments[a][b] += 1

    ans = 0
    cands = defaultdict(int)

    for a in comments:
        for b in comments[a]:
            if a in friends and b in friends:
                ans += comments[a][b]
            elif a in friends:
                cands[b] += comments[a][b]
            elif b in friends:
                cands[a] += comments[a][b]
            else:
                cands[a] += comments[a][b]
                cands[b] += comments[a][b]

    cands_list = sorted(cands.items(), key=lambda x: x[1], reverse=True)

    if len(cands_list) >= 1:
        ans += cands_list[0][1]
    if len(cands_list) >= 2:
        ans += cands_list[1][1]

    new_cands = defaultdict(int)
    for a in comments:
        for b in comments[a]:
            if a not in friends and b not in friends:
                new_cands[(a, b)] += comments[a][b]

    new_cands_list = sorted(new_cands.items(), key=lambda x: x[1], reverse=True)

    if len(cands_list) >= 1 and len(new_cands_list) >= 1:
        ans = max(ans, sum([cands_list[0][1], new_cands_list[0][1]]))

    print(ans)

t = int(input())
for _ in range(t):
    solve()



## CODE


from collections import defaultdict

def solve():
    n, m, k = map(int, input().split())
    friends = set(map(int, input().split()))
    comments = defaultdict(lambda: defaultdict(int))

    for _ in range(m):
        a, b = map(int, input().split())
        comments[a][b] += 1

    ans = 0
    cands = defaultdict(int)

    for a in comments:
        for b in comments[a]:
            if a in friends and b in friends:
                ans += comments[a][b]
            elif a in friends:
                cands[b] += comments[a][b]
            elif b in friends:
                cands[a] += comments[a][b]
            else:
                cands[a] += comments[a][b]
                cands[b] += comments[a][b]

    cands_list = sorted(cands.items(), key=lambda x: x[1], reverse=True)

    if len(cands_list) >= 1:
        ans += cands_list[0][1]
    if len(cands_list) >= 2:
        ans += cands_list[1][1]

    new_cands = defaultdict(int)
    for a in comments:
        for b in comments[a]:
            if a not in friends and b not in friends:
                new_cands[(a, b)] += comments[a][b]

    new_cands_list = sorted(new_cands.items(), key=lambda x: x[1], reverse=True)

    if len(cands_list) >= 1 and len(new_cands_list) >= 1:
        ans = max(ans, sum([cands_list[0][1], new_cands_list[0][1]]))

    print(ans)

t = int(input())
for _ in range(t):
    solve()


### Explanation
The code first reads the input and initializes the variables. It then iterates over the comments and updates the `comments` dictionary.

Next, it calculates the number of comments that can be seen without making any new friends.

Then, it creates a `cands` dictionary to store the number of comments that can be seen by making one new friend. It iterates over the comments again and updates the `cands` dictionary.

After that, it sorts the `cands` dictionary by value in descending order and adds the top two values to the answer.

Finally, it creates a `new_cands` dictionary to store the number of comments that can be seen by making two new friends. It iterates over the comments again and updates the `new_cands` dictionary.

It then sorts the `new_cands` dictionary by value in descending order and adds the top value to the answer if it is greater than the current answer.

The code repeats this process for each test case.
## Token
[586, 888, 1474]
 ### 

## Question


(K)
There are $w$ cells arranged in a row, numbered from $1$ to $w$ from left to right. Among the cells, $n$ of them are red, $m$ of them are black, and the remaining $(w - n - m)$ cells are white.

You need to cover all the red cells with some strips. Each strip must cover $k$ continuous cells. Find a way to cover all red cells while satisfying all the following constraints:

-   Each red cell is covered by a strip.
-   No black cell is covered by a strip.
-   No two strips cover the same cell. That is, each cell is covered by at most one strip.
-   The number of strips used is as small as possible.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains four integers $n$, $m$, $k$ and $w$ ($1 \le n, m \le 10^5$, $1 \le k \le w \le 10^9$, $n + m \le w$), indicating the number of red cells, the number of black cells, the length of each strip and the total number of cells.

The second line contains $n$ integers $a_1, a_2, \cdots, a_n$ ($1 \le a_i \le w$), indicating that cell $a_i$ is red.

The third line contains $m$ integers $b_1, b_2, \cdots, b_m$ ($1 \le b_i \le w$), indicating that cell $b_i$ is black.

It's guaranteed that the given $(n + m)$ cells are distinct. It's also guaranteed that neither the sum of $n$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case:

If it is possible to cover all the red cells while satisfying all constraints, first output one line containing one integer $c$ indicating the smallest number of strips used. Then output another line containing $c$ integers $l_1, l_2, \cdots, l_c$ ($1 \le l_i \le w - k + 1$) separated by a space, where $l_i$ is the left-most cell covered by the $i$\-th strip. If there are multiple valid answers, you can output any of them.

If it is not possible to do so, just output \-1 in one line.

Example Input1：
5 2 3 16
7 11 2 9 14
13 5
Example Output1：
4
6 2 14 9

Example Input2：
3 2 4 11
6 10 2
1 11
Example Output2：
-1

Example Input3：
2 1 2 6
1 5
3
Example Output3：
2
1 4

Example Input4：
2 1 2 6
1 5
2
Example Output4：
-1


## Solution


import sys

def solve(n, m, k, w, reds, blacks):
    blacks = set(blacks)
    reds.sort()

    strips = []
    i = 0
    while i < n:
        start = reds[i]
        end = reds[i] + k - 1
        if end > w:
            return None
        while i < n and reds[i] <= end:
            i += 1
        for j in range(start, end + 1):
            if j in blacks:
                return None
        strips.append(start)

    return strips

def main():
    input = sys.stdin.readline
    T = int(input())
    for _ in range(T):
        n, m, k, w = map(int, input().split())
        reds = list(map(int, input().split()))
        blacks = list(map(int, input().split()))

        strips = solve(n, m, k, w, reds, blacks)
        if strips is None:
            print(-1)
        else:
            print(len(strips))
            print(*strips)

if __name__ == "__main__":
    main()



## CODE


import sys

def solve(n, m, k, w, reds, blacks):
    blacks = set(blacks)
    reds.sort()

    strips = []
    i = 0
    while i < n:
        start = reds[i]
        end = reds[i] + k - 1
        if end > w:
            return None
        while i < n and reds[i] <= end:
            i += 1
        for j in range(start, end + 1):
            if j in blacks:
                return None
        strips.append(start)

    return strips

def main():
    input = sys.stdin.readline
    T = int(input())
    for _ in range(T):
        n, m, k, w = map(int, input().split())
        reds = list(map(int, input().split()))
        blacks = list(map(int, input().split()))

        strips = solve(n, m, k, w, reds, blacks)
        if strips is None:
            print(-1)
        else:
            print(len(strips))
            print(*strips)

if __name__ == "__main__":
    main()


### Explanation
The solution is a greedy algorithm. It sorts the red cells and then iterates over them, trying to cover as many red cells as possible with each strip. It checks if a strip can be placed at the current position by checking if there are any black cells in the range of the strip. If a strip can be placed, it adds the start position of the strip to the result list and moves on to the next uncovered red cell. If a strip cannot be placed, it returns None to indicate that it is impossible to cover all red cells.
## Token
[365, 771, 1136]
 ### 

## Question


(M)
Neuvillette is the Chief Justice of Fontaine, known as the Iudex, and he is renowned for his unassailable impartiality. As a playable character in the world-famous game Genshin Impact, he is known for his powerful charged attack that can hit enemies within a specific range.

Since he is very powerful, many players use him while challenging almost every quest. However, not everybody in Teyvat is happy about this, especially other ADC (Attack Damage Carry) characters, including Kamisato Ayaka, Keqing, etc. Together, they decide to persuade Mihoyo to nerf Neuvillette in the game. To do so, they must submit a report about Neuvillette's total damage in several scenarios.

Created from Genshin Impact official material

Each battle scenario happens on a two-dimensional plane. Neuvillette stands on $(0,0)$ facing $(x_0, y_0)$ initially, making a charged attack which lasts for $t$ units of time, and rotates $1$ rad counter-clockwise per unit of time. That is to say, Neuvillette turns a circle counter-clockwise in $2 \pi$ units of time.

Consider a ray from $(0,0)$ towards the direction Neuvillette faces. The attack range is the set of points whose distance to the ray is at most $d$. If the target, whose shape is a convex polygon, has common points with the attack range, it will suffer $1$ continued damage per unit of time.

As an experienced programmer, you are summoned by Ayaka. This time, your task is to calculate the damage the target incurs in the first $t$ units of time.

**Input**

There is only one test case in each test file.

The first line contains five integers $n$, $x_0$, $y_0$, $d$, and $t$ ($3 \le n \le 100$, $-10^4 \le x_0, y_0 \le 10^4$, $x_0^2 + y_0^2 &gt; 0$, $1 \le d, t \le 10^4$).

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($-10^4 \le x_i, y_i \le 10^4$), indicating the coordinates of the $i$\-th vertex of the convex polygon.

All $n$ vertices are given in counter-clockwise order, and any three of them are not collinear. It is also guaranteed that the shape has no common points with the circle centered at $(0,0)$ with radius $d$. That is to say, there does not exist a point inside or on the boundary of the convex polygon, while at the same time inside or on the boundary of the circle.

**Output**

Output one line containing one real number, indicating the damage the target incurs in the first $t$ units of time.

Your answer will be considered correct if its absolute or relative error does not exceed $10^{-6}$. Formally speaking, suppose that your output is $a$ and the jury's answer is $b$, your output is accepted if and only if $\frac{|a - b|}{\max(1, |b|)} \le 10^{-6}$.

Example Input1：
3 1 0 1 1
1 2
2 1
2 2
Example Output1：
1.000000000000

Example Input2：
3 1 0 1 2
1 2
2 1
2 2
Example Output2：
1.570796326795

Example Input3：
3 1 0 1 10000
1 2
2 1
2 2
Example Output3：
2500.707752257475
## Solution


import math

def cross_product(p1, p2):
    return p1[0] * p2[1] - p1[1] * p2[0]

def get_line_intersection(line1, line2):
    xdiff = (line1[0][0] - line1[1][0], line2[0][0] - line2[1][0])
    ydiff = (line1[0][1] - line1[1][1], line2[0][1] - line2[1][1])

    def det(a, b):
        return a[0] * b[1] - a[1] * b[0]

    div = det(xdiff, ydiff)
    if div == 0:
       return None

    d = (det(*line1), det(*line2))
    x = det(d, xdiff) / div
    y = det(d, ydiff) / div
    return (x, y)

def angle(p):
    return math.atan2(p[1], p[0])

def get_intersection_time(p1, p2, d, initial_angle, start_time):
    intersection = get_line_intersection(((0,0), (p1[0] + d * p1[1], p1[0] - d * p1[0])), ((0,0), p2))
    if intersection is None:
        return None

    intersection_angle = angle(intersection)
    if intersection_angle < initial_angle:
        intersection_angle += 2 * math.pi

    return start_time + intersection_angle - initial_angle

def get_damage(points, initial_point, d, t):
    initial_angle = angle(initial_point)
    points = [(point[0] - d * point[1], point[0] + d * point[1]) for point in points]
    points.sort(key=lambda p: angle(p))

    current_point_index = 0
    current_time = 0
    total_damage = 0

    while current_time < t:
        next_point_index = (current_point_index + 1) % len(points)
        intersection_time = get_intersection_time(points[current_point_index], points[next_point_index], d, initial_angle, current_time)
        if intersection_time is None:
            next_point_index = (next_point_index + 1) % len(points)
            intersection_time = get_intersection_time(points[current_point_index], points[next_point_index], d, initial_angle, current_time)
            if intersection_time is None:
                break

        intersection_time = max(intersection_time, current_time)
        if intersection_time > t:
            total_damage += t - current_time
            break

        total_damage += intersection_time - current_time
        current_time = intersection_time
        current_point_index = next_point_index

    return total_damage

n, x0, y0, d, t = map(float, input().split())
points = [tuple(map(float, input().split())) for _ in range(int(n))]
initial_point = (x0, y0)

damage = get_damage(points, initial_point, d, t)
print(damage)



## CODE


import math

def cross_product(p1, p2):
    return p1[0] * p2[1] - p1[1] * p2[0]

def get_line_intersection(line1, line2):
    xdiff = (line1[0][0] - line1[1][0], line2[0][0] - line2[1][0])
    ydiff = (line1[0][1] - line1[1][1], line2[0][1] - line2[1][1])

    def det(a, b):
        return a[0] * b[1] - a[1] * b[0]

    div = det(xdiff, ydiff)
    if div == 0:
       return None

    d = (det(*line1), det(*line2))
    x = det(d, xdiff) / div
    y = det(d, ydiff) / div
    return (x, y)

def angle(p):
    return math.atan2(p[1], p[0])

def get_intersection_time(p1, p2, d, initial_angle, start_time):
    intersection = get_line_intersection(((0,0), (p1[0] + d * p1[1], p1[0] - d * p1[0])), ((0,0), p2))
    if intersection is None:
        return None

    intersection_angle = angle(intersection)
    if intersection_angle < initial_angle:
        intersection_angle += 2 * math.pi

    return start_time + intersection_angle - initial_angle

def get_damage(points, initial_point, d, t):
    initial_angle = angle(initial_point)
    points = [(point[0] - d * point[1], point[0] + d * point[1]) for point in points]
    points.sort(key=lambda p: angle(p))

    current_point_index = 0
    current_time = 0
    total_damage = 0

    while current_time < t:
        next_point_index = (current_point_index + 1) % len(points)
        intersection_time = get_intersection_time(points[current_point_index], points[next_point_index], d, initial_angle, current_time)
        if intersection_time is None:
            next_point_index = (next_point_index + 1) % len(points)
            intersection_time = get_intersection_time(points[current_point_index], points[next_point_index], d, initial_angle, current_time)
            if intersection_time is None:
                break

        intersection_time = max(intersection_time, current_time)
        if intersection_time > t:
            total_damage += t - current_time
            break

        total_damage += intersection_time - current_time
        current_time = intersection_time
        current_point_index = next_point_index

    return total_damage

n, x0, y0, d, t = map(float, input().split())
points = [tuple(map(float, input().split())) for _ in range(int(n))]
initial_point = (x0, y0)

damage = get_damage(points, initial_point, d, t)
print(damage)


### Explanation
This solution works by simulating the movement of Neuvillette's attack range over time and calculating the intersection points with the target polygon. It uses the concept of line sweeping to efficiently find the intersection points. The algorithm first sorts the points of the polygon based on their angles with respect to the initial direction of Neuvillette's attack. Then, it iterates over the points and calculates the intersection time with the next point. If an intersection is found, it updates the current time and adds the time difference to the total damage. The process continues until the total time exceeds the given time `t`. The solution handles cases where the intersection point is not found by checking the intersection with the next point in the sorted list.
## Token
[815, 923, 1738]
 ### 

