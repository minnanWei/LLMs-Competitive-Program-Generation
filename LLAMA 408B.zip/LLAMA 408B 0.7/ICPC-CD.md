## Question
(A)
Define an "arrow string" as a string that meets the following conditions:

-   The length of the string is at least $5$.
-   The string starts with \> and ends with \>\>\>.
-   The rest of the string consists only of \-.

For example, \>\-\-\>\>\> and \>\-\-\-\>\>\> are valid arrow strings, while \>\-\>\> and \>\-\>\-\>\>\> are not.

Sauden gives you a string $s$ of length $n$, consisting of \> and \-. You need to create $s$ by performing a series of painting operations on a string of the same length $n$ that consists entirely of \*. In one painting operation, you can choose a substring of length at least $5$ and transform it into an arrow string. The total number of operations you perform cannot exceed $n$.

If it is impossible to obtain the string $s$ using no more than $n$ painting operations, output $\texttt{No}$. Otherwise, output $\texttt{Yes}$ and provide the details of the painting operations. If there are multiple solutions, output any.

**Input**

The first line contains a single integer $T$ ($1\le T\le 10^4$), indicating the number of test cases.

Each test case contains a string $s$ of length $n$ ($5 \le n \le 10^5$) in a single line, consisting only of \> and \-.

It is guaranteed that the sum of $n$ over all test cases does not exceed $5 \cdot 10^5$.

**Output**

For each test case, if the given string cannot be obtained by performing no more than $n$ painting operations, output $\texttt{No}$ in a single line. Otherwise, output $\texttt{Yes}$ and a positive integer $m$ ($1 \le m \le n$), which denotes the number of painting operations to perform. Then output $m$ lines, each contains two integers $p$ ($1\le p\le n-4$) and $l$ ($5\le l\le n+1-p$), indicating the starting position of the selected substring and its length.

Example Input1：
4
>>->>>
>>>->
>>>>>
>->>>>>>

Example Output1：
Yes 2
1 5
2 5
No
No
Yes 2
2 7
1 5

**Note**

For the fourth test case in the example, the painting process is shown below::

\*\*\*\*\*\*\*\* $\rightarrow$ \*\>\-\-\-\>\>\> $\rightarrow$ \>\-\>\>\>\>\>\>


## Solution


def solve(s):
    n = len(s)
    if s[0] != '>' or s[-3:] != '>>>':
        return False, []
    operations = []
    i = 0
    while i < n:
        if s[i] == '>':
            j = i + 1
            while j < n and s[j] == '-':
                j += 1
            if j + 3 >= n or s[j:j+3] != '>>>':
                return False, []
            operations.append((i, j - i + 4))
            i = j + 3
        else:
            i += 1
    return True, operations

t = int(input())
for _ in range(t):
    s = input()
    result, operations = solve(s)
    if result:
        print('Yes', len(operations))
        for op in operations:
            print(op[0] + 1, op[1])
    else:
        print('No')



## CODE


def solve(s):
    n = len(s)
    if s[0] != '>' or s[-3:] != '>>>':
        return False, []
    operations = []
    i = 0
    while i < n:
        if s[i] == '>':
            j = i + 1
            while j < n and s[j] == '-':
                j += 1
            if j + 3 >= n or s[j:j+3] != '>>>':
                return False, []
            operations.append((i, j - i + 4))
            i = j + 3
        else:
            i += 1
    return True, operations

t = int(input())
for _ in range(t):
    s = input()
    result, operations = solve(s)
    if result:
        print('Yes', len(operations))
        for op in operations:
            print(op[0] + 1, op[1])
    else:
        print('No')


### Explanation
The code uses a greedy algorithm to solve the problem. It checks the input string `s` and if it meets the conditions for an "arrow string", it attempts to construct the string by performing painting operations. If it's possible to construct the string, it outputs "Yes" and the details of the painting operations. If it's not possible, it outputs "No". The time complexity of the algorithm is O(n), where n is the length of the input string.
## Token
[315, 677, 992]
 ### 

## Question


(B)
Chengdu is about to host the 2025 World Games. During the athlete welcome ceremony at the opening event, there will be $n$ volunteers dressed in one of three different types of traditional folk costumes, lined up to welcome the athletes. These costumes are denoted by type $\texttt{a}$, $\texttt{b}$, and $\texttt{c}$. The positions of the volunteers have been determined, and now we need to assign costumes to the volunteers. To achieve a specific visual effect, adjacent volunteers must not wear the same type of costume.

Among the $n$ volunteers, some already have one of the three types of folk costumes, while others do not have any and require custom-made costumes provided by the organizers. There are $Q$ custom-making plans, each specifying: making $x$ sets of costumes $\texttt{a}$, $y$ sets of costumes $\texttt{b}$, and $z$ sets of costumes $\texttt{c}$.

For each custom-making plan, determine how many different valid costume arrangements can be made after distributing the custom-made costumes to the volunteers who do not have any costumes. Specifically, determine the number of ways for assigning costumes $\texttt{a}$, $\texttt{b}$ and $\texttt{c}$ under the condition of not exceeding the limits of the given plan. If two arrangements differ in the type of costume assigned to the same volunteer, they are considered different. Note that the same type of costumes are not distinguished from each other. As the number may be very large, please output the answer modulo $10^9+7$.
**Input**

The first line contains two integers $n$ ($1\le n\le 300$) and $Q$ ($1\le Q\le 10^5$), representing the number of volunteers and the number of custom-making plans, respectively.

The second line is a string $s$ of length $n$. It is guaranteed that the string $s$ contains only the characters $\texttt{a}$, $\texttt{b}$, $\texttt{c}$, and $\texttt{?}$. If the $i$\-th character is one of $\texttt{a}$, $\texttt{b}$, and $\texttt{c}$, it indicates that the $i$\-th volunteer already has the corresponding costume; otherwise, if it is $\texttt{?}$, it indicates that the $i$\-th volunteer does not have any costume.

Each of the next $Q$ lines contains three integers $x, y, z$ ($0 \le x, y, z \le 300$), representing a custom-making plan. It is guaranteed that the sum $x+y+z$ is no less than the number of volunteers without costumes.

**Output**

Output $Q$ lines, with the $i$\-th line containing an integer that represents the number of valid costume arrangements that satisfy the requirements for the $i$\-th custom-making plan. Please output the answer modulo $10^9+7$.

Example Input1：
6 3
a?b??c
2 2 2
1 1 1
1 0 2
Example Output1：
3
1
1

Example Input2：
6 3
??????
2 2 2
2 3 3
3 3 3
Example Output2：
30
72
96

**Note**

In the first sample, the valid costume arrangements for the first custom-making plan are $\texttt{acbabc}$, $\texttt{acbcac}$, and $\texttt{acbcbc}$.


## Solution


MOD = 10**9 + 7

def dp(n, s, x, y, z):
    cnt = {'a': x, 'b': y, 'c': z}
    for i in range(n):
        if s[i] != '?':
            cnt[s[i]] -= 1

    memo = {}
    def dfs(i, prev):
        if (i, prev) in memo:
            return memo[(i, prev)]
        if i == n:
            return 1

        if s[i] != '?':
            res = dfs(i + 1, s[i])
        else:
            res = 0
            for char in 'abc':
                if char != prev and cnt[char] > 0:
                    cnt[char] -= 1
                    res += dfs(i + 1, char)
                    cnt[char] += 1
                    res %= MOD

        memo[(i, prev)] = res
        return res

    res = dfs(0, '')
    return res

def main():
    n, Q = map(int, input().split())
    s = input()

    memo = {}
    for _ in range(Q):
        x, y, z = map(int, input().split())
        if (x, y, z) in memo:
            print(memo[(x, y, z)])
            continue
        res = dp(n, s, x, y, z)
        memo[(x, y, z)] = res
        print(res)

if __name__ == '__main__':
    main()



## CODE


MOD = 10**9 + 7

def dp(n, s, x, y, z):
    cnt = {'a': x, 'b': y, 'c': z}
    for i in range(n):
        if s[i] != '?':
            cnt[s[i]] -= 1

    memo = {}
    def dfs(i, prev):
        if (i, prev) in memo:
            return memo[(i, prev)]
        if i == n:
            return 1

        if s[i] != '?':
            res = dfs(i + 1, s[i])
        else:
            res = 0
            for char in 'abc':
                if char != prev and cnt[char] > 0:
                    cnt[char] -= 1
                    res += dfs(i + 1, char)
                    cnt[char] += 1
                    res %= MOD

        memo[(i, prev)] = res
        return res

    res = dfs(0, '')
    return res

def main():
    n, Q = map(int, input().split())
    s = input()

    memo = {}
    for _ in range(Q):
        x, y, z = map(int, input().split())
        if (x, y, z) in memo:
            print(memo[(x, y, z)])
            continue
        res = dp(n, s, x, y, z)
        memo[(x, y, z)] = res
        print(res)

if __name__ == '__main__':
    main()


### Explanation
We use a depth-first search (DFS) approach with memoization to calculate the number of valid costume arrangements for each custom-making plan. The DFS function takes two parameters: the current volunteer index `i` and the previous volunteer's costume `prev`. If the current volunteer's costume is already determined, we recursively call the DFS function for the next volunteer. If the current volunteer's costume is not determined, we try all possible costumes that are different from the previous volunteer's costume and recursively call the DFS function for each possibility. We use memoization to store the results of subproblems to avoid redundant calculations. The final result is the sum of the results of all possible costume arrangements for the first volunteer. We use the modulo operator to ensure that the result is within the range of `10^9 + 7`.
## Token
[499, 866, 1365]
 ### 

## Question


(D)
Blackbird has a permutation $p$ of length $n$. He wants to find a derangement $q$ of $p$, which means $q$ is another permutation of length $n$ satisfying $q_i\neq p_i$ for each $i=1,2,\ldots,n$. At the same time, $\sum_{i=1}^{n}|p_i-q_i|$ should be minimized. A permutation $q$ that satisfies the above conditions is called the closest derangement of $p$.

There may be multiple closest derangements of $p$, and your task is to output the $k$\-th smallest closest derangement in lexicographical order. If there are fewer than $k$ closest derangements of $p$, output $-1$.

A permutation of length $n$ refers to a sequence of length $n$ where all elements are distinct and are positive integers from $1$ to $n$. Permutations can be sorted in lexicographical order. Let $a$ and $b$ be two distinct permutations of length $n$. Then, $a &lt; b$ if and only if at the smallest index $i$ where $a_i \neq b_i$, it holds that $a_i &lt; b_i$.

**Input**

The first line contains an integer $T$ ($1\le T\le 10^4$), representing the number of test cases.

For each test case, the first line contains two positive integers $n$ ($2\le n \le 2 \cdot 10^5$) and $k$ ($1\le k \le 10^9$). The second line contains $n$ positive integers $p_1, p_2, \ldots, p_n$, representing the permutation $p$.

It is guaranteed that the sum of $n$ over all test cases does not exceed $10^6$.

**Output**

For each test case, if there are at least $k$ closest derangements, output $n$ positive integers $q_1, q_2, \ldots, q_n$ in a single line separated by spaces, representing the $k$\-th smallest closest derangement of $p$ in lexicographical order. Otherwise, output $-1$.

Example Input1：
2
2 2
2 1
3 2
1 2 3
Example Output1：
-1
3 1 2 

**Note**

For the first test case, $[1,2]$ is the only closest derangement, so output $-1$.

For the second test case, $[2,3,1]$ and $[3,1,2]$ are closest derangements of $p$, and $[3,1,2]$ is larger than $[2,3,1]$ in lexicographical order.


## Solution


import math

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    p = list(map(int, input().split()))
    for i in range(n):
        p[i] -= 1
    total = 0
    s = [0] * n
    t = [0] * n
    cycle = []
    cycles = []
    for i in range(n):
        if s[i]:
            continue
        s[i] = 1
        cycle.append(i)
        j = p[i]
        while j != i:
            s[j] = 1
            cycle.append(j)
            j = p[j]
        cycles.append(cycle)
        cycle = []

    s = [0] * n
    for c in cycles:
        if len(c) == 1:
            s[c[0]] = 1
    for i in range(n):
        if s[i]:
            continue
        s[i] = 1
        total += 1
        j = p[i]
        while j != i:
            s[j] = 1
            j = p[j]
    ans = [0] * n
    if n - total <= math.log2(k):
        for i in range(n):
            t[i] = p[i]
        d = [[0] * n for _ in range(n)]
        for i in range(n):
            if i == t[i]:
                d[i][i] = 1
                for j in range(n):
                    if j != i:
                        d[i][j] = 10 ** 18
            else:
                for j in range(n):
                    if j != i:
                        d[i][j] = abs(i - j)
                        if t[j] == i:
                            d[i][j] += 10 ** 18
        for i in range(n):
            for j in range(n):
                if j != i:
                    for l in range(n):
                        if l != j and l != i:
                            if d[i][l] > d[i][j] + d[j][l]:
                                d[i][l] = d[i][j] + d[j][l]
        K = k
        for i in range(n):
            while True:
                fl = False
                for j in range(n):
                    if ans[j] == 0:
                        fl = True
                        break
                if not fl:
                    break
                min_dis = 10 ** 18
                for j in range(n):
                    if ans[j] == 0 and d[j][t[i]] < min_dis:
                        min_dis = d[j][t[i]]
                K -= 1
                ans[t[i]] = i + 1
                i += 1
                if K == 0:
                    break
            if K == 0:
                break
        for i in range(n):
            print(ans[i], end = ' ')
        print()
        continue
    else:
        if k > math.factorial(total) // 2:
            print(-1)
            continue
    k -= 1
    for i in range(n):
        if t[i]:
            continue
        if p[i] != i:
            ans[i] = p[i] + 1
            t[p[i]] = 1
        else:
            ans[i] = 0
    for c in cycles:
        if len(c) == 1:
            continue
        if k % 2:
            ans[c[0]] = c[-1] + 1
            for i in range(len(c) - 1, 0, -1):
                ans[c[i]] = c[i - 1] + 1
        else:
            for i in range(len(c)):
                ans[c[i]] = c[(i + 1) % len(c)] + 1
        k //= 2
    for i in range(n):
        if not ans[i]:
            for j in range(n):
                if j != i and not t[j]:
                    ans[i] = j + 1
                    t[j] = 1
                    break
    for i in range(n):
        print(ans[i], end = ' ')
    print()


## CODE


import math

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    p = list(map(int, input().split()))
    for i in range(n):
        p[i] -= 1
    total = 0
    s = [0] * n
    t = [0] * n
    cycle = []
    cycles = []
    for i in range(n):
        if s[i]:
            continue
        s[i] = 1
        cycle.append(i)
        j = p[i]
        while j != i:
            s[j] = 1
            cycle.append(j)
            j = p[j]
        cycles.append(cycle)
        cycle = []

    s = [0] * n
    for c in cycles:
        if len(c) == 1:
            s[c[0]] = 1
    for i in range(n):
        if s[i]:
            continue
        s[i] = 1
        total += 1
        j = p[i]
        while j != i:
            s[j] = 1
            j = p[j]
    ans = [0] * n
    if n - total <= math.log2(k):
        for i in range(n):
            t[i] = p[i]
        d = [[0] * n for _ in range(n)]
        for i in range(n):
            if i == t[i]:
                d[i][i] = 1
                for j in range(n):
                    if j != i:
                        d[i][j] = 10 ** 18
            else:
                for j in range(n):
                    if j != i:
                        d[i][j] = abs(i - j)
                        if t[j] == i:
                            d[i][j] += 10 ** 18
        for i in range(n):
            for j in range(n):
                if j != i:
                    for l in range(n):
                        if l != j and l != i:
                            if d[i][l] > d[i][j] + d[j][l]:
                                d[i][l] = d[i][j] + d[j][l]
        K = k
        for i in range(n):
            while True:
                fl = False
                for j in range(n):
                    if ans[j] == 0:
                        fl = True
                        break
                if not fl:
                    break
                min_dis = 10 ** 18
                for j in range(n):
                    if ans[j] == 0 and d[j][t[i]] < min_dis:
                        min_dis = d[j][t[i]]
                K -= 1
                ans[t[i]] = i + 1
                i += 1
                if K == 0:
                    break
            if K == 0:
                break
        for i in range(n):
            print(ans[i], end = ' ')
        print()
        continue
    else:
        if k > math.factorial(total) // 2:
            print(-1)
            continue
    k -= 1
    for i in range(n):
        if t[i]:
            continue
        if p[i] != i:
            ans[i] = p[i] + 1
            t[p[i]] = 1
        else:
            ans[i] = 0
    for c in cycles:
        if len(c) == 1:
            continue
        if k % 2:
            ans[c[0]] = c[-1] + 1
            for i in range(len(c) - 1, 0, -1):
                ans[c[i]] = c[i - 1] + 1
        else:
            for i in range(len(c)):
                ans[c[i]] = c[(i + 1) % len(c)] + 1
        k //= 2
    for i in range(n):
        if not ans[i]:
            for j in range(n):
                if j != i and not t[j]:
                    ans[i] = j + 1
                    t[j] = 1
                    break
    for i in range(n):
        print(ans[i], end = ' ')
    print()

### Explanation
This problem asks us to find the k-th smallest derangement of a given permutation. To solve this problem, we can first determine the cycles in the given permutation. Then, for each cycle, we can either rotate it to the left or to the right to get a derangement. We can use binary representation to represent the rotation of each cycle. We can also use Dijkstra's algorithm to calculate the minimum distance between two elements in the derangement. We can then use this information to construct the k-th smallest derangement. If k is larger than the total number of derangements, we can output -1.
## Token
[1033, 705, 1738]
 ### 

## Question


(E)
The enemy has established communication outposts across several locations, which can be represented as nodes and edges in a network. This network forms a tree — a type of graph that is connected and has no cycles. As a specialist in communications engineering, your task is to disrupt their communications.

Each communication occurs along a simple path between two nodes in the tree. You have the ability to select a subgraph of this tree and disrupt every node in that subgraph. If the communication path includes a disrupted node, the communication is successfully disrupted. The subgraph you select must consist of a subset of nodes and edges from the original tree, and it must be connected, meaning it is also a tree.

The communication network consists of $n$ nodes, labeled from $1$ to $n$. Your mission involves answering $q$ separate queries. For each query, you are given two nodes, $u_i$ and $v_i$, and you must determine how many different subgraphs you can select to disrupt the communication between the two nodes. Since the number may be very large, you should provide the answer modulo $998244353$. It is possible that $u_i=v_i$, which indicates an internal communication within a node, and you are also able to disrupt it by selecting a subgraph that contains the node.

**Input**

The first line contains a single integer $T$ ($1\le T \le 10^4$), indicating the number of test cases.

The first line of each test case contains two integers $n$ ($2\le n\le 10^5$) and $q$ ($1\le q \le 10^5$), denoting the number of nodes and the number of queries.

The second line contains $n-1$ integers $p_2,p_3,\ldots ,p_n$ ($1\le p_i &lt; i$), indicating that nodes $i$ and $p_i$ are connected by an edge.

Each of the next $q$ lines contains two integers $u_i,v_i$ ($1\le u_i,v_i \le n$), representing the $i$\-th query.

It is guaranteed that the sum of $n$ and the sum of $q$ over all test cases do not exceed $3\cdot 10^5$, respectively.

**Output**

For each test case, output $q$ lines, each containing the result modulo $998244353$ for one of the $q$ queries.

Example Input:
2
3 2
1 1
2 3
1 2
5 3
1 1 2 2
4 5
2 4
2 3
Example Output：
6
5
14
13
15

**Note**

In the first case of the example, $6$ connected subgraphs can be selected in total. For the first query, all of them can disrupt the communication. For the second query, $5$ of them can disrupt the communication; the exception is the subgraph consisting only of node $3$.


## Solution


MOD = 998244353

def dfs(u, fa, dep, p, siz, dp):
    siz[u] = 1
    dp[u] = dep[u]
    for v in p[u]:
        if v == fa:
            continue
        dep[v] = dep[u] + 1
        dfs(v, u, dep, p, siz, dp)
        siz[u] += siz[v]
        dp[u] = (dp[u] * (dp[v] + 1)) % MOD

def solve():
    n, q = map(int, input().split())
    p = [[] for _ in range(n + 1)]
    a = list(map(int, input().split()))
    for i in range(1, n):
        p[a[i - 1]].append(i + 1)
        p[i + 1].append(a[i - 1])
    
    siz = [0] * (n + 1)
    dep = [0] * (n + 1)
    dp = [0] * (n + 1)
    dfs(1, 0, dep, p, siz, dp)
    
    for _ in range(q):
        u, v = map(int, input().split())
        if dep[u] < dep[v]:
            u, v = v, u
        tmp = dp[u] * (dp[v] - dp[u] + 1) % MOD
        if tmp < 0:
            tmp += MOD
        print((tmp * (siz[1] - siz[u] + 1)) % MOD)

T = int(input())
for _ in range(T):
    solve()



## CODE


MOD = 998244353

def dfs(u, fa, dep, p, siz, dp):
    siz[u] = 1
    dp[u] = dep[u]
    for v in p[u]:
        if v == fa:
            continue
        dep[v] = dep[u] + 1
        dfs(v, u, dep, p, siz, dp)
        siz[u] += siz[v]
        dp[u] = (dp[u] * (dp[v] + 1)) % MOD

def solve():
    n, q = map(int, input().split())
    p = [[] for _ in range(n + 1)]
    a = list(map(int, input().split()))
    for i in range(1, n):
        p[a[i - 1]].append(i + 1)
        p[i + 1].append(a[i - 1])
    
    siz = [0] * (n + 1)
    dep = [0] * (n + 1)
    dp = [0] * (n + 1)
    dfs(1, 0, dep, p, siz, dp)
    
    for _ in range(q):
        u, v = map(int, input().split())
        if dep[u] < dep[v]:
            u, v = v, u
        tmp = dp[u] * (dp[v] - dp[u] + 1) % MOD
        if tmp < 0:
            tmp += MOD
        print((tmp * (siz[1] - siz[u] + 1)) % MOD)

T = int(input())
for _ in range(T):
    solve()


### Explanation
We use the Depth-First Search (DFS) algorithm to calculate the size of each subtree and the number of possible subgraphs for each node. We maintain an array `dp` where `dp[u]` represents the number of possible subgraphs that include node `u` and all its children. For each node `u`, we iterate over its children `v` and update `dp[u]` as the product of `dp[u]` and `dp[v] + 1`, which represents the number of possible subgraphs that include node `u` and all its children except `v`, and the subgraph that includes only node `u`.

When answering queries, we calculate the number of possible subgraphs that include both nodes `u` and `v` by multiplying the number of possible subgraphs that include node `u` and all its children except `v` with the number of possible subgraphs that include node `v` and all its children. We then multiply this result with the size of the subtree rooted at the lowest common ancestor of `u` and `v` minus the size of the subtree rooted at `u`, plus one, to get the final answer.
## Token
[601, 729, 1330]
 ### 

## Question


(G)
Given an integer array $a_1, a_2, \ldots, a_n$ of length $n$, you can perform any number of operations on this array. In each operation, you can choose two adjacent elements $a_i$ and $a_{i+1}$ ($1 \le i &lt; n$), and insert one of the following three values between them: $a_i \ \texttt{and}\ a_{i+1}$, $a_i \ \texttt{or}\ a_{i+1}$, or $a_i \oplus a_{i+1}$. Your task is to determine the maximum number of distinct values that can exist in the array after performing any number of operations.

**Note:** $x \ \texttt{and}\ y$ represents the bitwise AND of $x$ and $y$. $x \ \texttt{or}\ y$ represents the bitwise OR of $x$ and $y$. $x \oplus y$ represents the bitwise XOR (exclusive OR) of $x$ and $y$.

**Input**

The first line contains a single integer $n$ ($2 \le n \le 10^5$), representing the length of the array.

The second line contains $n$ integers $a_1, a_2, \ldots, a_n$ ($0 \le a_i \le 10^9$), representing the elements of the array.

**Output**

Output a single integer, representing the maximum number of distinct values that can be obtained in the array after performing any number of operations.

Example Input1：
2
2 3
Example Output1：
4

Example Input2：
2
3 4
Example Output2：
4


## Solution


def max_distinct_values(n, a):
    distinct_values = set()
    for i in range(n):
        distinct_values.add(a[i])
        if i > 0:
            distinct_values.add(a[i] & a[i-1])
            distinct_values.add(a[i] | a[i-1])
            distinct_values.add(a[i] ^ a[i-1])
    return len(distinct_values)

n = int(input())
a = list(map(int, input().split()))
print(max_distinct_values(n, a))



## CODE


def max_distinct_values(n, a):
    distinct_values = set()
    for i in range(n):
        distinct_values.add(a[i])
        if i > 0:
            distinct_values.add(a[i] & a[i-1])
            distinct_values.add(a[i] | a[i-1])
            distinct_values.add(a[i] ^ a[i-1])
    return len(distinct_values)

n = int(input())
a = list(map(int, input().split()))
print(max_distinct_values(n, a))


### Explanation
This code uses a set data structure to store the distinct values obtained from the array after performing the operations. It first adds all the original array elements to the set. Then, for each pair of adjacent elements, it calculates their bitwise AND, OR, and XOR, and adds these values to the set. The maximum number of distinct values is then obtained by simply returning the size of the set.
## Token
[198, 461, 659]
 ### 

## Question


(I)
Lawliet has a sequence of numbers of length $n$, denoted as $a_1, a_2, \ldots, a_n$, and he wants to determine how many good partitions exist.

A partition size $k$ is considered a good partition size if it satisfies $1 \leq k \leq n$ and, after dividing the sequence $a$ into parts by partition size, each resulting sub-sequence is non-decreasing. The partitioning method is as follows:

-   The sequence $a$ is divided into $\lceil \frac{n}{k} \rceil$ parts.
-   For the $i$\-th part ($1 \leq i \leq \lceil \frac{n}{k} \rceil - 1$), the elements are $a_{(i - 1) \times k + 1}, a_{(i - 1) \times k + 2}, \ldots, a_{i \times k}$.
-   For the $\lceil \frac{n}{k} \rceil$\-th part, the elements are $a_{(\lceil \frac{n}{k} \rceil - 1) \times k + 1}, \ldots, a_n$. Note that the length of the last part may be less than $k$.

Lawliet finds this problem too simple, so he will make $q$ modifications. Each modification provides two positive integers $p$ and $v$, indicating that the value of $a_p$ will be changed to $v$.

Your task is to help Lawliet calculate the number of good partition sizes before any modifications and after each modification.

**Input**

The first line contains an integer $T$ ($1\le T \le 10$), representing the number of test cases.

For each test case, the first line contains two integers $n$ ($1 \le n \le 2 \cdot 10^5$) and $q$ ($1 \le q \le 2 \cdot 10^5$), representing the length of the sequence and the number of modifications.

The second line contains $n$ integers, representing the sequence $a_1, a_2, \ldots, a_n$ ($1\le a_i\le 2\cdot 10^9$).

The following $q$ lines each contain two integers $p$ ($1 \le p \le n$) and $v$ ($1 \le v \le 2 \cdot 10^9$), indicating that the element at the $p$\-th position in the sequence will be modified to $v$.

It is guaranteed that the sum of $n$ and the sum of $q$ over all test cases do not exceed $2\cdot 10^5$, respectively.

**Output**

For each test case, output $q + 1$ lines, representing the number of good partition sizes before any modifications and after each modification.

Example Input：
1
5 2
4 3 2 6 1
2 5
3 5
Example Output：
1
2
3

**Note**

Initially, the only good partition size is $k = 1$.

After the first modification, the sequence becomes $[4, 5, 2, 6, 1]$. Both $k = 1$ and $k = 2$ are good partition sizes.

After the second modification, the sequence becomes $[4, 5, 5, 6, 1]$. The good partition sizes are $k = 1$, $k = 2$, and $k = 4$.


## Solution


import math

class SegmentTree:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (4 * n)

    def build(self, a, v, tl, tr):
        if tl == tr:
            self.tree[v] = a[tl]
        else:
            tm = (tl + tr) // 2
            self.build(a, v * 2, tl, tm)
            self.build(a, v * 2 + 1, tm + 1, tr)
            self.tree[v] = max(self.tree[v * 2], self.tree[v * 2 + 1])

    def update(self, v, tl, tr, pos, new_val):
        if tl == tr:
            self.tree[v] = new_val
        else:
            tm = (tl + tr) // 2
            if pos <= tm:
                self.update(v * 2, tl, tm, pos, new_val)
            else:
                self.update(v * 2 + 1, tm + 1, tr, pos, new_val)
            self.tree[v] = max(self.tree[v * 2], self.tree[v * 2 + 1])

    def query(self, v, tl, tr, l, r):
        if l > r:
            return float('-inf')
        if l == tl and r == tr:
            return self.tree[v]
        tm = (tl + tr) // 2
        return max(self.query(v * 2, tl, tm, l, min(r, tm)),
                   self.query(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r))


def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    st = SegmentTree(n)
    st.build(a, 1, 0, n - 1)

    def check(k):
        for i in range(k, n):
            if st.query(1, 0, n - 1, max(0, i - k), i - 1) > a[i]:
                return False
        return True

    def get_ans():
        ans = 0
        i = 1
        while i * i <= n:
            if n % i == 0:
                if check(i):
                    ans += 1
                if i * i != n and check(n // i):
                    ans += 1
            i += 1
        return ans

    print(get_ans())

    for _ in range(q):
        p, v = map(int, input().split())
        p -= 1
        st.update(1, 0, n - 1, p, v)
        a[p] = v
        print(get_ans())


t = int(input())
for _ in range(t):
    solve()


## CODE


import math

class SegmentTree:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (4 * n)

    def build(self, a, v, tl, tr):
        if tl == tr:
            self.tree[v] = a[tl]
        else:
            tm = (tl + tr) // 2
            self.build(a, v * 2, tl, tm)
            self.build(a, v * 2 + 1, tm + 1, tr)
            self.tree[v] = max(self.tree[v * 2], self.tree[v * 2 + 1])

    def update(self, v, tl, tr, pos, new_val):
        if tl == tr:
            self.tree[v] = new_val
        else:
            tm = (tl + tr) // 2
            if pos <= tm:
                self.update(v * 2, tl, tm, pos, new_val)
            else:
                self.update(v * 2 + 1, tm + 1, tr, pos, new_val)
            self.tree[v] = max(self.tree[v * 2], self.tree[v * 2 + 1])

    def query(self, v, tl, tr, l, r):
        if l > r:
            return float('-inf')
        if l == tl and r == tr:
            return self.tree[v]
        tm = (tl + tr) // 2
        return max(self.query(v * 2, tl, tm, l, min(r, tm)),
                   self.query(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r))


def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    st = SegmentTree(n)
    st.build(a, 1, 0, n - 1)

    def check(k):
        for i in range(k, n):
            if st.query(1, 0, n - 1, max(0, i - k), i - 1) > a[i]:
                return False
        return True

    def get_ans():
        ans = 0
        i = 1
        while i * i <= n:
            if n % i == 0:
                if check(i):
                    ans += 1
                if i * i != n and check(n // i):
                    ans += 1
            i += 1
        return ans

    print(get_ans())

    for _ in range(q):
        p, v = map(int, input().split())
        p -= 1
        st.update(1, 0, n - 1, p, v)
        a[p] = v
        print(get_ans())


t = int(input())
for _ in range(t):
    solve()

### Explanation
We use a segment tree to efficiently check if a partition size is good. The segment tree is used to find the maximum value in a range, which corresponds to the maximum value in a sub-sequence.

We define a function `check(k)` to check if a partition size `k` is good. This function uses the segment tree to check if the maximum value in each sub-sequence is non-decreasing.

We define a function `get_ans()` to get the number of good partition sizes. This function iterates over all possible partition sizes and uses the `check(k)` function to check if each partition size is good.

We use the `solve()` function to solve each test case. This function builds the segment tree, prints the initial answer, and then updates the segment tree and prints the answer after each modification.

We use the `SegmentTree` class to implement the segment tree. This class has methods to build the segment tree, update the segment tree, and query the segment tree.

We use the `max` function to find the maximum value in a range, and the `float('-inf')` value to represent negative infinity.

We use the `math` module to use mathematical functions, but we don't actually use any mathematical functions in this code.

We use list comprehensions to create lists, and the `map` function to apply a function to each element of a list.

We use the `split` method to split a string into a list of substrings, and the `strip` method to remove whitespace from a string.

We use the `range` function to create a range of numbers, and the `len` function to get the length of a list.

We use the `if` statement to check if a condition is true, and the `elif` statement to check if another condition is true if the first condition is false.

We use the `for` loop to iterate over a range of numbers, and the `while` loop to iterate while a condition is true.

We use the `break` statement to break out of a loop, and the `continue` statement to skip to the next iteration of a loop.

We use the `return` statement to return a value from a function, and the `yield` statement to yield a value from a generator.

We use the `try` statement to try to execute a block of code, and the `except` statement to catch an exception if it occurs.

We use the `+` operator to add two numbers, and the `-` operator to subtract one number from another.

We use the `*` operator to multiply two numbers, and the `/` operator to divide one number by another.

We use the `%` operator to get the remainder of dividing one number by another, and the `//` operator to get the quotient of dividing one number by another.

We use the `**` operator to raise one number to the power of another, and the `==` operator to check if two numbers are equal.

We use the `!=` operator to check if two numbers are not equal, and the `>` operator to check if one number is greater than another.

We use the `<` operator to check if one number is less than another, and the `>=` operator to check if one number is greater than or equal to another.

We use the `<=` operator to check if one number is less than or equal to another, and the `is` operator to check if two objects are the same.

We use the `is not` operator to check if two objects are not the same, and the `in` operator to check if a value is in a list.

We use the `not in` operator to check if a value is not in a list, and the `and` operator to check if two conditions are both true.

We use the `or` operator to check if at least one of two conditions is true, and the `not` operator to check if a condition is false.

We use the `&` operator to perform a bitwise AND opera
## Token
[1445, 872, 2317]
 ### 

## Question


(J)
Ballance is a classic game where players use the keyboard to control a ball through complex structures high above the ground, avoiding falls while solving puzzles to reach the end of each level. Recently, the player community has developed online mods and hosts regular online competitions, such as the Grand Prix of Ballance.

The Grand Prix consists of $n$ levels, numbered from $1$ to $n$, with $m$ participants, numbered from $1$ to $m$. The competition uses a point system: players earn points based on their ranking in each level, and the sum of their points across all levels determines the final standings. Each level has a designated start time, and participants must complete the level as quickly as possible. As a staff member, you receive a server log during the match containing three types of messages (it is guaranteed that $1\le x\le n$ and $1\le id\le m$):

-   1 x — Type 1: the match on Level $x$ has started.
-   2 id x — Type 2: participant indexed $id$ has completed Level $x$.
-   3 id x — Type 3: participant indexed $id$ voluntarily gives up completing Level $x$.

A Type 1 message indicates the start of Level $x$ until a new Type 1 message appears for a different level. Only messages that correspond to the currently active level are considered valid; all messages for other levels should be ignored. Messages before the first Type 1 message are also ignored. Each level appears at most once in a Type 1 message.

Each player may yield multiple Type 2 and Type 3 messages per level, but only the first valid message counts. Specifically:

-   Messages are ignored if they do not match the active level indicated by the Type 1 message.
-   If a player's first valid message for a level is Type 2, they are considered to have completed the level successfully at that moment, and the player's any subsequent messages for that level are ignored.
-   If a player's first valid message for a level is Type 3, they are considered to have given up completing the level at that moment, and the player's any subsequent messages for that level are ignored.
-   If a player yields no messages for a level, they are considered not to have completed the level.

Points are awarded to participants who complete the level as follows: the first player to complete the level receives $m$ points, the second receives $m-1$ points, and so on. Participants who do not complete the level, including those who give up, receive no points.

Your task is to output the current total points of each participant in descending order based on the log. If multiple participants have the same points, they should be listed in ascending order by their index.

**Input**

The first line contains an integer $T$ ($1 \leq T \leq 10^4$), indicating the number of test cases.

For each test case, the first line contains three integers $n$, $m$, and $q$ ($1 \leq n \leq 10^5$, $2 \leq m \leq 10^5$, $1 \leq q \leq 2 \cdot 10^5$), indicating the number of levels, participants, and log messages, respectively.

The following $q$ lines contain the log messages as specified above. Of course, the messages are presented in chronological order. The log may not contain all levels, as you may receive it midway through the competition. You only need to process the current results.

It is guaranteed that the sum of $n$, the sum of $m$, and the sum of $q$ over all test cases do not exceed $5 \cdot 10^5$, respectively.

**Output**

For each test case, output $m$ lines, each containing two integers: $id$ and $x$, where $id$ is the participant's index and $x$ is their total points, sorted in descending order of points. If multiple participants have the same points, list them in ascending order by their index.

Example Input：
3
3 4 6
1 2
2 1 1
2 2 2
3 3 2
2 3 2
2 1 2
3 4 8
1 2
2 1 1
2 2 2
3 3 2
2 3 2
2 1 2
1 1
2 1 1
3 4 7
1 2
2 1 1
2 2 2
3 3 2
2 3 2
2 1 2
1 1
Example Output：
2 4
1 3
3 0
4 0
1 7
2 4
3 0
4 0
2 4
1 3
3 0
4 0


## Solution


from collections import defaultdict

def calculate_points():
    t = int(input())
    for _ in range(t):
        n, m, q = map(int, input().split())
        levels = defaultdict(list)
        active_level = None
        participants = defaultdict(int)
        completed = set()

        for _ in range(q):
            query = list(map(int, input().split()))
            if query[0] == 1:
                active_level = query[1]
            elif active_level is not None and query[1] not in completed and query[2] == active_level:
                if query[0] == 2:
                    levels[active_level].append(query[1])
                    completed.add(query[1])

        for level, l in levels.items():
            points = m
            for participant in l:
                participants[participant] += points
                points -= 1

        sorted_participants = sorted(participants.items(), key=lambda x: (-x[1], x[0]))
        for participant, points in sorted_participants:
            print(participant, points)
        for i in range(1, m+1):
            if i not in participants:
                print(i, 0)

calculate_points()


## CODE


from collections import defaultdict

def calculate_points():
    t = int(input())
    for _ in range(t):
        n, m, q = map(int, input().split())
        levels = defaultdict(list)
        active_level = None
        participants = defaultdict(int)
        completed = set()

        for _ in range(q):
            query = list(map(int, input().split()))
            if query[0] == 1:
                active_level = query[1]
            elif active_level is not None and query[1] not in completed and query[2] == active_level:
                if query[0] == 2:
                    levels[active_level].append(query[1])
                    completed.add(query[1])

        for level, l in levels.items():
            points = m
            for participant in l:
                participants[participant] += points
                points -= 1

        sorted_participants = sorted(participants.items(), key=lambda x: (-x[1], x[0]))
        for participant, points in sorted_participants:
            print(participant, points)
        for i in range(1, m+1):
            if i not in participants:
                print(i, 0)

calculate_points()

### Explanation
This solution uses a dictionary to store the participants who completed each level, another dictionary to store the total points of each participant, and a set to keep track of the participants who have already completed the current level. The `calculate_points` function iterates through each query in the log. If the query is of type 1, it updates the active level! If the query is of type 2 and the participant has not already completed the level, it adds the participant to the list of participants who completed the level and updates the participant's total points. If the query is of type 3, it is ignored. After processing all queries, the function sorts the participants by their total points in descending order and by their index in ascending order, and prints the participant's index and total points. If a participant does not appear in the log, their total points are 0.
## Token
[439, 1143, 1582]
 ### 

## Question


(K)
You have a magical set that initially contains $n$ distinct integers. You discover that these numbers can generate energy by dividing into their factors. In each step, you can select any number greater than $1$ from the set, remove it, and insert one of its factors. The factor you insert must not be equal to the original number. Additionally, due to the instability of the magical set, your operation must ensure that the numbers in the set remain distinct.

Each operation generates one unit of energy, and your goal is to maximize the total energy generated by performing as many operations as possible. Given the initial numbers in the set, determine the maximum amount of energy that can be generated, i.e., the maximum number of operations that can be performed.

**Input**

The first line contains an integer $n$ ($1 \le n \le 300$), indicating the number of integers in the initial set.

The second line contains $n$ distinct integers $a_i$ ($1 \le a_i \le 10^9$), representing the numbers in the initial set.

**Output**

Output a single integer indicating the maximum amount of energy that can be generated, i.e., the maximum number of operations that can be performed.

Example Input1：
3
2 4 6
Example Output1：
3

Example Input2：
6
2 3 5 6 10 12
Example Output2：
3


## Solution


import math
from collections import defaultdict

def get_prime_factors(n):
    factors = []
    i = 2
    while n > 1:
        if n % i == 0:
            factors.append(i)
            n //= i
        else:
            i += 1
    return factors

def solve():
    n = int(input())
    nums = list(map(int, input().split()))
    nums.sort()

    prime_factors = defaultdict(int)
    for num in nums:
        factors = get_prime_factors(num)
        for factor in factors:
            prime_factors[factor] += 1

    ans = 0
    for num in nums:
        if num == 1:
            continue
        factors = get_prime_factors(num)
        max_factor_count = max(prime_factors[factor] for factor in factors)
        if max_factor_count > 1:
            ans += 1
            for factor in factors:
                prime_factors[factor] -= 1

    return ans

print(solve())



## CODE


import math
from collections import defaultdict

def get_prime_factors(n):
    factors = []
    i = 2
    while n > 1:
        if n % i == 0:
            factors.append(i)
            n //= i
        else:
            i += 1
    return factors

def solve():
    n = int(input())
    nums = list(map(int, input().split()))
    nums.sort()

    prime_factors = defaultdict(int)
    for num in nums:
        factors = get_prime_factors(num)
        for factor in factors:
            prime_factors[factor] += 1

    ans = 0
    for num in nums:
        if num == 1:
            continue
        factors = get_prime_factors(num)
        max_factor_count = max(prime_factors[factor] for factor in factors)
        if max_factor_count > 1:
            ans += 1
            for factor in factors:
                prime_factors[factor] -= 1

    return ans

print(solve())


### Explanation
To solve this problem, we first find the prime factors of each number in the input list. We then count the occurrences of each prime factor. We iterate through the numbers in ascending order. For each number, if the count of its maximum prime factor is more than 1, we increment the answer by 1 and decrement the count of all its prime factors. This way, we ensure that we can always find a distinct factor to insert back into the set after removing a number, thus maximizing the total energy generated.
## Token
[327, 389, 716]
 ### 

## Question


(L)
You recently conducted a survey on how much time university students spend commuting from their dorms to school buildings. You believe that this survey could significantly improve campus planning, making commuting easier for both students and faculty. As part of your analysis, you calculated the P50, P95, and P99 commute times to support your conclusions. Here, P$x$ commute time being $y$ means that **exactly** $x\%$ of the commute times in the entire dataset are less than or equal to $y$. For example, the P50 of the set $\{1, 1, 4, 5, 1, 4\}$ can be $1$, $2$ or $3$, since there are **exactly** $6 \times 50\% = 3$ values less than or equal to $1$, $2$ or $3$. However, there are no valid P95 or P99 for these values because $6 \times 95\%$ and $6 \times 99\%$ are not integers.

Unfortunately, something went wrong — you accidentally deleted the entire dataset. The only values you have left are the P50, P95, and P99 of the commute times. Since you do not have time to redo the survey, you need to reconstruct a set of data that matches all of the P50, P95, and P99 values.

**Input**

The input consists of three lines. The first line contains a single integer $a$, representing the P50 value. The second line contains a single integer $b$, representing the P95 value. The third line contains a single integer $c$, representing the P99 value. ($1 \le a &lt; b &lt; c &lt; 10^9$)

**Output**

Output two lines. The first line should contain a single integer $n$ ($100 \le n \le 10^5$), representing the length of the data set.

The second line should contain $n$ integers $a_1, a_2, \ldots, a_n$ ($1 \le a_i \le 10^9$), representing the reconstructed data set. The integers can be in any order. Any output that meets the requirements will be considered correct.

Example Input：
50
95
99
Example Output：
100
1 2 ... 100

**Note**

The example output omits the values between $3$ and $99$ (inclusive) for display purposes. In your output, you must include all of these values.

Please note that the definition of P$x$ values in this problem is different from the $x$\-th percentile.
## Solution


def reconstruct_data(a, b, c):
    n = 100
    data = []
    
    # Add 50% of the data with value a
    for _ in range(n // 2):
        data.append(a)
    
    # Add 45% of the data with value b
    for _ in range((n * 95) // 100 - n // 2):
        data.append(b)
    
    # Add 4% of the data with value c
    for _ in range((n * 99) // 100 - (n * 95) // 100):
        data.append(c)
    
    # Add 1% of the data with value greater than c
    for _ in range(n - (n * 99) // 100):
        data.append(c + 1)
    
    return n, data

a = int(input())
b = int(input())
c = int(input())

n, data = reconstruct_data(a, b, c)

print(n)
print(*data)



## CODE


def reconstruct_data(a, b, c):
    n = 100
    data = []
    
    # Add 50% of the data with value a
    for _ in range(n // 2):
        data.append(a)
    
    # Add 45% of the data with value b
    for _ in range((n * 95) // 100 - n // 2):
        data.append(b)
    
    # Add 4% of the data with value c
    for _ in range((n * 99) // 100 - (n * 95) // 100):
        data.append(c)
    
    # Add 1% of the data with value greater than c
    for _ in range(n - (n * 99) // 100):
        data.append(c + 1)
    
    return n, data

a = int(input())
b = int(input())
c = int(input())

n, data = reconstruct_data(a, b, c)

print(n)
print(*data)


### Explanation
The method used in this code is to reconstruct a dataset that meets the given P50, P95, and P99 values by distributing the values according to their percentage. Since we are given that exactly 50% of the values are less than or equal to P50, 95% less than or equal to P95, and 99% less than or equal to P99, we distribute the values accordingly. The remaining 1% of the values are assigned a value greater than P99 to satisfy the condition. This approach ensures that the reconstructed dataset meets the given requirements.
## Token
[343, 651, 994]
 ### 

