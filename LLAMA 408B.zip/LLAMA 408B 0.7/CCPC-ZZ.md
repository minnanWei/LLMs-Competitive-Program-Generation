## Question
(A)
Given three positive integers $p_A,p_B,p_C$, Bobo challenges you to find out three infinite binary strings $A,B,C$ with period $p_A$, $p_B$ and $p_C$ respectively satisfying $A \oplus B = C$, or determine it is impossible to do so.
Please refer to the Note section for the formal definition of period and exclusive or.
**Input**
The first line of the input contains a single integer $T$ ($1 \le T \le 10^4$), denoting the number of test cases. The description of the test cases follows.
The first and the only line of each test case contains three integers $p_A$, $p_B$ and $p_C$ ($1 \le p_A,p_B,p_C \le 10^6$).
It is guaranteed that the sum of $\max(p_A,p_B,p_C)$ over all test cases does not exceed $10^6$.
**Output**
For each test case, output "NO" (without quotes) in one line if no solution exists. Otherwise, output "YES" (without quotes) in one line. Then, output three binary strings of length $p_A$, $p_B$ and $p_C$ in three lines, denoting the first $p_A$, $p_B$, $p_C$ character(s) of the infinite strings $A$, $B$, $C$ respectively.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input：
2 3 6
2 3 5
Example Output：
YES
01
011
001110
NO
**Note**
Let $s=s_1 s_2 s_3 \ldots$ and $t=t_1 t_2 t_3 \ldots$ be infinite binary strings.
The period of $s$ is the smallest positive integer $k$ satisfying $s_i = s_{i+k}$ for all $i \ge 1$.
The exclusive or of strings $s$ and $t$ is given by $s \oplus t$ satisfying $(s \oplus t)_i = s_i \oplus t_i$ for all $i \ge 1$.


## Solution


def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def lcm(a, b):
    return a * b // gcd(a, b)

def solve(pa, pb, pc):
    if pc == lcm(pa, pb):
        print("YES")
        a = [1 if i % 2 == 0 else 0 for i in range(pa)]
        b = [1 if i % 2 == 0 else 0 for i in range(pb)]
        c = [(a[i % pa] ^ b[i % pb]) for i in range(pc)]
        print(''.join(map(str, a)))
        print(''.join(map(str, b)))
        print(''.join(map(str, c)))
    elif lcm(pa, pc) == lcm(pb, pc):
        print("YES")
        a = [1 if i % 2 == 0 else 0 for i in range(pa)]
        c = [1 if i % 2 == 0 else 0 for i in range(pc)]
        b = [(a[i % pa] ^ c[i % pc]) for i in range(pb)]
        print(''.join(map(str, a)))
        print(''.join(map(str, b)))
        print(''.join(map(str, c)))
    else:
        print("NO")

T = int(input())
for _ in range(T):
    pa, pb, pc = map(int, input().split())
    solve(pa, pb, pc)



## CODE


def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

def lcm(a, b):
    return a * b // gcd(a, b)

def solve(pa, pb, pc):
    if pc == lcm(pa, pb):
        print("YES")
        a = [1 if i % 2 == 0 else 0 for i in range(pa)]
        b = [1 if i % 2 == 0 else 0 for i in range(pb)]
        c = [(a[i % pa] ^ b[i % pb]) for i in range(pc)]
        print(''.join(map(str, a)))
        print(''.join(map(str, b)))
        print(''.join(map(str, c)))
    elif lcm(pa, pc) == lcm(pb, pc):
        print("YES")
        a = [1 if i % 2 == 0 else 0 for i in range(pa)]
        c = [1 if i % 2 == 0 else 0 for i in range(pc)]
        b = [(a[i % pa] ^ c[i % pc]) for i in range(pb)]
        print(''.join(map(str, a)))
        print(''.join(map(str, b)))
        print(''.join(map(str, c)))
    else:
        print("NO")

T = int(input())
for _ in range(T):
    pa, pb, pc = map(int, input().split())
    solve(pa, pb, pc)


### Explanation
We first check if pc is equal to the least common multiple (LCM) of pa and pb. If so, we can construct the binary strings A, B, and C by assigning values to A and B, and then calculating C as the XOR of A and B. We then print out the values of A, B, and C.

If pc is not equal to the LCM of pa and pb, we check if the LCM of pa and pc is equal to the LCM of pb and pc. If so, we can construct the binary strings A, B, and C by assigning values to A and C, and then calculating B as the XOR of A and C. We then print out the values of A, B, and C.

If neither condition is met, we print out "NO", indicating that it is impossible to find binary strings A, B, and C that satisfy the given conditions.
## Token
[514, 578, 1092]
 ### 

## Question


(B)
Bobo has been playing a puzzle called Rolling Stones, which takes place on an equilateral triangular board consisting of $n$ $(n\geq 2)$ rows and $n^2$ cells. Each cell on the board is labeled with a number from $1$ to $4$. Bobo also has a tetrahedral stone, with each face numbered from $1$ to $4$ (a tetrahedral dice), initially placed at the first cell in the first row of the board. The position of the stone is as follows: the face with the number $1$ is towards the left, the face with the number $2$ is towards the next row, the face with the number $3$ is towards the right, and the face with the number $4$ is on the bottom side.
The goal of the puzzle is to roll the stone to a target cell under the following rules:

- **Matching Numbers**: When the stone rests on a cell, the number on the cell must match the number on the stone's bottom face.
- **Single Visit**: Each cell can only be visited once throughout the journey, including the starting and target cells.
The stone rolls by tipping along an edge that touches the board, moving it to a neighboring cell. Given the board layout, the target cell, and the stone's initial orientation, Bobo wants to know: is it possible to reach the target cell following the rules? If possible, what is the minimum number of rolls required to reach the target?
The illustration for a solution of the first sample test is given as follows.
![]
**Input**
The first line contains an integer $n$ $(2\leq n\leq 100)$, denoting the size of the board.
Then $n$ lines follows, with the $i$\-th $(1\leq i\leq n)$ line containing $2i-1$ numbers $a_{i,1},a_{i,2},\dots,a_{i,2i-1}$, where each $1\leq a_{i,j}\leq 4$ indicates the number on the $j$\-th cell from left to right in the $i$\-th row. It is guaranteed that $a_{1,1}=4$.
Then another line follows, containing two integers $x,y$ $(2\leq x\leq n,1\leq y\leq 2x-1)$. Here, $(x,y)$ represents the target cell, located at the $y$\-th cell from left to right in the $x$\-th row.
**Output**
If there is no way to roll the stone to the target cell, output $-1$ in a line. Otherwise, output the minimum number of rolls to roll the stone to the target cell in a line.
Example Input：
3
4
3 2 3
4 3 2 1 3
3 1
Example Output：
6


## Solution


from collections import deque

def bfs(board, target):
    n = len(board)
    directions = [(0, 1), (1, 0), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
    queue = deque([(0, 0, 3, 0)])  # row, col, prev direction, steps
    visited = {(0, 0, 3)}
    
    while queue:
        row, col, prev_direction, steps = queue.popleft()
        
        if (row, col) == target:
            return steps
        
        for direction in range(6):
            if direction == (prev_direction + 3) % 6:
                continue
            dr, dc = directions[direction]
            nr, nc = row + dr, col + dc
            
            if 0 <= nr < n and 0 <= nc < len(board[nr]):
                if (direction % 3) == 0:  # check right
                    if board[nr][nc] == 1:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))
                elif (direction % 3) == 1:  # check down
                    if board[nr][nc] == 2:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))
                else:  # check left
                    if board[nr][nc] == 3:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))

    return -1

def solve():
    n = int(input())
    board = []
    for _ in range(n):
        board.append(list(map(lambda x: int(x) - 1, input().split())))
    target = tuple(map(lambda x: int(x) - 1, input().split()))
    print(bfs(board, target))

solve()



## CODE


from collections import deque

def bfs(board, target):
    n = len(board)
    directions = [(0, 1), (1, 0), (0, -1), (-1, -1), (-1, 0), (-1, 1)]
    queue = deque([(0, 0, 3, 0)])  # row, col, prev direction, steps
    visited = {(0, 0, 3)}
    
    while queue:
        row, col, prev_direction, steps = queue.popleft()
        
        if (row, col) == target:
            return steps
        
        for direction in range(6):
            if direction == (prev_direction + 3) % 6:
                continue
            dr, dc = directions[direction]
            nr, nc = row + dr, col + dc
            
            if 0 <= nr < n and 0 <= nc < len(board[nr]):
                if (direction % 3) == 0:  # check right
                    if board[nr][nc] == 1:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))
                elif (direction % 3) == 1:  # check down
                    if board[nr][nc] == 2:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))
                else:  # check left
                    if board[nr][nc] == 3:
                        state = (nr, nc, direction)
                        if state not in visited:
                            visited.add(state)
                            queue.append((nr, nc, direction, steps + 1))

    return -1

def solve():
    n = int(input())
    board = []
    for _ in range(n):
        board.append(list(map(lambda x: int(x) - 1, input().split())))
    target = tuple(map(lambda x: int(x) - 1, input().split()))
    print(bfs(board, target))

solve()


### Explanation
We use BFS (Breadth-First Search) to solve this problem. BFS is suitable here because we are looking for the shortest path to the target cell.

We maintain a queue of states, where each state is represented by the current row, column, previous direction, and the number of steps taken so far. We also keep track of the visited states to avoid revisiting them.

For each state, we explore all possible next directions and check if the next cell matches the required number. If it does, we add the new state to the queue and mark it as visited.

The BFS continues until we reach the target cell or the queue becomes empty. If we reach the target cell, we return the number of steps taken. If the queue becomes empty without reaching the target cell, we return -1, indicating that it is impossible to reach the target cell.
## Token
[645, 714, 1359]
 ### 

## Question


(C)
Bobo is exploring a set of lattice points on a two-dimensional plane. Initially, the set of points is defined as $S = \{(0,0),(A,0),(0,B),(A,B)\}$. Bobo's goal is to include a specific lattice point $(X,Y)$ in $S$. To achieve the goal, Bobo may perform the following operation:
- Select two lattice points $P,Q \in S$ such that $\frac{P+Q}{2}$ is also a lattice point, and add $\frac{P+Q}{2}$ to $S$.
Your task is to help Bobo find a sequence of operations that minimizes the number of steps to achieve the goal or determine if it is impossible to do so.
**Input**
The first line of the input contains two integers $A$ and $B$ ($0 \le A,B \le 10^9$), describing the parameters of the initial lattice points.
The second line of the input contains two integers $X$ and $Y$ ($0 \le X \le A$, $0 \le Y \le B$), denoting the coordinates of the target lattice point.
**Output**
If it is impossible to achieve the goal, output $-1$ in one line. Otherwise, output a single integer $k$ ($0 \le k \le 10^5$) in one line, denoting the total number of operations to perform. Then $k$ lines follow. The $i$\-th line contains four integers $U_i,V_i,S_i,T_i$ ($0 \le U_i,V_i,S_i,T_i \le 10^9$), describing the lattice points $P=(U_i,V_i)$ and $Q=(S_i,T_i)$ chosen in the $i$\-th operation. If there exist multiple solutions, output any.
Example Input1：
2 2
1 1
Example Output1：
1
0 0 2 2
Example Input2：
8 8
5 0
Example Output2：
3
0 0 8 0
4 0 8 0
4 0 6 0
Example Input3：
8 6
7 3
Example Output3：
3
0 0 8 0
4 0 8 0
6 0 8 6


## Solution


def solve(a, b, x, y):
    def output(steps):
        print(len(steps))
        for step in steps:
            print(*step)
        return

    steps = []
    def add_step(p1, p2):
        steps.append(p1 + p2)

    def work(a, b, x, y):
        if (x, y) == (0, 0):
            return []
        if x == 0:
            add_step((0, 0), (0, b))
            return work(a, b // 2, x, y % (b // 2))
        if y == 0:
            add_step((0, 0), (a, 0))
            return work(a // 2, b, x % (a // 2), y)
        if x == a:
            add_step((a, 0), (a, b))
            return work(a, b // 2, x, y % (b // 2))
        if y == b:
            add_step((0, b), (a, b))
            return work(a // 2, b, x % (a // 2), y)
        dx, dy = a - x, b - y
        if dx > dy:
            add_step((0, 0), (a, 0))
            add_step((a // 2, 0), (a, 0))
            return work(a // 2, b, x % (a // 2), y)
        else:
            add_step((0, 0), (0, b))
            add_step((0, b // 2), (0, b))
            return work(a, b // 2, x, y % (b // 2))

    work(a, b, x, y)
    if (x, y) not in [(0, 0), (a, 0), (0, b), (a, b)]:
        if a % 2 == 1 or b % 2 == 1:
            print(-1)
            return
        if x % 2 == 1 or y % 2 == 1:
            print(-1)
            return
        output(steps)
    else:
        print(0)

a, b = map(int, input().split())
x, y = map(int, input().split())
solve(a, b, x, y)



## CODE


def solve(a, b, x, y):
    def output(steps):
        print(len(steps))
        for step in steps:
            print(*step)
        return

    steps = []
    def add_step(p1, p2):
        steps.append(p1 + p2)

    def work(a, b, x, y):
        if (x, y) == (0, 0):
            return []
        if x == 0:
            add_step((0, 0), (0, b))
            return work(a, b // 2, x, y % (b // 2))
        if y == 0:
            add_step((0, 0), (a, 0))
            return work(a // 2, b, x % (a // 2), y)
        if x == a:
            add_step((a, 0), (a, b))
            return work(a, b // 2, x, y % (b // 2))
        if y == b:
            add_step((0, b), (a, b))
            return work(a // 2, b, x % (a // 2), y)
        dx, dy = a - x, b - y
        if dx > dy:
            add_step((0, 0), (a, 0))
            add_step((a // 2, 0), (a, 0))
            return work(a // 2, b, x % (a // 2), y)
        else:
            add_step((0, 0), (0, b))
            add_step((0, b // 2), (0, b))
            return work(a, b // 2, x, y % (b // 2))

    work(a, b, x, y)
    if (x, y) not in [(0, 0), (a, 0), (0, b), (a, b)]:
        if a % 2 == 1 or b % 2 == 1:
            print(-1)
            return
        if x % 2 == 1 or y % 2 == 1:
            print(-1)
            return
        output(steps)
    else:
        print(0)

a, b = map(int, input().split())
x, y = map(int, input().split())
solve(a, b, x, y)


### Explanation
The method used here is to recursively divide the grid into smaller parts until the target point (x, y) is on the edge of the grid. In each step, we add the midpoint of the two lattice points on the edge to the set of lattice points, effectively reducing the size of the grid by half. If the target point (x, y) is not on the edge of the grid after the recursive division, it means that the target point cannot be reached. If the target point is on the edge of the grid, we can then construct the sequence of operations to reach the target point by backtracking the recursive division steps.
## Token
[650, 593, 1243]
 ### 

## Question


(F)
Bobo is trapped in an infinite time loop of a peculiar day! Each day consists of exactly $k$ hours, and every day, $n$ tasks arrive for Bobo to complete.
- The $i$\-th task of the day arrives at the beginning of the $a_i$\-th hour and requires $b_i$ hours of uninterrupted effort to finish.
- Bobo works diligently and always follows a disciplined approach: whenever there are unfinished tasks, 、textbf{Bobo works on the earliest received unfinished task}.
At the beginning of the first day, Bobo starts with no tasks.
Your mission is to help Bobo answer $q$ queries. For the $i$\-th query, you are given $x_i$, the day on which a task is received, and $y_i$, the index of the task received on that day. Your goal is to determine the exact day and hour when Bobo will complete the $y_i$\-th taskof day $x_i$.
**Input**
The first line contains three space-separated integers, which are $n$ ($1 \leq n \leq 10^5$), $k$ ($1 \leq k \leq 10^8$), and $q$ ($1 \leq q \leq 10^5$), respectively.
The next $n$ lines each contain two space-separated integers, where the $i$\-th line contains $a_i$ ($1 \leq a_i \leq k$) and $b_i$ ($1 \leq b_i \leq k$). It is guaranteed that $a_i$ is strictly monotonically increasing.
Then $q$ lines follow, each containing two space-separated integers, where the $i$\-th line contains $x_i$ ($1 \leq x_i \leq 5 \times 10^5$) and $y_i$ ($1 \leq y_i \leq n$).
**Output**
Output $q$ lines, where the $i$\-th line outputs two space-separated integers $d_i$ and $h_i$, indicating that the task for the $i$\-th query is completed at the $h_i$\-th hour on the $d_i$\-th day.
Example Input1:
2 5 6
1 1
4 3
1 1
1 2
2 1
2 2
3 1
3 2
Example Output1:
1 1
2 1
2 2
3 1
3 2
4 1
Example Input2:
3 10 5
2 4
3 1
10 7
2 2
7 1
4 3
5 2
28 3
Example Output2:
3 1
8 10
6 2
6 7
34 10


## Solution


import bisect
import sys

def read_ints():
    return map(int, sys.stdin.readline().split())

n, k, q = read_ints()

# Read tasks
tasks = []
for _ in range(n):
    a, b = read_ints()
    tasks.append((a, b))

# Precompute task completion times
task_completion_times = []
total_time = 0
for a, b in tasks:
    if total_time < a:
        total_time = a
    total_time += b
    task_completion_times.append(total_time)

# Precompute day completion times
day_completion_times = [0]
for i in range(n):
    day_completion_times.append(task_completion_times[i] + day_completion_times[-1])

# Read queries
for _ in range(q):
    x, y = read_ints()
    y -= 1  # 0-indexed

    # Calculate the day when the task is completed
    if x == 1:
        day = 1
        time = task_completion_times[y]
    else:
        prev_day_completion_time = day_completion_times[-1] * (x - 2)
        task_completion_time = task_completion_times[y]
        day_completion_time = day_completion_times[y + 1]
        if prev_day_completion_time + task_completion_time <= k * (x - 1):
            day = x
            time = task_completion_time
        else:
            day = x + (prev_day_completion_time + task_completion_time - k * (x - 1) + k - 1) // k
            time = (prev_day_completion_time + task_completion_time - k * (x - 1)) % k

    # Handle the case where the task is completed on a subsequent day
    if time > k:
        day += time // k
        time %= k

    # Handle the case where the task is completed at the beginning of a day
    if time == 0:
        day -= 1
        time = k

    print(day, time)


## CODE


import bisect
import sys

def read_ints():
    return map(int, sys.stdin.readline().split())

n, k, q = read_ints()

# Read tasks
tasks = []
for _ in range(n):
    a, b = read_ints()
    tasks.append((a, b))

# Precompute task completion times
task_completion_times = []
total_time = 0
for a, b in tasks:
    if total_time < a:
        total_time = a
    total_time += b
    task_completion_times.append(total_time)

# Precompute day completion times
day_completion_times = [0]
for i in range(n):
    day_completion_times.append(task_completion_times[i] + day_completion_times[-1])

# Read queries
for _ in range(q):
    x, y = read_ints()
    y -= 1  # 0-indexed

    # Calculate the day when the task is completed
    if x == 1:
        day = 1
        time = task_completion_times[y]
    else:
        prev_day_completion_time = day_completion_times[-1] * (x - 2)
        task_completion_time = task_completion_times[y]
        day_completion_time = day_completion_times[y + 1]
        if prev_day_completion_time + task_completion_time <= k * (x - 1):
            day = x
            time = task_completion_time
        else:
            day = x + (prev_day_completion_time + task_completion_time - k * (x - 1) + k - 1) // k
            time = (prev_day_completion_time + task_completion_time - k * (x - 1)) % k

    # Handle the case where the task is completed on a subsequent day
    if time > k:
        day += time // k
        time %= k

    # Handle the case where the task is completed at the beginning of a day
    if time == 0:
        day -= 1
        time = k

    print(day, time)

### Explanation
This solution works by first precomputing the completion times of each task and each day. Then, for each query, it calculates the day and time when the task is completed by considering two cases: when the task is completed on the same day and when the task is completed on a subsequent day. The solution handles edge cases where the task is completed at the beginning of a day or where the task completion time exceeds the number of hours in a day. The precomputation step allows for efficient query processing, and the use of binary search (not shown in this code) could further improve the efficiency of the solution for large inputs.
## Token
[564, 706, 1270]
 ### 

## Question


(G)
Bobo is working with an integer sequence $a_1,a_2,\ldots,a_n$ of length $n$. He must process $q$ queries in order. Each query is of one of the following two types:
- 1 $L$ $R$ $v$ ($1 \le L \le R \le n$, $0 \le v \le 2 \cdot 10^5$): for all $i \in [L,R]$, update $a_i \gets a_i + v$;
- 2 $L$ $R$ ($1 \le L &lt; R \le n$, $R-L+1$ is even): determine if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum.
Your task is to help Bobo process these queries efficiently.
**Input**
The first line of input contains two integers $n$, $q$ ($1 \le n,q \le 2 \cdot 10^5$).
The second line of input contains $n$ integers $a_1, a_2, \ldots, a_n$ ($0 \le a_i \le 2 \cdot 10^5$).
Then $q$ lines follow. Each of the following lines contains a query, described in the statement.
**Output**
For each query of the second type, output "YES" (without quotes) in one line if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum; otherwise, output "NO" (without quotes) in one line.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input:
8 4
1 2 3 4 5 6 7 8
2 1 8
1 1 4 4
2 1 6
2 1 8
Example Output:
YES
NO
YES 


## Solution


import sys
input = sys.stdin.readline

class FenwickTree:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * n

    def sum(self, r):
        res = 0
        while r >= 0:
            res += self.bit[r]
            r = (r & (r + 1)) - 1
        return res

    def rsum(self, l, r):
        return self.sum(r) - self.sum(l - 1)

    def add(self, idx, delta):
        while idx < self.n:
            self.bit[idx] += delta
            idx = idx | (idx + 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))
    fenwick = FenwickTree(n)
    fenwick2 = FenwickTree(n)

    for i in range(n):
        fenwick.add(i, a[i])

    for _ in range(q):
        query = list(map(int, input().split()))

        if query[0] == 1:
            l, r, v = query[1:]
            l -= 1
            r -= 1
            fenwick.add(l, v)
            fenwick.add(r + 1, -v)
            if l % 2 == 0:
                fenwick2.add(l, v)
                fenwick2.add(r + 1, -v)
            else:
                fenwick2.add(l, -v)
                fenwick2.add(r + 1, v)
        else:
            l, r = query[1:]
            l -= 1
            r -= 1
            if fenwick2.rsum(l, r) == 0:
                print("YES")
            else:
                print("NO")

solve()



## CODE


import sys
input = sys.stdin.readline

class FenwickTree:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * n

    def sum(self, r):
        res = 0
        while r >= 0:
            res += self.bit[r]
            r = (r & (r + 1)) - 1
        return res

    def rsum(self, l, r):
        return self.sum(r) - self.sum(l - 1)

    def add(self, idx, delta):
        while idx < self.n:
            self.bit[idx] += delta
            idx = idx | (idx + 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))
    fenwick = FenwickTree(n)
    fenwick2 = FenwickTree(n)

    for i in range(n):
        fenwick.add(i, a[i])

    for _ in range(q):
        query = list(map(int, input().split()))

        if query[0] == 1:
            l, r, v = query[1:]
            l -= 1
            r -= 1
            fenwick.add(l, v)
            fenwick.add(r + 1, -v)
            if l % 2 == 0:
                fenwick2.add(l, v)
                fenwick2.add(r + 1, -v)
            else:
                fenwick2.add(l, -v)
                fenwick2.add(r + 1, v)
        else:
            l, r = query[1:]
            l -= 1
            r -= 1
            if fenwick2.rsum(l, r) == 0:
                print("YES")
            else:
                print("NO")

solve()


### Explanation
We use two Fenwick trees to keep track of the prefix sums of the sequence and the prefix sums of the sequence with alternating signs. The first Fenwick tree allows us to update the sequence and calculate prefix sums in O(log n) time. The second Fenwick tree allows us to check if the elements in a range can be divided into pairs with the same sum in O(log n) time.

When we update a range [L, R] by adding a value v, we update the first Fenwick tree by adding v to the L-th element and subtracting v from the (R+1)-th element. We update the second Fenwick tree by adding v to the L-th element and subtracting v from the (R+1)-th element if L is even, and by subtracting v from the L-th element and adding v to the (R+1)-th element if L is odd.

When we query a range [L, R], we check if the sum of the elements in the range with alternating signs is zero by querying the second Fenwick tree. If the sum is zero, we print "YES", otherwise we print "NO".
## Token
[637, 556, 1193]
 ### 

## Question


(K)
Bobo is playing a game called **Brotato**. The game consists of $n$ levels, each of which he can either pass or fail. Each level has a probability $p$ of failure and a probability $1-p$ of passing. If Bobo fails a level, he must normally restart from the first level.

Bobo is quite frustrated about the fact that each time he dies, he has to start over from the very beginning. Therefore, Bobo decided to cheat. Now, Bobo has $k$ special items that allow him to continue from the same level after a failure rather than restarting from the beginning.

Given this setup, determine the minimum expected number of attempts for levels needed for Bobo to complete all $n$ levels.
**Input**

The first line contains two integers $n,k$ ($1 \le n\leq 10^5, 0 \le k\leq 10^9)$, denoting the number of levels and the number of items, respectively.

The second line contains a number $p$ $(0&lt;p\leq 0.5)$. It is guaranteed that $p$ has at most $4$ decimal places.

**It is guaranteed that $np\leq 20$.**
**Output**

Output a number in a line denoting the answer.

Your answer is considered correct if its absolute or relative error doesn't exceed $10^{-9}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $\frac{|b-a|}{\max(b,1)} \le 10^{-9}$.
Example Input1:
5 0
0.5
Example Output1:
62.0000000000
Example Input2:
5 1
0.5
Example Output2:
47.0000000000
Example Input3：
10000 0
0.002
Example Output3：
247489700298.2536834329
Example Input4：
100000 10
0.0002
Example Output4：
38767507133.2322179824


## Solution


import sys

def calculate_expected_attempts(n, k, p):
    dp = [[0.0 for _ in range(k + 1)] for _ in range(n + 1)]
    dp[0] = [0.0] * (k + 1)
    for i in range(1, n + 1):
        dp[i][0] = dp[i - 1][0] + 1 / (1 - p)
    for i in range(1, n + 1):
        for j in range(1, k + 1):
            dp[i][j] = dp[i - 1][j] + (1 - p) + p * dp[i][j - 1]
    return dp[n][k]

n, k = map(int, input().split())
p = float(input())
result = calculate_expected_attempts(n, k, p)
print(result)



## CODE


import sys

def calculate_expected_attempts(n, k, p):
    dp = [[0.0 for _ in range(k + 1)] for _ in range(n + 1)]
    dp[0] = [0.0] * (k + 1)
    for i in range(1, n + 1):
        dp[i][0] = dp[i - 1][0] + 1 / (1 - p)
    for i in range(1, n + 1):
        for j in range(1, k + 1):
            dp[i][j] = dp[i - 1][j] + (1 - p) + p * dp[i][j - 1]
    return dp[n][k]

n, k = map(int, input().split())
p = float(input())
result = calculate_expected_attempts(n, k, p)
print(result)


### Explanation
We use dynamic programming to solve this problem. The dp[i][j] represents the minimum expected number of attempts for levels needed for Bobo to complete i levels with j items. We initialize the base case dp[0][j] as 0. Then we calculate dp[i][j] based on the previous state dp[i - 1][j] and dp[i][j - 1]. If Bobo has no item, he has to restart from the beginning after a failure, so dp[i][0] = dp[i - 1][0] + 1 / (1 - p). If Bobo has items, he can continue from the same level after a failure, so dp[i][j] = dp[i - 1][j] + (1 - p) + p * dp[i][j - 1]. Finally, we return dp[n][k] as the minimum expected number of attempts for levels needed for Bobo to complete all n levels.
## Token
[401, 538, 939]
 ### 

## Question


(L)
Welcome to the China Collegiate Programming Contest (CCPC) Zhengzhou onsite! Bobo has noticed that the initials of "Zheng" and "Zhou" are both Z. This motivates him to study the well-known Z-order curve.

To introduce the Z-order curve, we first introduce the Moser–de Bruijn sequence $(B_t)_{t \ge 0}$, the ordered sequence of numbers whose binary representation has nonzero digits only in the even positions. The first few terms of the Moser-de Bruijn sequence are $0, 1, 4, 5, 16, 17, 20, 21$.

Each non-negative integer $z$ can be uniquely decomposed into the sum of $B_x$ and $2B_y$. Therefore, we can write down all natural numbers in an infinitely large table. The Z-order curve is then obtained by connecting all the numbers in numerical order.

| ![](https://espresso.codeforces.com/3763e73d21e60b6c9037b14d5210dc6564fed8b9.png) |
| --- |
Illustration of Z-curve

Bobo now challenges you with the following problem: For a given fragment extracted from the Z-curve from $L$ to $R$, find the smallest integer $l$ such that the Z-curve from $l$ to $l+R-L$ is identical to the given fragment (i.e., the curve from $l$ to $l+R-L$ can be obtained by translating the curve from $L$ to $R$).

**Please note that in this problem, the curve is directed. Specifically, the curve from $1$ to $2$ is NOT identical to the curve from $3$ to $4$.**
**Input**

The first line of the input contains a single integer $T$ ($1 \le T \le 100$), denoting the number of test cases.

The first and only line of each test case contains two integers $L$ and $R$ ($0 \le L &lt; R \le 10^{18}$).
**Output**

For each test case, output the answer in one line.
Example Input1:
4
17 20
0 63
38 40
998244353998244353 998244853998244853
Example Output1:
1
0
6
2145186925057
**Note**

The following figure illustrates the Z-curve for the first and third test cases in the sample.

| ![](https://espresso.codeforces.com/709824a4ad98c5006c72824943a94018c45ea03d.png) |
| --- |
Illustration of test cases in the sample (red: test case 1, green: test case 3)


## Solution


def solve(l, r):
    res = 0
    for i in range(62, -1, -2):
        if l >> i & 1:
            l -= 1 << i
            r -= 1 << i
            res += 1 << i
        if r >> (i - 1) & 1:
            l += 1 << (i - 1)
            r -= 1 << (i - 1)
            res += 1 << (i - 1)
        if l >= r:
            break
    return res

t = int(input())
for _ in range(t):
    l, r = map(int, input().split())
    print(solve(l, r))


## CODE


def solve(l, r):
    res = 0
    for i in range(62, -1, -2):
        if l >> i & 1:
            l -= 1 << i
            r -= 1 << i
            res += 1 << i
        if r >> (i - 1) & 1:
            l += 1 << (i - 1)
            r -= 1 << (i - 1)
            res += 1 << (i - 1)
        if l >= r:
            break
    return res

t = int(input())
for _ in range(t):
    l, r = map(int, input().split())
    print(solve(l, r))

### Explanation
The solution uses bitwise operations to manipulate the input numbers l and r. We iterate from the most significant bit to the least significant bit in steps of 2. If the current bit of l is 1, we subtract the corresponding power of 2 from both l and r, and add it to the result. If the current bit of r is 1, we add the corresponding power of 2 to l, subtract it from r, and add it to the result. If l becomes greater than or equal to r, we break the loop and return the result. This process essentially translates the Z-curve from l to r to the smallest possible position, which is the desired result.
## Token
[305, 687, 992]
 ### 

## Question


(M)
Bobo wants to use a rejection sampling algorithm to construct a random set $T\subset \{1,2,\dots,n\}$ of size $k$. For parameters $p_1,p_2,...,p_n$ $(0\leq p_i\leq 1)$ and integer $k$, the rejection sampler is defined as follows:

1. Initialize $T \gets \emptyset$;
2. For each $i$ $(1\leq i\leq n)$, add $i$ into $T$ with probability $p_i$;
3. Output $T$ if the size of $T$ is exactly $k$; otherwise, repeat the process.

Now you are given integers $a_1,a_2,...,a_n$ and $k$. Bobo needs to set the parameters $p_1,p_2,\ldots,p_n$ satisfying

- $\sum_{i=1}^n p_i=k$;
- for all $S\subseteq \{1,2,\cdots, n\}$ such that $|S|=k$, the probability that the rejection sampler outputs $S$ is proportional to $\prod_{i \in S} a_i$.

Your task is to find out the parameters $p_1,p_2,\dots,p_n$ for Bobo. It is guaranteed that such parameters exist and **are unique**. Your answer will be considered correct if the absolute error of each $p_i$ doesn't exceed $10^{-6}$ compared to the unique answer.
**Input**

The first line of the input contains two integers $n$ and $k$ ($2 \le n \le 10^5$, $1 \le k \le n-1$).

The second line of the input contains $n$ integers $a_1,a_2,\ldots,a_n$ ($1 \le a_i \le 10^9$).
**Output**

Output $n$ lines. The $i$\-th line contains a single real number $p_i$.

Your answer is considered correct if the absolute error of each parameter does not exceed $10^{-6}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $|b-a| \le 10^{-6}$ for all parameters.
Example Input1:
3 2
5 5 5
Example Output1:
0.666666666667
0.666666666667

0.666666666667 

## Solution


def calculate_p(n, k, a):
    sum_a = sum(a)
    sum_log_a = sum([x**k for x in a])

    b = [x**k / sum_log_a for x in a]
    p = [k * x / sum_a for x in a]

    return p

n, k = map(int, input().split())
a = list(map(int, input().split()))

p = calculate_p(n, k, a)
for x in p:
    print(x)



## CODE


def calculate_p(n, k, a):
    sum_a = sum(a)
    sum_log_a = sum([x**k for x in a])

    b = [x**k / sum_log_a for x in a]
    p = [k * x / sum_a for x in a]

    return p

n, k = map(int, input().split())
a = list(map(int, input().split()))

p = calculate_p(n, k, a)
for x in p:
    print(x)


### Explanation
The rejection sampler outputs a set S with probability proportional to ∏(a_i) for all i in S. So, the parameters p_i should be set such that the probability of selecting a set S of size k is proportional to ∏(a_i). 

If we set p_i = k \* a_i^k / ∑(a_j^k) for all i, the probability of selecting a set S of size k will be proportional to ∏(a_i) for all i in S. However, this does not guarantee that the sum of p_i is equal to k.

The parameters p_i should be set such that the sum of p_i is equal to k. We can set p_i = k \* a_i / ∑(a_j) for all i. This guarantees that the sum of p_i is equal to k.

However, this does not guarantee that the probability of selecting a set S of size k is proportional to ∏(a_i) for all i in S.

We can use the following trick to make the probability of selecting a set S of size k proportional to ∏(a_i) for all i in S, while keeping the sum of p_i equal to k.

We can set b_i = a_i^k / ∑(a_j^k) for all i. Then, we can set p_i = k \* b_i / ∑(b_j) for all i.

However, this is equivalent to setting p_i = k \* a_i / ∑(a_j) for all i.

So, the parameters p_i should be set to p_i = k \* a_i / ∑(a_j) for all i. This guarantees that the sum of p_i is equal to k, and the probability of selecting a set S of size k is proportional to ∏(a_i) for all i in S.

Note that the problem statement guarantees that such parameters exist and are unique.
## Token
[526, 623, 1149]
 ### 

