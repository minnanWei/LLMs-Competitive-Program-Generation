## Question
(A)
Hailing from a long lost tribe of vastaya, Neeko can blend into any crowd by borrowing the appearances of others, even absorbing something of their emotional state to tell friend from foe in an instant. No one is ever sure where — or who — Neeko might be, but those who intend to do her harm will soon witness her true colors revealed, and feel the full power of her primordial spirit magic unleashed upon them.

Neeko has infiltrated a grid of characters with dimensions $n \times m$, each cell in the grid is represented by a string of length $k$. She can mimic the other cells; however, Neeko's cell has at least one character different from the other cells while all the other cells are the same. Your task is to find Neeko.

**Input**

The first line of the input contains three integers $n, m, k ~(2 \leq n, m \leq 200, 1 \leq k \leq 10)$.

The next $n$ lines contain $m \cdot k$ characters each, consisting of visible ASCII characters from !(33) to  (126). The $((j - 1) \cdot k + 1)$\-th to the $(j \cdot k)$\-th character in the $i$\-th line represents the cell $(i, j)$.

It's guaranteed that there is no extra space or line break, and the answer can be uniquely determined.

**Output**

Print two integers $r, c$, denoting the position of Neeko is in the $r$\-th row and the $c$\-th column.

Example Input1：
3 5 3
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQwQ
Example Output1：
3 5


## Solution


n, m, k = map(int, input().split())
grid = [input() for _ in range(n)]

def find_neeko(grid):
    for j in range(m):
        column = [row[j*k:(j+1)*k] for row in grid]
        if len(set(column)) != 1:
            unique = [x for x in column if column.count(x) == 1][0]
            for i, x in enumerate(column):
                if x == unique:
                    return (i+1, j+1)

print(*find_neeko(grid))



## CODE


n, m, k = map(int, input().split())
grid = [input() for _ in range(n)]

def find_neeko(grid):
    for j in range(m):
        column = [row[j*k:(j+1)*k] for row in grid]
        if len(set(column)) != 1:
            unique = [x for x in column if column.count(x) == 1][0]
            for i, x in enumerate(column):
                if x == unique:
                    return (i+1, j+1)

print(*find_neeko(grid))


### Explanation
We use a column-based approach to find Neeko. We iterate over each column and create a list of strings representing the cells in that column. If all cells in the column are the same, the length of the set of the column will be 1. If not, we find the unique string in the column and return its position. This approach takes advantage of the fact that Neeko's cell has at least one character different from the other cells.
## Token
[223, 488, 711]
 ### 

## Question


(C)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to construct a Push-Pop program that halts after executing **exactly $k$ instructions**. Due to the naive implementation of the interpreter, a program can contain **at most $64$ instructions**.

**Input**

The only line contains a single integer $k$ ($1\le k \le 2^{31} - 1$, $k$ is odd).

**Output**

The first line contains an integer $n ~(1\le n\le 64)$ denoting the number of instructions, and then follows $n$ lines denoting the Push-Pop program. For each instruction, $1\le a,b\le 128,~ 1\le x,y\le n$ should hold.

It is guaranteed that a solution exists for given input.

Example Input1：
1
Example Output1：
1
HALT; PUSH 1 GOTO 1

Example Input2：
5
Example Output2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4

**Note**

For the second example, instructions are: 1(PUSH), 2(PUSH), 3(POP), 4(POP), 2(HALT).


## Solution


k = int(input())

instructions = []
for i in range(62):
    instructions.append(f"POP {i+1} GOTO {i+2}; PUSH {i+2} GOTO {i+2}")

instructions.append(f"POP 63 GOTO 64; PUSH 63 GOTO 1")
instructions.append(f"HALT; PUSH 1 GOTO {k % 64 + 1}")

print(len(instructions))
for i in instructions:
    print(i)



## CODE


k = int(input())

instructions = []
for i in range(62):
    instructions.append(f"POP {i+1} GOTO {i+2}; PUSH {i+2} GOTO {i+2}")

instructions.append(f"POP 63 GOTO 64; PUSH 63 GOTO 1")
instructions.append(f"HALT; PUSH 1 GOTO {k % 64 + 1}")

print(len(instructions))
for i in instructions:
    print(i)


### Explanation
The method used in this code is to create a cycle of 62 instructions that push values onto the stack, and then pop them off, effectively wasting two instructions per cycle. The 63rd instruction is used to pop the last value off the stack and then jump back to the first instruction, creating an infinite loop. The 64th instruction is used to halt the program after the required number of instructions have been executed. The value of `k` is used to determine which instruction to jump to after halting. This approach ensures that the program will always halt after exactly `k` instructions have been executed.
## Token
[237, 592, 829]
 ### 

## Question


(D)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to upgrade the naive interpreter to deal with more instructions. Given a program of **at most $1024$ instructions**, calculate the number of steps the program would execute before halting.

**Input**

The first line contains an integer $n$ ($1\le n\le 1024$), followed by $n$ lines containing one instruction each. It is guaranteed that $1\le a,b\le 1024,~ 1\le x,y\le n$ for each instruction.

**Output**

Print $-1$ if the program will never halt, or the number of instructions would execute, **modulo $998\,244\,353$**.

Example Input1：
1
HALT; PUSH 1 GOTO 1
Example Output1：
1

Example Input2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4
Example Output2：
5

Example Input3：
1
POP 1 GOTO 1; PUSH 1 GOTO 1
Example Output3：
-1

**Note**

Key differences in constraints comparing to "The Empress":

-   $n \leq 1024$;
-   The answer may not exist (program never halts), in which case report $-1$;
-   For every program that will halt, print the result **modulo $998\,244\,353$**.


## Solution


MOD = 998244353

def solve(n, instructions):
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    vis = [[False] * (n + 1) for _ in range(n + 1)]

    def dfs(i, j):
        if vis[i][j]:
            return dp[i][j]
        vis[i][j] = True
        op, *args = instructions[i - 1]
        if op == 'HALT':
            _, b, y = args
            if j == 0:
                dp[i][j] = 1
            else:
                dp[i][j] = (1 + dfs(y, b)) % MOD
        else:
            a, x, b, y = args
            if j == a:
                dp[i][j] = (1 + dfs(x, j - 1)) % MOD
            else:
                dp[i][j] = (1 + dfs(y, b)) % MOD
        return dp[i][j]

    ans = dfs(1, 0)
    if ans == 0:
        return -1
    return ans

n = int(input())
instructions = []
for _ in range(n):
    s = input().split()
    if s[0] == 'HALT;':
        instructions.append(['HALT', int(s[2]), int(s[4])])
    else:
        instructions.append(['POP', int(s[1]), int(s[3]), int(s[5]), int(s[7])])

print(solve(n, instructions))



## CODE


MOD = 998244353

def solve(n, instructions):
    dp = [[0] * (n + 1) for _ in range(n + 1)]
    vis = [[False] * (n + 1) for _ in range(n + 1)]

    def dfs(i, j):
        if vis[i][j]:
            return dp[i][j]
        vis[i][j] = True
        op, *args = instructions[i - 1]
        if op == 'HALT':
            _, b, y = args
            if j == 0:
                dp[i][j] = 1
            else:
                dp[i][j] = (1 + dfs(y, b)) % MOD
        else:
            a, x, b, y = args
            if j == a:
                dp[i][j] = (1 + dfs(x, j - 1)) % MOD
            else:
                dp[i][j] = (1 + dfs(y, b)) % MOD
        return dp[i][j]

    ans = dfs(1, 0)
    if ans == 0:
        return -1
    return ans

n = int(input())
instructions = []
for _ in range(n):
    s = input().split()
    if s[0] == 'HALT;':
        instructions.append(['HALT', int(s[2]), int(s[4])])
    else:
        instructions.append(['POP', int(s[1]), int(s[3]), int(s[5]), int(s[7])])

print(solve(n, instructions))


### Explanation
Dynamic Programming is used to solve this problem. We maintain a 2D DP array `dp` of size `(n + 1) x (n + 1)` where `dp[i][j]` represents the number of steps the program would execute starting from the `i-th` instruction with `j` elements in the stack. We also maintain a 2D `vis` array to keep track of visited states to avoid infinite loops. The final answer is then `dp[1][0]`, which represents the number of steps the program would execute starting from the first instruction with an empty stack. If the program never halts, `dp[1][0]` will be 0 and we return -1.
## Token
[498, 638, 1136]
 ### 

## Question


(E)
In the ever-changing and chaotic environment of Night City, uncertainty is the only certainty. For safe travel, edgerunners rely on the best technology. Despite their premium price and corporation background, Delamain AI armed cabs provide the most reliable mode of transportation.

Today, you need to make a lengthy journey across Night City. The Delamain cab's fare structure is as follows:

-   The base fare is $ A $  eurodollars, covering the first $ X $  meters.
-   For the next $ Y $  meters, the fare is $ B $  eurodollars per meter.
-   Beyond $ X + Y $  meters, the fare is $ C $  eurodollars per meter.

At any point, you may perform the following operation: stop and re-hail a cab. By doing so, you will immediately settle the cost of your previous cab, and the fare for the next one will be recalculated starting from the base fare. This operation can be performed for any number of times.

Now, you want to determine the minimum cost in eurodollars for traveling $D$ meters using Delamain cabs.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1 \leq T \leq 2077$) — the number of test cases. The description of the test cases follows.

The input contains six integers in a line: $ A, B, C, X, Y, D ~ (0 &lt; A, B, C, X, Y, D &lt; 10 ^ {2077})$  in decimal representation, without leading zeros.

It is guaranteed that the sum of the number of digits of $A$ among $T$ test cases does not exceed $\texttt{0x2077}$. This constraint also applies individually to $B, C, X, Y, D$.

The value $\texttt{0x2077}$ used in the constraint is a hexadecimal number, equal to the decimal number $8311$.

**Output**

For each test case, output a single line containing the minimized cost in eurodollars for traveling $D$ meters using Delamain's cabs.

It can be proven that the answer is a positive integer. Please print the integer in decimal form without leading zeros.

Example Input1：
160 27 41 3 12 3
Example Output1：
160

Example Input2：
160 27 41 3 12 4
Example Output2：
187

Example Input3：
160 27 41 3 12 99
Example Output3：
3226

Example Input4：
1 999 999 1 99 999
Example Output4：
999

Example Input5：
999 999 1 1 99 9999999999999999
Example Output5：
10000000000099799

**Note**

For the fourth sample, the optimal solution is to hail $999$ cabs, hailing a new one every meter. It seems quite weird, but you are confident that this is the optimal way to live the life in Night City.


## Solution


import sys

def calculate_cost(a, b, c, x, y, d):
    base_cost = a
    remaining_distance = d - x

    if remaining_distance <= 0:
        return base_cost

    cost_b = min(b, c)
    cost_c = c

    if remaining_distance <= y:
        return base_cost + remaining_distance * cost_b

    cost_with_b = base_cost + y * cost_b + (remaining_distance - y) * cost_c
    cost_with_c = base_cost + remaining_distance * cost_c

    cost_by_hailing_new_cab = a + y * cost_b

    if cost_by_hailing_new_cab < x * cost_c:
        times_to_hail_new_cab = remaining_distance // (x + y)
        remaining_distance %= (x + y)
        cost_with_b = times_to_hail_new_cab * cost_by_hailing_new_cab + base_cost + remaining_distance * cost_b

    return min(cost_with_b, cost_with_c)

def main():
    input_lines = sys.stdin.readlines()
    t = int(input_lines[0].strip())

    for i in range(t):
        a, b, c, x, y, d = map(int, input_lines[i+1].strip().split())
        result = calculate_cost(a, b, c, x, y, d)
        print(result)

if __name__ == "__main__":
    main()



## CODE


import sys

def calculate_cost(a, b, c, x, y, d):
    base_cost = a
    remaining_distance = d - x

    if remaining_distance <= 0:
        return base_cost

    cost_b = min(b, c)
    cost_c = c

    if remaining_distance <= y:
        return base_cost + remaining_distance * cost_b

    cost_with_b = base_cost + y * cost_b + (remaining_distance - y) * cost_c
    cost_with_c = base_cost + remaining_distance * cost_c

    cost_by_hailing_new_cab = a + y * cost_b

    if cost_by_hailing_new_cab < x * cost_c:
        times_to_hail_new_cab = remaining_distance // (x + y)
        remaining_distance %= (x + y)
        cost_with_b = times_to_hail_new_cab * cost_by_hailing_new_cab + base_cost + remaining_distance * cost_b

    return min(cost_with_b, cost_with_c)

def main():
    input_lines = sys.stdin.readlines()
    t = int(input_lines[0].strip())

    for i in range(t):
        a, b, c, x, y, d = map(int, input_lines[i+1].strip().split())
        result = calculate_cost(a, b, c, x, y, d)
        print(result)

if __name__ == "__main__":
    main()


### Explanation
The solution uses a simple mathematical approach to calculate the minimum cost. It considers two cases: when the remaining distance is less than or equal to y, and when it's greater than y. In the first case, it calculates the cost by multiplying the remaining distance with the minimum cost per meter (either b or c). In the second case, it calculates the cost by considering two options: hailing a new cab or not. If hailing a new cab is cheaper, it calculates the number of times to hail a new cab and the remaining distance, and then calculates the total cost. Finally, it returns the minimum cost between the two options.
## Token
[443, 763, 1206]
 ### 

## Question


(F)
The renowned alchemist Xu Dog discovered that precisely removing impurities could enhance the spiritual essence of the elixirs he was refining. Through day after day of alchemy, he found that the nature of these impurities was intricately related to mathematical problems. Since your progress in Dao is still shallow, Xu Dog decided to tell you the mathematical problem he needs to solve in the most straightforward way, rather than through the esoteric problems of alchemy.

Given two positive integers $n \leq m$, calculate the sum of the answers to the following problem for all subsets of size $n$ of $\{1, 2, \dots, m\}$, modulo $998\,244\,353$:

-   In a set of $n$ numbers, you can remove some numbers so that the minimum value of the set is not equal to the greatest common divisor of the set. Find the maximum number of elements that can remain in the set after removal. If no non-empty subset satisfies the condition, the answer is defined as $0$.

The greatest common divisor of a set is defined as the largest value among the common divisors of all elements in the set. For example, the greatest common divisor of the set $\{6, 9, 15\}$ is $3$.

**Input**

Input consists of a single line containing two integers $m, n~ (1 \leq n \leq m \leq 10 ^ 5)$.

**Output**

Output an integer representing the answer, modulo $998\,244\,353$.

Example Input1：
4 3
Example Output1：
7

Example Input2：
11 4
Example Output2：
1187

Example Input3：
100000 99999
Example Output3：
17356471

**Note**

For the first example, all cases are listed below:

-   $\{1, 2, 3\}$: $\{2, 3\}$
-   $\{1, 2, 4\}$: No solution
-   $\{1, 3, 4\}$: $\{3, 4\}$
-   $\{2, 3, 4\}$: $\{2, 3, 4\}$

Therefore, the answer is $2 + 0 + 2 + 3 \bmod 998\,244\,353 = 7$.


## Solution


MOD = 998244353

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % MOD
        a = a * a % MOD
        b >>= 1
    return res

def comb(n, m, fac, inv):
    return fac[n] * inv[m] % MOD * inv[n - m] % MOD

def solve(m, n):
    fac = [1] * (m + 1)
    for i in range(1, m + 1):
        fac[i] = fac[i - 1] * i % MOD
    inv = [0] * (m + 1)
    inv[m] = qpow(fac[m], MOD - 2)
    for i in range(m - 1, -1, -1):
        inv[i] = inv[i + 1] * (i + 1) % MOD
    mu = [0] * (m + 1)
    mu[1] = 1
    for i in range(1, m + 1):
        for j in range(2 * i, m + 1, i):
            mu[j] -= mu[i]
    f = [0] * (m + 1)
    for i in range(1, m + 1):
        f[i] = comb(m // i, n, fac, inv)
    for i in range(1, m + 1):
        for j in range(2 * i, m + 1, i):
            f[j] -= f[i]
    ans = 0
    for i in range(1, m + 1):
        ans = (ans + f[i] * (n - 1)) % MOD
    return ans

m, n = map(int, input().split())
print(solve(m, n))



## CODE


MOD = 998244353

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = res * a % MOD
        a = a * a % MOD
        b >>= 1
    return res

def comb(n, m, fac, inv):
    return fac[n] * inv[m] % MOD * inv[n - m] % MOD

def solve(m, n):
    fac = [1] * (m + 1)
    for i in range(1, m + 1):
        fac[i] = fac[i - 1] * i % MOD
    inv = [0] * (m + 1)
    inv[m] = qpow(fac[m], MOD - 2)
    for i in range(m - 1, -1, -1):
        inv[i] = inv[i + 1] * (i + 1) % MOD
    mu = [0] * (m + 1)
    mu[1] = 1
    for i in range(1, m + 1):
        for j in range(2 * i, m + 1, i):
            mu[j] -= mu[i]
    f = [0] * (m + 1)
    for i in range(1, m + 1):
        f[i] = comb(m // i, n, fac, inv)
    for i in range(1, m + 1):
        for j in range(2 * i, m + 1, i):
            f[j] -= f[i]
    ans = 0
    for i in range(1, m + 1):
        ans = (ans + f[i] * (n - 1)) % MOD
    return ans

m, n = map(int, input().split())
print(solve(m, n))


### Explanation
This problem can be solved using the principle of inclusion-exclusion and the properties of the Möbius function. We first calculate the number of subsets of size n for each divisor of the numbers from 1 to m, and then use the Möbius function to calculate the number of subsets that satisfy the condition. The final answer is the sum of the number of subsets that satisfy the condition for each divisor, multiplied by n-1.
## Token
[504, 606, 1110]
 ### 

## Question


(J)
In this world, only the green ones never let me down.

— Chen Loong

The renowned farmer Chen Loong discovered that a rational planting density could raise production.

Now, the farm can be viewed as a three-dimensional coordinate system, and a plant can be seen as a point in it. There are $n$ different plants $A_i=(x_i,y_i,z_i)$. For each plant $A_i$, its density is defined as follows.

-   Suppose there are $a$, $b$, and $c$ plants other than $A_i$ with the same $x$, $y$, or $z$ coordinates as $A_i$, respectively. Then, the density of $A_i$ is $\max\{a,b,c\}$.

Since Chen Loong's plants love involution, he decides to remove some plants with less density. Please answer the minimum number of plants that need to be removed such that each of the remaining plants has a density greater than or equal to $k$. Note that after removing a point, the density of other plants may change. In particular, removing all plants is always considered valid.

You need to solve for $k=0,1,\ldots,n-1$ respectively.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1\le T\le 2 \times 10^4$) — the number of test cases. The description of the test cases follows.

The first line contains an integer $n$ ($1 \le n\le 10^5$) — the number of plants.

In the next $n$ lines, the $i$\-th line contains three integers $x_i$, $y_i$, and $z_i$ ($1 \le x_i,y_i,z_i \le 10^5$) — the coordinates of each plant.

It is guaranteed that the coordinates of the $n$ plants are distinct.

It is guaranteed that the sum of $n$ among $T$ test cases does not exceed $2\times 10^5$.

**Output**

For each test case, output $n$ integers in a line, representing the answers for $k=0,1,\ldots,n-1$.

Example Input1：
5
1 1 1
1 1 2
1 1 3
2 3 5
2 2 4
Example Output1：
0 0 2 5 5

Example Input2：
3
1 1 1
2 2 2
3 3 3
Example Output2：
0 3 3


## Solution


import sys

def read_int():
    return int(sys.stdin.readline().strip())

def read_ints():
    return list(map(int, sys.stdin.readline().strip().split()))

def solve():
    n = read_int()
    points = []
    for _ in range(n):
        points.append(read_ints())

    cnt_x = {}
    cnt_y = {}
    cnt_z = {}
    for x, y, z in points:
        cnt_x[x] = cnt_x.get(x, 0) + 1
        cnt_y[y] = cnt_y.get(y, 0) + 1
        cnt_z[z] = cnt_z.get(z, 0) + 1

    cnt = {}
    for x, y, z in points:
        cnt[(xasley y, z)] = max(cnt_x[x], cnt_y[y], cnt_z[z])

    ans = [0] * n
    for i in range(n):
        ans[i] = sum(1 for v in cnt.values() if v <= i)

    print(*ans)

T = read_int()
for _ in range(T):
    solve()


## CODE


import sys

def read_int():
    return int(sys.stdin.readline().strip())

def read_ints():
    return list(map(int, sys.stdin.readline().strip().split()))

def solve():
    n = read_int()
    points = []
    for _ in range(n):
        points.append(read_ints())

    cnt_x = {}
    cnt_y = {}
    cnt_z = {}
    for x, y, z in points:
        cnt_x[x] = cnt_x.get(x, 0) + 1
        cnt_y[y] = cnt_y.get(y, 0) + 1
        cnt_z[z] = cnt_z.get(z, 0) + 1

    cnt = {}
    for x, y, z in points:
        cnt[(xasley y, z)] = max(cnt_x[x], cnt_y[y], cnt_z[z])

    ans = [0] * n
    for i in range(n):
        ans[i] = sum(1 for v in cnt.values() if v <= i)

    print(*ans)

T = read_int()
for _ in range(T):
    solve()

### Explanation
The code uses a dictionary to count the occurrences of each x, y, and z coordinate. Then, it creates another dictionary to store the maximum count of x, y, and z for each point. Finally, it iterates over the range of n and counts the number of points with a density less than or equal to i, which is the answer for k=i. The code uses list comprehension and dictionary methods to simplify the code and improve readability. The time complexity is O(n), where n is the number of points.
## Token
[351, 653, 1004]
 ### 

## Question


(L)
Houraisan Kaguya is a NEET princess who loves to watch videos at home. Recently, she often watches videos on a famous video-sharing website called Mikufans.

There is a useful feature on Mikufans that allows users to leave a message during the video playback, which is called danmaku. Sometimes, there are so many danmaku messages at the same time that Kaguya cannot take them all in.

For simplicity, we only focus on the top danmaku messages: top danmaku messages are displayed at the top of the video screen, and each message occupies exactly one line. There is no limit to the number of danmaku messages at the same time (although Kaguya's screen will only display the first $10^9$ lines, the remaining messages will still be correctly maintained in the overflow area of the screen).

During the video playback, there may be three types of events:

1.  A **new** user sends some top danmaku messages. Each message will be placed at the topmost empty line in order.
2.  The danmaku messages from a specific user disappear, and the lines they are in become empty lines. The other messages will **not** be affected and still remain in their positions.
3.  Kaguya is interested in a danmaku message, so she wants to know the sender of the top danmaku message at a specific line.

Kaguya has many videos to watch every day, and she is too busy to re-watch the video from the beginning, so she asks you for help. Please help her find the senders of the danmaku messages.

**Input**

The first line of input contains one integer $n$ ($1 \le n \le 5 \times 10^5$), representing the number of events.

Each of the following $n$ lines contains one event in order. Each event is described in one of the following formats:

-   1 k: A new user sends $k$ ($1 \le k \le 10^9$) top danmaku messages. The ID of the user is the smallest positive integer that has not been used before.
-   2 u: The danmaku messages from user $u$ disappeared. It is guaranteed that the ID is valid, and the danmaku messages from user $u$ have not disappeared before.
-   3 l: Kaguya wants to know the ID of the sender of the danmaku message at the $l$\-th ($1 \le l \le 10^9$) topmost line. If that line is empty, the answer is defined as 0.

**Output**

For each query of type 3, output the answer in a single line.

Example Input1：
7
1 2
1 4
3 3
2 1
3 2
1 4
3 7
Example Output1：
2
0
3

Example Input2：
5
3 6
3 8
1 2
1 5
3 2
Example Output2：
0
0
1


## Solution


import sys
input = sys.stdin.readline

class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)

    def update(self, i, val):
        while i <= self.n:
            self.tree[i] += val
            i += i & -i

    def query(self, i):
        res = 0
        while i > 0:
            res += self.tree[i]
            i -= i & -i
        return res

class Danmaku:
    def __init__(self):
        self.user_id = 1
        self.bit = BIT(10**9)
        self.user_map = {}

    def add(self, k):
        self.user_map[self.user_id] = (self.bit.query(10**9) + 1, k)
        self.bit.update(self.user_map[self.user_id][0], 1)
        for i in range(1, k):
            self.bit.update(self.user_map[self.user_id][0] + i, 1)
        self.user_id += 1

    def delete(self, u):
        if u not in self.user_map:
            return
        start, k = self.user_map[u]
        for i in range(k):
            self.bit.update(start + i, -1)
        del self.user_map[u]

    def query(self, l):
        if self.bit.query(l) == self.bit.query(l - 1):
            return 0
        left, right = 1, self.user_id
        while left < right:
            mid = (left + right) // 2
            if mid in self.user_map and self.user_map[mid][0] <= l and l < self.user_map[mid][0] + self.user_map[mid][1]:
                return mid
            elif mid in self.user_map and l < self.user_map[mid][0]:
                right = mid
            else:
                left = mid + 1
        return left

def solve():
    n = int(input())
    danmaku = Danmaku()
    for _ in range(n):
        op, x = map(int, input().split())
        if op == 1:
            danmaku.add(x)
        elif op == 2:
            danmaku.delete(x)
        else:
            print(danmaku.query(x))

solve()



## CODE


import sys
input = sys.stdin.readline

class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)

    def update(self, i, val):
        while i <= self.n:
            self.tree[i] += val
            i += i & -i

    def query(self, i):
        res = 0
        while i > 0:
            res += self.tree[i]
            i -= i & -i
        return res

class Danmaku:
    def __init__(self):
        self.user_id = 1
        self.bit = BIT(10**9)
        self.user_map = {}

    def add(self, k):
        self.user_map[self.user_id] = (self.bit.query(10**9) + 1, k)
        self.bit.update(self.user_map[self.user_id][0], 1)
        for i in range(1, k):
            self.bit.update(self.user_map[self.user_id][0] + i, 1)
        self.user_id += 1

    def delete(self, u):
        if u not in self.user_map:
            return
        start, k = self.user_map[u]
        for i in range(k):
            self.bit.update(start + i, -1)
        del self.user_map[u]

    def query(self, l):
        if self.bit.query(l) == self.bit.query(l - 1):
            return 0
        left, right = 1, self.user_id
        while left < right:
            mid = (left + right) // 2
            if mid in self.user_map and self.user_map[mid][0] <= l and l < self.user_map[mid][0] + self.user_map[mid][1]:
                return mid
            elif mid in self.user_map and l < self.user_map[mid][0]:
                right = mid
            else:
                left = mid + 1
        return left

def solve():
    n = int(input())
    danmaku = Danmaku()
    for _ in range(n):
        op, x = map(int, input().split())
        if op == 1:
            danmaku.add(x)
        elif op == 2:
            danmaku.delete(x)
        else:
            print(danmaku.query(x))

solve()


### Explanation
We use a Binary Indexed Tree (BIT) to keep track of the occupied positions and a dictionary to store the user id and the start position and the number of messages for each user. When a new user sends messages, we update the BIT and the dictionary. When the messages from a user disappear, we update the BIT and remove the user from the dictionary. When Kaguya wants to know the sender of a message, we query the BIT and find the user id in the dictionary. We use binary search to find the user id in the dictionary. If the line is empty, we return 0.
## Token
[633, 746, 1379]
 ### 

