## Question
(B)
Grammy's birthday is approaching, and she gets a sequence $A$ from her friends as a gift. The sequence consists of only $0$, $1$, and $2$. Grammy thinks that the sequence is too long, so she decides to modify $A$ to make it shorter.

Formally, Grammy can perform an arbitrary number of operations. Each time she can choose one of the following three operations to perform:

-   Change any $2$ into $0$ or $1$.
-   Choose two adjacent $0$s, erase them, and concatenate the rest of the parts.
-   Choose two adjacent $1$s, erase them, and concatenate the rest of the parts.

Calculate the minimum sequence length Grammy can get.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first and only line contains a string of length $n$ ($1\leq n\leq 2 \times 10^5$) consisting of digits $0$, $1$, and $2$, indicating the initial sequence $A$.

It is guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the minimum sequence length Grammy can get.

Example Input1:
0110101
Example Output1：
3
Example Input2:
01020102
Example Output2：
4
Example Input3:
0000021111
Example Output3：
0
Example Input4:
1012121010
Example Output4：
6
Example Input5:
0100202010
Example Output5：
0


## Solution


def solve(s):
    stack = []
    for c in s:
        if c == '2':
            if stack and stack[-1] != '2':
                stack.pop()
            else:
                stack.append('2')
        elif stack and stack[-1] == c:
            stack.pop()
        else:
            stack.append(c)
    return len(stack)

t = int(input())
for _ in range(t):
    s = input()
    print(solve(s))



## CODE


def solve(s):
    stack = []
    for c in s:
        if c == '2':
            if stack and stack[-1] != '2':
                stack.pop()
            else:
                stack.append('2')
        elif stack and stack[-1] == c:
            stack.pop()
        else:
            stack.append(c)
    return len(stack)

t = int(input())
for _ in range(t):
    s = input()
    print(solve(s))


### Explanation
The solution uses a stack to keep track of the sequence. When a '2' is encountered, it checks if the top of the stack is not '2'. If it's not, it pops the top element from the stack (because '2' can be changed to the opposite of the top element and then both can be removed). If the top element is '2' or the stack is empty, it pushes '2' onto the stack. When a '0' or '1' is encountered, it checks if the top of the stack is the same. If it is, it pops the top element from the stack (because two adjacent '0's or '1's can be removed). If it's not, it pushes the element onto the stack. The final length of the stack is the minimum sequence length.
## Token
[276, 457, 733]
 ### 

## Question

(C)
You are given a tree consisting of $n$ vertices, rooted at vertex $1$. It is guaranteed that every vertex has a smaller index than all of its children. A topological order of this tree is a permutation $p_1,p_2,\dots,p_n$ of $n$ that satisfies the following constraint: For all $1\leq i&lt;j\leq n$, vertex $p_j$ is not the parent of vertex $p_i$.

For each $1 \le i \le n$, calculate the number of topological orders of the given tree satisfying $p_i=i$, modulo $998\,244\,353$.

**Input**

There is only one test case in each test file.

The first line contains an integer $n$ ($2\leq n\leq 5\,000$), denoting the number of vertices of the tree.

The second line contains $(n-1)$ integers $f_2,f_3,\dots,f_n$ ($1\leq f_i&lt; i$), where $f_i$ is the parent of vertex $i$.

**Output**

Output one line containing $n$ integers $a_1, a_2, \cdots, a_n$ separated by a space, where $a_i$ is the number of topological orders satisfying $p_i=i$, modulo $998\,244\,353$.

Example Input1：
4
1 1 2
Example Output1：
3 2 1 2
Example Input2：
9
1 1 2 2 3 3 4 5
Example Output2：
672 420 180 160 152 108 120 170 210

**Note**

For the first sample test case, all topological orders of the tree are $\{1, 2, 3, 4\}$, $\{1, 3, 2, 4\}$ and $\{1, 2, 4, 3\}$. There are $3$ of them satisfying $p_1 = 1$, $2$ of them satisfying $p_2 = 2$, $1$ of them satisfying $p_3 = 3$, and $2$ of them satisfying $p_4 = 4$.


## Solution


MOD = 998244353

def dfs(graph, node, dp):
    if not graph[node]:
        dp[node] = [1, 1]
        return dp[node]

    total = 0
    prefix = [1]
    for child in graph[node]:
        child_dp = dfs(graph, child, dp)
        total += child_dp[0]
        total %= MOD
        prefix.append((prefix[-1] * child_dp[1]) % MOD)

    suffix = [1]
    for child in reversed(graph[node]):
        child_dp = dp[child]
        suffix.append((suffix[-1] * child_dp[1]) % MOD)

    suffix.reverse()
    dp[node] = [total, 0]
    for i in range(len(graph[node])):
        dp[node][1] += (prefix[i] * suffix[i+1] * dp[graph[node][i]][0]) % MOD
        dp[node][1] %= MOD

    return dp[node]

def solve():
    n = int(input())
    parents = list(map(int, input().split()))

    graph = [[] for _ in range(n+1)]
    for i in range(len(parents)):
        graph[parents[i]].append(i+2)

    dp = [[0, 0] for _ in range(n+1)]
    dfs(graph, 1, dp)

    result = []
    for i in range(1, n+1):
        if i == 1:
            result.append(dp[i][1])
        else:
            parent = parents[i-2]
            parent_dp = dp[parent]
            child_dp = dp[i]
            total = parent_dp[0] - child_dp[0]
            if total < 0:
                total += MOD
            result.append((total * child_dp[1]) % MOD)

    print(*result)

if __name__ == "__main__":
    solve()



## CODE


MOD = 998244353

def dfs(graph, node, dp):
    if not graph[node]:
        dp[node] = [1, 1]
        return dp[node]

    total = 0
    prefix = [1]
    for child in graph[node]:
        child_dp = dfs(graph, child, dp)
        total += child_dp[0]
        total %= MOD
        prefix.append((prefix[-1] * child_dp[1]) % MOD)

    suffix = [1]
    for child in reversed(graph[node]):
        child_dp = dp[child]
        suffix.append((suffix[-1] * child_dp[1]) % MOD)

    suffix.reverse()
    dp[node] = [total, 0]
    for i in range(len(graph[node])):
        dp[node][1] += (prefix[i] * suffix[i+1] * dp[graph[node][i]][0]) % MOD
        dp[node][1] %= MOD

    return dp[node]

def solve():
    n = int(input())
    parents = list(map(int, input().split()))

    graph = [[] for _ in range(n+1)]
    for i in range(len(parents)):
        graph[parents[i]].append(i+2)

    dp = [[0, 0] for _ in range(n+1)]
    dfs(graph, 1, dp)

    result = []
    for i in range(1, n+1):
        if i == 1:
            result.append(dp[i][1])
        else:
            parent = parents[i-2]
            parent_dp = dp[parent]
            child_dp = dp[i]
            total = parent_dp[0] - child_dp[0]
            if total < 0:
                total += MOD
            result.append((total * child_dp[1]) % MOD)

    print(*result)

if __name__ == "__main__":
    solve()


### Explanation
This problem can be solved using dynamic programming and depth-first search. The idea is to calculate the number of topological orders for each subtree and then combine them to get the final result. 

For each node, we calculate two values: the total number of topological orders for the subtree rooted at this node, and the number of topological orders where this node is at the beginning. 

We use a depth-first search to traverse the tree and calculate these values for each node. The final result is then calculated by combining these values for each node. 

The time complexity of this solution is O(n), where n is the number of nodes in the tree. The space complexity is also O(n), as we need to store the dynamic programming values for each node.
## Token
[559, 583, 1142]
 ### 

## Question


(E)
Given a string $S = s_0s_1\cdots s_{n-1}$ of length $n$, you can shift $S$ to the left for at most $k$ times (including zero times). Calculate the maximum number of "nanjing" substrings contained in the string after the operations.

More formally, let $f(S, d)$ be the string obtained by shifting $S$ to the left $d$ times. That is, $f(S, d) = s_{(d+0)\bmod n}s_{(d+1)\bmod n}\cdots s_{(d+n-1)\bmod n}$. Let $g(f(S, d), l, r) = s_{(d+l)\bmod n}s_{(d+l+1)\bmod n}\cdots s_{(d+r)\bmod n}$. Let $h(d)$ be the number of integer pairs $(l, r)$ such that $0 \le l \le r &lt; n$ and $g(f(S, d), l, r) =$ nanjing. Find an integer $d$ such that $0 \le d \le k$ to maximize $h(d)$ and output this maximized value.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $k$ ($1 \le n \le 2 \times 10^5$, $0 \le k \le 10^9$) indicating the length of the string and the maximum number of left shifts you can perform.

The second line contains a string $s_0s_1\cdots s_{n - 1}$ of length $n$. The string consists of lower-cased English letters.

It's guaranteed that the sum of $n$ of all test cases will not exceed $5 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of "nanjing" substrings contained in the string.

Example Input1：
21 10
jingicpcnanjingsuanan
Example Output1：
2

Example Input2：
21 0
jingicpcnanjingsuanan
Example Output2：
1

Example Input3：
21 3
nanjingnanjingnanjing
Example Output3：
3

Example Input4：
4 100
icpc
Example Output4：
0

**Note**

For the first sample test case, we can shift the string to the left $6$ times and get the string "pcnanjingsuananjingic". There are two "nanjing" substrings.

For the second sample test case, because $k = 0$, we cannot perform any left shifting. There is one "nanjing" substring in the original string.


## Solution


def kmp(s):
    n = len(s)
    lps = [0] * n
    j = 0
    for i in range(1, n):
        while j > 0 and s[j] != s[i]:
            j = lps[j - 1]
        if s[j] == s[i]:
            j += 1
        lps[i] = j
    return lps

def count_substring(s, sub):
    lps = kmp(sub)
    n = len(s)
    m = len(sub)
    j = 0
    count = 0
    for i in range(n):
        while j > 0 and s[i] != sub[j]:
            j = lps[j - 1]
        if s[i] == sub[j]:
            j += 1
        if j == m:
            count += 1
            j = lps[j - 1]
    return count

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    s = s + s
    sub = "nanjing"
    max_count = 0
    for i in range(n):
        if i > k:
            break
        count = count_substring(s[i:i + n], sub)
        max_count = max(max_count, count)
    print(max_count)



## CODE


def kmp(s):
    n = len(s)
    lps = [0] * n
    j = 0
    for i in range(1, n):
        while j > 0 and s[j] != s[i]:
            j = lps[j - 1]
        if s[j] == s[i]:
            j += 1
        lps[i] = j
    return lps

def count_substring(s, sub):
    lps = kmp(sub)
    n = len(s)
    m = len(sub)
    j = 0
    count = 0
    for i in range(n):
        while j > 0 and s[i] != sub[j]:
            j = lps[j - 1]
        if s[i] == sub[j]:
            j += 1
        if j == m:
            count += 1
            j = lps[j - 1]
    return count

t = int(input())
for _ in range(t):
    n, k = map(int, input().split())
    s = input()
    s = s + s
    sub = "nanjing"
    max_count = 0
    for i in range(n):
        if i > k:
            break
        count = count_substring(s[i:i + n], sub)
        max_count = max(max_count, count)
    print(max_count)


### Explanation
The solution uses the KMP (Knuth-Morris-Pratt) algorithm for string matching. The KMP algorithm is used to find the longest proper prefix which is also a proper suffix in the substring "nanjing". This is done to efficiently count the occurrences of "nanjing" in the given string.

The function `kmp(s)` calculates the lps (longest proper prefix which is also a proper suffix) array for the string `s`.

The function `count_substring(s, sub)` counts the occurrences of the substring `sub` in the string `s` using the lps array.

In the main part of the solution, the string `s` is concatenated with itself to simulate the left shift operation. Then, for each possible left shift `i` from 0 to `k`, the solution counts the occurrences of "nanjing" in the shifted string `s[i:i + n]` and updates the maximum count.

Finally, the solution prints the maximum count of "nanjing" substrings found.
## Token
[518, 718, 1236]
 ### 

## Question


(F)
In Pigeland, the subway system is quite advanced. It consists of $n$ sites, numbered from $1$ to $n$, and $k$ directed subway lines, numbered from $1$ to $k$. Subway line $i$ travels through sites $x_{i, 1}, x_{i, 2}, \cdots, x_{i, p_i}$ in order, where $x_{i, j}$ is the $j$\-th site visited by line $i$. It takes $w_{i,j}$ units of time to travel from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$.

When multiple lines meet at the same site, passengers can transfer between lines. If a passenger is at a site on line $x$, while line $y$ also passes through this site, he/she can spend $a_y \times b_x$ units of time to transfer from line $x$ to line $y$, where $a_y$ and $b_x$ are given coefficients for lines $y$ and $x$. After transferring, the passenger is still at the same site, but on line $y$.

You start at site $1$. Find the minimum time needed to reach site $s$ for all $2 \le s \le n$. In particular, you can start by choosing any line at site $1$ with no transfer time cost. It is guaranteed that all sites are reachable from site $1$.

**Input**

There is only one test case in each test file.

The first line contains two integers $n$ and $k$ ($2 \leq n \leq 2 \times 10^5$, $1 \leq k \leq 2 \times 10^5$), indicating the number of sites and the number of subway lines.

The second line contains $k$ integers $a_1, a_2, \cdots, a_k$ ($1 \leq a_i \leq 10^6$).

The third line contains $k$ integers $b_1, b_2, \cdots, b_k$ ($1 \leq b_i \leq 10^6$).

For the following $k$ lines, the $i$\-th line first contains an integer $p_i$ ($2 \leq p_i \leq n$), indicating the number of sites line $i$ travels through. Then $(2p_i - 1)$ integers $x_{i, 1}, w_{i, 1}, x_{i, 2}, \ldots, x_{i, p_i - 1}, w_{i, p_i - 1}, x_{i, p_i}$ follow ($1 \leq x_{i,j} \leq n$, $1 \leq w_{i,j} \leq 10^9$), where $x_{i, j}$ is the $j$\-th site visited by line $i$, and $w_{i,j}$ is the travel time from site $x_{i,j}$ to site $x_{i,j+1}$ on line $i$. The sites traveled through by a subway line are distinct.

It is guaranteed that $\sum\limits_{i=1}^k (p_i - 1) \leq 2 \times 10^5$.

**Output**

Output one line containing $(n - 1)$ integers $d_2, d_3, \cdots, d_n$ separated by a space, where $d_i$ is the minimum time cost from site $1$ to site $i$.

Example Input1：
6 3
1 5 1
5 5 1
3 1 2 2 3 3
3 5 1 2 1 4
3 3 4 5 4 6
Example Output1：
2 5 21 14 18

Example Input2：
6 3
1 5 1
5 5 1
5 1 2 2 100 3 100 6 1 4
5 1 100 2 4 3 100 5 1 4
2 3 1 5
Example Output2：
2 31 43 37 136


## Solution


import sys
import heapq

def read_ints():
    return map(int, sys.stdin.readline().split())

def main():
    n, k = read_ints()
    a = list(read_ints())
    b = list(read_ints())
    graph = [[] for _ in range(n + 1)]
    lines = [[] for _ in range(k + 1)]

    for i in range(1, k + 1):
        p, *values = read_ints()
        values = list(values)
        x_prev = 0
        for j in range(p):
            x = values[2 * j]
            if j > 0:
                w = values[2 * j - 1]
                lines[i].append((x, w))
                graph[x_prev].append((x, w, i))
            x_prev = x

    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    queue = [(0, 1, 0)]

    while queue:
        d, u, line = heapq.heappop(queue)
        if d > dist[u]:
            continue
        for v, w, line2 in graph[u]:
            if line2 == line:
                if dist[v] > dist[u] + w:
                    dist[v] = dist[u] + w
                    heapq.heappush(queue, (dist[v], v, line2))
            for i in range(1, k + 1):
                if (v, 0) in lines[i]:
                    if dist[v] > dist[u] + w + a[i - 1] * b[line - 1]:
                        dist[v] = dist[u] + w + a[i - 1] * b[line - 1]
                        heapq.heappush(queue, (dist[v], v, i))

    print(' '.join(map(str, dist[2:])))

if __name__ == "__main__":
    main()



## CODE


import sys
import heapq

def read_ints():
    return map(int, sys.stdin.readline().split())

def main():
    n, k = read_ints()
    a = list(read_ints())
    b = list(read_ints())
    graph = [[] for _ in range(n + 1)]
    lines = [[] for _ in range(k + 1)]

    for i in range(1, k + 1):
        p, *values = read_ints()
        values = list(values)
        x_prev = 0
        for j in range(p):
            x = values[2 * j]
            if j > 0:
                w = values[2 * j - 1]
                lines[i].append((x, w))
                graph[x_prev].append((x, w, i))
            x_prev = x

    dist = [float('inf')] * (n + 1)
    dist[1] = 0
    queue = [(0, 1, 0)]

    while queue:
        d, u, line = heapq.heappop(queue)
        if d > dist[u]:
            continue
        for v, w, line2 in graph[u]:
            if line2 == line:
                if dist[v] > dist[u] + w:
                    dist[v] = dist[u] + w
                    heapq.heappush(queue, (dist[v], v, line2))
            for i in range(1, k + 1):
                if (v, 0) in lines[i]:
                    if dist[v] > dist[u] + w + a[i - 1] * b[line - 1]:
                        dist[v] = dist[u] + w + a[i - 1] * b[line - 1]
                        heapq.heappush(queue, (dist[v], v, i))

    print(' '.join(map(str, dist[2:])))

if __name__ == "__main__":
    main()


### Explanation
This code solves the problem using Dijkstra's algorithm with a priority queue. The graph is represented as an adjacency list, where each node is associated with a list of its neighbors and the corresponding edge weights. The lines are also represented as lists of nodes and weights.

The algorithm starts by initializing the distance to the starting node (1) to 0 and the distances to all other nodes to infinity. It then pushes the starting node into the priority queue.

In each iteration, the alliances with the smallest distance is popped from the queue and its neighbors are updated if a shorter path is found. The update process takes into account the transfer time between lines.

Finally, the algorithm prints the minimum distances to all nodes except the starting node.
## Token
[570, 1022, 1592]
 ### 

## Question


(G)
Given a binary tree with $n$ vertices, your task is to find a special vertex $s$ in the tree with at most $p = \lfloor \log_2 n \rfloor$ queries. That is to say, $p$ is the largest integer such that $2^p \le n$.

Each query consists of two different vertices $u$ and $v$. The interactor will output an integer $t$ ($0 \le t \le 2$) as the answer. Let $d(a, b)$ be the number of edges on the simple path from vertex $a$ to vertex $b$.

-   If $t = 0$, then vertex $u$ is nearer to the special vertex. That is, $d(u, s) &lt; d(v, s)$.
-   If $t = 1$, then the distances from $u$ and $v$ to the special vertex are the same. That is, $d(u, s) = d(v, s)$.
-   If $t = 2$, then vertex $v$ is nearer to the special vertex. That is, $d(u, s) &gt; d(v, s)$.

Note that the interactor is adaptive, meaning that the answer for each test case is not pre-determined. The interactor can determine the special vertex according to your queries, as long as its answer does not conflict with the previous queries and answers.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains an integer $n$ ($2 \le n \le 10^5$) indicating the number of vertices in the binary tree.

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($0 \le x_i, y_i \le n$), indicating the left and right child of the $i$\-th vertex. If $x_i = 0$, then the $i$\-th vertex has no left child; if $y_i = 0$, then the $i$\-th vertex has no right child.

It is guaranteed that the sum of $n$ for all test cases will not exceed $2 \times 10^5$.

**Interaction**

To ask a query, output one line. First output ? followed by a space, then print two different integers $u$ and $v$ ($1 \le u, v \le n$) separated by a space. After flushing your output, your program should read a single integer $t$ indicating the answer to your query.

If you want to guess the special vertex, output one line. First output ! followed by a space, then print an integer $s$ ($1 \le s \le n$) indicating the special vertex. After flushing your output, your program should continue processing the next test case, or exit immediately if there are no more test cases. Note that your guess does not count as a query.

To flush your output, you can use:

-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java.
-   stdout.flush() in Python.

Example Input1：
2
5
0 0
1 5
2 4
0 0
0 0

1

0

2
0 2
0 0

2
Example Output1：







? 5 1

? 1 4

! 2



? 2 1

! 1


## Solution


import sys
import math

def query(u, v):
    print(f"? {u} {v}", flush=True)
    return int(input())

def guess(s):
    print(f"! {s}", flush=True)

def find_special_vertex(n, edges):
    max_depth = math.floor(math.log2(n))
    root = 1

    for _ in range(max_depth):
        left_child = edges[root - 1][0]
        right_child = edges[root - 1][1]

        if left_child == 0:
            root = right_child
        elif right_child == 0:
            root = left_child
        else:
            result = query(left_child, right_child)
            if result == 0:
                root = left_child
            elif result == 2:
                root = right_child
            else:
                # If the distances are the same, we can choose either child
                root = left_child

    guess(root)

def main():
    t = int(input())
    for _ in range(t):
        n = int(input())
        edges = []
        for _ in range(n):
            x, y = map(int, input().split())
            edges.append((x, y))
        find_special_vertex(n, edges)

if __name__ == "__main__":
    main()



## CODE


import sys
import math

def query(u, v):
    print(f"? {u} {v}", flush=True)
    return int(input())

def guess(s):
    print(f"! {s}", flush=True)

def find_special_vertex(n, edges):
    max_depth = math.floor(math.log2(n))
    root = 1

    for _ in range(max_depth):
        left_child = edges[root - 1][0]
        right_child = edges[root - 1][1]

        if left_child == 0:
            root = right_child
        elif right_child == 0:
            root = left_child
        else:
            result = query(left_child, right_child)
            if result == 0:
                root = left_child
            elif result == 2:
                root = right_child
            else:
                # If the distances are the same, we can choose either child
                root = left_child

    guess(root)

def main():
    t = int(input())
    for _ in range(t):
        n = int(input())
        edges = []
        for _ in range(n):
            x, y = map(int, input().split())
            edges.append((x, y))
        find_special_vertex(n, edges)

if __name__ == "__main__":
    main()


### Explanation
The provided code implements a solution to the problem of finding a special vertex in a binary tree using at most p = floor(log2(n)) queries.

The approach used is to start at the root of the tree and iteratively move down the tree, choosing the child node that is closer to the special vertex. This is done by querying the left and right child nodes and moving to the node that is closer to the special vertex based on the query result.

The process is repeated until the maximum allowed depth (p) is reached, at which point the current node is guessed as the special vertex.

The code uses a recursive approach to handle the tree traversal and query process, with the `find_special_vertex` function implementing the main logic. The `query` and `guess` functions handle the interaction with the interactor, printing the query or guess to the output and flushing it to ensure immediate processing.
## Token
[462, 870, 1332]
 ### 

## Question


(I)
Given two integers $n$, $m$ and an integer sequence $a_1, a_2, \cdots, a_{nm}$ of length $n \times m$, we're going to fill a grid of $n$ rows and $m$ columns with the integers from the sequence. More specifically, let $(i, j)$ be the cell on the $i$\-th row and the $j$\-th column, we'll put the $((i - 1) \times m + j)$\-th element of the sequence (that is, $a_{(i - 1) \times m + j}$) into that cell.

We say an integer $k$ is a "bingo integer" of the sequence, if after filling all the cells, at least one of the two following conditions is satisfied.

-   There is at least one row, where all integers in the cells of that row are less than or equal to $k$.
-   There is at least one column, where all integers in the cells of that column are less than or equal to $k$.

It is easy to see that a sequence may have multiple bingo integers, however in this problem, we're only interested in the smallest bingo integer.

Calculate the sum of the smallest bingo integers for all $(nm)!$ permutations of the given sequence. As the answer may be large, output the answer modulo $998\,244\,353$.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains two integers $n$ and $m$ ($1 \le n, m \le 2 \times 10^5$, $1 \le n \times m \le 2 \times 10^5$), indicating the number of rows and columns of the grid.

The second line contains $n \times m$ integers $a_1, a_2, \cdots, a_{nm}$ ($0 \le a_i &lt; 998\,244\,353$) indicating the given sequence.

It's guaranteed that the sum of $n \times m$ of all test cases will not exceed $4 \times 10^5$.

**Output**

For each test case, output one line containing one integer indicating the answer.

Example Input1：
2 2
1 3 2 4
Example Output1：
56

Example Input2：
3 1
10 10 10
Example Output2：
60

Example Input3：
1 3
20 10 30
Example Output3：
60

Example Input4：
3 4
1 1 4 5 1 4 1 9 1 9 8 10
Example Output4：
855346687

**Note**

For the first sample test case, if $1$ and $2$ are not on the same row or column, then the smallest bingo integer will be $3$, otherwise the smallest bingo integer will be $2$. There are $8$ permutations where $1$ and $2$ are not on the same row or column, so the answer is $8 \times 3 + (4! - 8) \times 2 = 56$.

For the second sample test case, the smallest bingo integer is always $10$, so the answer is $3! \times 10 = 60$.


## Solution


import sys
input = sys.stdin.readline

MOD = 998244353

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = (res * a) % MOD
        a = (a * a) % MOD
        b >>= 1
    return res

def init(n):
    fac = [1] * (n + 1)
    inv = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = (fac[i - 1] * i) % MOD
    inv[n] = qpow(fac[n], MOD - 2)
    for i in range(n - 1, 0, -1):
        inv[i] = (inv[i + 1] * (i + 1)) % MOD
    return fac, inv

def C(n, m, fac, inv):
    if n < m:
        return 0
    return ((fac[n] * inv[m]) % MOD * inv[n - m]) % MOD

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    fac, inv = init(n * m)
    ans = 0
    for i in range(n * m):
        res = ((fac[i] * fac[n * m - i - 1]) % MOD * C(n + m - 1, n, fac, inv)) % MOD
        for j in range(n):
            if i - j * m < 0:
                break
            res = (res - ((fac[n - 1] * fac[m - 1]) % MOD * fac[j * m + n - 1] % MOD * fac[i - j * m] % MOD * inv[i - j * m + n - 1] % MOD * inv[n * m - i - 1] % MOD * C(m - 1, i - j * m, fac, inv)) % MOD) % MOD
        for j in range(m):
            if i - j * n < 0:
                break
            res = (res - ((fac[m - 1] * fac[n - 1]) % MOD * fac[j * n + m - 1] % MOD * fac[i - j * n] % MOD * inv[i - j * n + m - 1] % MOD * inv[n * m - i - 1] % MOD * C(n - 1, i - j * n, fac, inv)) % MOD) % MOD
        ans = (ans + (res * a[i]) % MOD) % MOD
    print(ans)

T = int(input())
for _ in range(T):
    solve()


## CODE


import sys
input = sys.stdin.readline

MOD = 998244353

def qpow(a, b):
    res = 1
    while b:
        if b & 1:
            res = (res * a) % MOD
        a = (a * a) % MOD
        b >>= 1
    return res

def init(n):
    fac = [1] * (n + 1)
    inv = [1] * (n + 1)
    for i in range(1, n + 1):
        fac[i] = (fac[i - 1] * i) % MOD
    inv[n] = qpow(fac[n], MOD - 2)
    for i in range(n - 1, 0, -1):
        inv[i] = (inv[i + 1] * (i + 1)) % MOD
    return fac, inv

def C(n, m, fac, inv):
    if n < m:
        return 0
    return ((fac[n] * inv[m]) % MOD * inv[n - m]) % MOD

def solve():
    n, m = map(int, input().split())
    a = list(map(int, input().split()))
    a.sort()
    fac, inv = init(n * m)
    ans = 0
    for i in range(n * m):
        res = ((fac[i] * fac[n * m - i - 1]) % MOD * C(n + m - 1, n, fac, inv)) % MOD
        for j in range(n):
            if i - j * m < 0:
                break
            res = (res - ((fac[n - 1] * fac[m - 1]) % MOD * fac[j * m + n - 1] % MOD * fac[i - j * m] % MOD * inv[i - j * m + n - 1] % MOD * inv[n * m - i - 1] % MOD * C(m - 1, i - j * m, fac, inv)) % MOD) % MOD
        for j in range(m):
            if i - j * n < 0:
                break
            res = (res - ((fac[m - 1] * fac[n - 1]) % MOD * fac[j * n + m - 1] % MOD * fac[i - j * n] % MOD * inv[i - j * n + m - 1] % MOD * inv[n * m - i - 1] % MOD * C(n - 1, i - j * n, fac, inv)) % MOD) % MOD
        ans = (ans + (res * a[i]) % MOD) % MOD
    print(ans)

T = int(input())
for _ in range(T):
    solve()

### Explanation
The problem can be solved using combinatorics and modular arithmetic. We first sort the given sequence in ascending order. Then, for each number in the sequence, we calculate the number of permutations where this number is the smallest bingo integer. We use the formula for combinations and permutations to calculate this number. We also use modular arithmetic to avoid overflow. Finally, we multiply the number of permutations by the number itself and add it to the answer. We repeat this process for all numbers in the sequence and output the final answer.
## Token
[715, 828, 1543]
 ### 

## Question


(J)
On a social media platform, users can leave comments under others' posts to express their thoughts. However, these comments are not visible to everyone. Specifically, for user $C$ to see user $A$'s comments under user $B$'s post, he/she has to be friends with both $A$ and $B$ at the same time. If a user leaves a comment under his/her own post, all his/her friends can see this comment.

As an active user on this platform, you would like to see as many comments as possible. There are $k$ users (not counting you) on the platform, numbered from $1$ to $k$. There are also $m$ comments on the platform, but you might not be able to see them all because you only have $n$ friends. As you need to participate in the 2024 ICPC Asia Nanjing Regional Contest, you don't have time to make too many new friends. What's the maximum number of comments you can see if you make at most two new friends on the platform?

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains three integers $n$, $m$, and $k$ ($1 \le n \le k \le 2 \times 10^5$, $1 \le m \le 2 \times 10^5$) indicating the number of your friends, the number of comments, and the number of users (not counting you) on the platform.

The second line contains $n$ distinct integers $f_1, f_2, \cdots, f_n$ ($1 \le f_i \le k$) indicating your friends on the platform.

For the following $m$ lines, the $i$\-th line contains two integers $a_i$ and $b_i$ ($1 \le a_i, b_i \le k$) indicating a comment written by user $a_i$ under user $b_i$'s post.

It's guaranteed that neither the sum of $k$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case, output one line containing one integer, indicating the maximum number of comments you can see if you make at most two new friends on the platform.

Example Input1：
4 12 7
5 7 3 6
3 6
2 2
1 4
2 4
1 3
7 6
4 1
5 4
1 1
1 1
2 1
3 7
Example Output1：
9

Example Input2：
2 7 6
2 4
1 2
3 2
2 5
5 4
2 6
4 6
2 6
Example Output2：
5

Example Input3：
1 1 2
1
1 2
Example Output3：
1

Example Input4：
2 1 2
1 2
1 2
Example Output4：
1

Example Input5：
2 1 100
24 11
11 24
Example Output5：
1

**Note**

For the first sample test case, you can make friends with user $1$ and $4$.

For the second sample test case, you can make friends with user $5$ and $6$.

For the third sample test case, you can make friends with user $2$.

For the fourth and fifth sample test cases, you don't need to make new friends because you can already see all comments.


## Solution


import sys
from collections import defaultdict

def solve(n, m, k, friends, comments):
    friend_set = set(friends)
    graph = defaultdict(list)
    for u, v in comments:
        graph[u].append(v)
        graph[v].append(u)

    count = 0
    for u, v in comments:
        if u in friend_set and v in friend_set:
            count += 1

    max_count = count
    for i in range(1, k+1):
        if i not in friend_set:
            tmp_count = count
            for j in graph[i]:
                if j in friend_set:
                    tmp_count += sum(1 for x in graph[j] if x == i or x in friend_set)
            max_count = max(max_count, tmp_count)

    for i in range(1, k+1):
        if i not in friend_set:
            for j in graph[i]:
                if j not in friend_set and i < j:
                    tmp_count = count
                    for x in graph[i]:
                        if x in friend_set:
                            tmp_count += sum(1 for y in graph[x] if y == i or y == j or y in friend_set)
                    for x in graph[j]:
                        if x in friend_set:
                            tmp_count += sum(1 for y in graph[x] if y == i or y == j or y in friend_set)
                    if i in graph[j]:
                        tmp_count += 1
                    max_count = max(max_count, tmp_count)

    return max_count

t = int(input())
for _ in range(t):
    n, m, k = map(int, input().split())
    friends = list(map(int, input().split()))
    comments = [tuple(map(int, input().split())) for _ in range(m)]
    print(solve(n, m, k, friends, comments))



## CODE


import sys
from collections import defaultdict

def solve(n, m, k, friends, comments):
    friend_set = set(friends)
    graph = defaultdict(list)
    for u, v in comments:
        graph[u].append(v)
        graph[v].append(u)

    count = 0
    for u, v in comments:
        if u in friend_set and v in friend_set:
            count += 1

    max_count = count
    for i in range(1, k+1):
        if i not in friend_set:
            tmp_count = count
            for j in graph[i]:
                if j in friend_set:
                    tmp_count += sum(1 for x in graph[j] if x == i or x in friend_set)
            max_count = max(max_count, tmp_count)

    for i in range(1, k+1):
        if i not in friend_set:
            for j in graph[i]:
                if j not in friend_set and i < j:
                    tmp_count = count
                    for x in graph[i]:
                        if x in friend_set:
                            tmp_count += sum(1 for y in graph[x] if y == i or y == j or y in friend_set)
                    for x in graph[j]:
                        if x in friend_set:
                            tmp_count += sum(1 for y in graph[x] if y == i or y == j or y in friend_set)
                    if i in graph[j]:
                        tmp_count += 1
                    max_count = max(max_count, tmp_count)

    return max_count

t = int(input())
for _ in range(t):
    n, m, k = map(int, input().split())
    friends = list(map(int, input().split()))
    comments = [tuple(map(int, input().split())) for _ in range(m)]
    print(solve(n, m, k, friends, comments))


### Explanation
This solution works by first initializing a graph and a set of friends. It then counts the number of comments that can be seen by the user without making any new friends. 

Next, it iterates over all users who are not friends with the user and calculates the number of additional comments that can be seen if the user befriends this person. 

Finally, it iterates over all pairs of users who are not friends with the user and calculates the number of additional comments that can be seen if the user befriends both of these people. 

The maximum number of comments that can be seen is then returned. 

This solution has a time complexity of O(t * (m + k^2)) and a space complexity of O(m + k), where t is the number of test cases, m is the number of comments, and k is the number of users.
## Token
[580, 888, 1468]
 ### 

## Question


(K)
There are $w$ cells arranged in a row, numbered from $1$ to $w$ from left to right. Among the cells, $n$ of them are red, $m$ of them are black, and the remaining $(w - n - m)$ cells are white.

You need to cover all the red cells with some strips. Each strip must cover $k$ continuous cells. Find a way to cover all red cells while satisfying all the following constraints:

-   Each red cell is covered by a strip.
-   No black cell is covered by a strip.
-   No two strips cover the same cell. That is, each cell is covered by at most one strip.
-   The number of strips used is as small as possible.

**Input**

There are multiple test cases. The first line of the input contains an integer $T$ indicating the number of test cases. For each test case:

The first line contains four integers $n$, $m$, $k$ and $w$ ($1 \le n, m \le 10^5$, $1 \le k \le w \le 10^9$, $n + m \le w$), indicating the number of red cells, the number of black cells, the length of each strip and the total number of cells.

The second line contains $n$ integers $a_1, a_2, \cdots, a_n$ ($1 \le a_i \le w$), indicating that cell $a_i$ is red.

The third line contains $m$ integers $b_1, b_2, \cdots, b_m$ ($1 \le b_i \le w$), indicating that cell $b_i$ is black.

It's guaranteed that the given $(n + m)$ cells are distinct. It's also guaranteed that neither the sum of $n$ nor the sum of $m$ of all test cases will exceed $2 \times 10^5$.

**Output**

For each test case:

If it is possible to cover all the red cells while satisfying all constraints, first output one line containing one integer $c$ indicating the smallest number of strips used. Then output another line containing $c$ integers $l_1, l_2, \cdots, l_c$ ($1 \le l_i \le w - k + 1$) separated by a space, where $l_i$ is the left-most cell covered by the $i$\-th strip. If there are multiple valid answers, you can output any of them.

If it is not possible to do so, just output \-1 in one line.

Example Input1：
5 2 3 16
7 11 2 9 14
13 5
Example Output1：
4
6 2 14 9

Example Input2：
3 2 4 11
6 10 2
1 11
Example Output2：
-1

Example Input3：
2 1 2 6
1 5
3
Example Output3：
2
1 4

Example Input4：
2 1 2 6
1 5
2
Example Output4：
-1


## Solution


def min_strips(n, m, k, w, red, black):
    black_set = set(black)
    red.sort()
    strips = []
    i = 0
    while i < n:
        start = red[i]
        while i < n and red[i] < start + k:
            i += 1
        if any(j in black_set for j in range(start, start + k)):
            return -1
        strips.append(start)
    return len(strips), strips

T = int(input())
for _ in range(T):
    n, m, k, w = map(int, input().split())
    red = list(map(int, input().split()))
    black = list(map(int, input().split()))
    res, strips = min_strips(n, m, k, w, red, black)
    if res == -1:
        print(-1)
    else:
        print(res)
        print(*strips)



## CODE


def min_strips(n, m, k, w, red, black):
    black_set = set(black)
    red.sort()
    strips = []
    i = 0
    while i < n:
        start = red[i]
        while i < n and red[i] < start + k:
            i += 1
        if any(j in black_set for j in range(start, start + k)):
            return -1
        strips.append(start)
    return len(strips), strips

T = int(input())
for _ in range(T):
    n, m, k, w = map(int, input().split())
    red = list(map(int, input().split()))
    black = list(map(int, input().split()))
    res, strips = min_strips(n, m, k, w, red, black)
    if res == -1:
        print(-1)
    else:
        print(res)
        print(*strips)


### Explanation
This solution works by iterating through the sorted list of red cells and trying to cover as many red cells as possible with each strip. If a black cell is found within the range of a strip, it returns -1 as it's impossible to cover the red cells without covering the black cell. The start position of each strip is stored and returned as the result. The time complexity is O(n log n) due to the sorting of the red cells.
## Token
[302, 771, 1073]
 ### 

## Question


(M)
Neuvillette is the Chief Justice of Fontaine, known as the Iudex, and he is renowned for his unassailable impartiality. As a playable character in the world-famous game Genshin Impact, he is known for his powerful charged attack that can hit enemies within a specific range.

Since he is very powerful, many players use him while challenging almost every quest. However, not everybody in Teyvat is happy about this, especially other ADC (Attack Damage Carry) characters, including Kamisato Ayaka, Keqing, etc. Together, they decide to persuade Mihoyo to nerf Neuvillette in the game. To do so, they must submit a report about Neuvillette's total damage in several scenarios.

Created from Genshin Impact official material

Each battle scenario happens on a two-dimensional plane. Neuvillette stands on $(0,0)$ facing $(x_0, y_0)$ initially, making a charged attack which lasts for $t$ units of time, and rotates $1$ rad counter-clockwise per unit of time. That is to say, Neuvillette turns a circle counter-clockwise in $2 \pi$ units of time.

Consider a ray from $(0,0)$ towards the direction Neuvillette faces. The attack range is the set of points whose distance to the ray is at most $d$. If the target, whose shape is a convex polygon, has common points with the attack range, it will suffer $1$ continued damage per unit of time.

As an experienced programmer, you are summoned by Ayaka. This time, your task is to calculate the damage the target incurs in the first $t$ units of time.

**Input**

There is only one test case in each test file.

The first line contains five integers $n$, $x_0$, $y_0$, $d$, and $t$ ($3 \le n \le 100$, $-10^4 \le x_0, y_0 \le 10^4$, $x_0^2 + y_0^2 &gt; 0$, $1 \le d, t \le 10^4$).

For the following $n$ lines, the $i$\-th line contains two integers $x_i$ and $y_i$ ($-10^4 \le x_i, y_i \le 10^4$), indicating the coordinates of the $i$\-th vertex of the convex polygon.

All $n$ vertices are given in counter-clockwise order, and any three of them are not collinear. It is also guaranteed that the shape has no common points with the circle centered at $(0,0)$ with radius $d$. That is to say, there does not exist a point inside or on the boundary of the convex polygon, while at the same time inside or on the boundary of the circle.

**Output**

Output one line containing one real number, indicating the damage the target incurs in the first $t$ units of time.

Your answer will be considered correct if its absolute or relative error does not exceed $10^{-6}$. Formally speaking, suppose that your output is $a$ and the jury's answer is $b$, your output is accepted if and only if $\frac{|a - b|}{\max(1, |b|)} \le 10^{-6}$.

Example Input1：
3 1 0 1 1
1 2
2 1
2 2
Example Output1：
1.000000000000

Example Input2：
3 1 0 1 2
1 2
2 1
2 2
Example Output2：
1.570796326795

Example Input3：
3 1 0 1 10000
1 2
2 1
2 2
Example Output3：
2500.707752257475
## Solution


import math

def calculate_damage(n, x0, y0, d, t, polygon):
    def distance(p1, p2):
        return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

    def is_inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0

    def get_intersection(p1, p2, a1, a2):
        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = a1
        x4, y4 = a2
        denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if denom == 0:
            return None
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
        if 0 <= t <= 1 and u >= 0:
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
        return None

    def get_angle(p):
        return math.atan2(p[1], p[0])

    damage = 0
    angle = get_angle((x0, y0))
    for i in range(n):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % n]
        a1 = (p1[0] - d * (p2[1] - p1[1]) / distance(p1, p2), p1[1] + d * (p2[0] - p1[0]) / distance(p1, p2))
        a2 = (p2[0] - d * (p2[1] - p1[1]) / distance(p1, p2), p2[1] + d * (p2[0] - p1[0]) / distance(p1, p2))
        intersection1 = get_intersection((0, 0), (math.cos(angle) * 10000, math.sin(angle) * 10000), a1, a2)
        intersection2 = get_intersection((0, 0), (math.cos(angle + math.pi / 2) * 10000, math.sin(angle + math.pi / 2) * 10000), a1, a2)
        if intersection1 and is_inside(intersection1, p1, p2):
            damage += t
            break
        if intersection2 and is_inside(intersection2, p1, p2):
            start_angle = get_angle(intersection2)
            end_angle = get_angle(intersection1) if intersection1 else angle + math.pi * 2
            damage += (end_angle - start_angle) / (2 * math.pi) * t
    return damage

n, x0, y0, d, t = map(float, input().split())
polygon = [tuple(map(float, input().split())) for _ in range(int(n))]
print(calculate_damage(n, x0, y0, d, t, polygon))



## CODE


import math

def calculate_damage(n, x0, y0, d, t, polygon):
    def distance(p1, p2):
        return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

    def is_inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0

    def get_intersection(p1, p2, a1, a2):
        x1, y1 = p1
        x2, y2 = p2
        x3, y3 = a1
        x4, y4 = a2
        denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if denom == 0:
            return None
        t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
        u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
        if 0 <= t <= 1 and u >= 0:
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
        return None

    def get_angle(p):
        return math.atan2(p[1], p[0])

    damage = 0
    angle = get_angle((x0, y0))
    for i in range(n):
        p1 = polygon[i]
        p2 = polygon[(i + 1) % n]
        a1 = (p1[0] - d * (p2[1] - p1[1]) / distance(p1, p2), p1[1] + d * (p2[0] - p1[0]) / distance(p1, p2))
        a2 = (p2[0] - d * (p2[1] - p1[1]) / distance(p1, p2), p2[1] + d * (p2[0] - p1[0]) / distance(p1, p2))
        intersection1 = get_intersection((0, 0), (math.cos(angle) * 10000, math.sin(angle) * 10000), a1, a2)
        intersection2 = get_intersection((0, 0), (math.cos(angle + math.pi / 2) * 10000, math.sin(angle + math.pi / 2) * 10000), a1, a2)
        if intersection1 and is_inside(intersection1, p1, p2):
            damage += t
            break
        if intersection2 and is_inside(intersection2, p1, p2):
            start_angle = get_angle(intersection2)
            end_angle = get_angle(intersection1) if intersection1 else angle + math.pi * 2
            damage += (end_angle - start_angle) / (2 * math.pi) * t
    return damage

n, x0, y0, d, t = map(float, input().split())
polygon = [tuple(map(float, input().split())) for _ in range(int(n))]
print(calculate_damage(n, x0, y0, d, t, polygon))


### Explanation
This solution uses geometric calculations to determine the damage incurred by the target. It first calculates the intersection points of the attack range with the edges of the polygon. If the intersection point is inside the polygon, it calculates the angle of the intersection point with respect to the initial direction of Neuvillette. The damage is then calculated based on the angle and the time of the attack. If there are multiple intersection points, it calculates the damage for each intersection point and adds them up. The solution assumes that the polygon is convex and that the attack range is a circular sector.
## Token
[895, 923, 1818]
 ### 

