## Question
(A)
Given three positive integers $p_A,p_B,p_C$, Bobo challenges you to find out three infinite binary strings $A,B,C$ with period $p_A$, $p_B$ and $p_C$ respectively satisfying $A \oplus B = C$, or determine it is impossible to do so.
Please refer to the Note section for the formal definition of period and exclusive or.
**Input**
The first line of the input contains a single integer $T$ ($1 \le T \le 10^4$), denoting the number of test cases. The description of the test cases follows.
The first and the only line of each test case contains three integers $p_A$, $p_B$ and $p_C$ ($1 \le p_A,p_B,p_C \le 10^6$).
It is guaranteed that the sum of $\max(p_A,p_B,p_C)$ over all test cases does not exceed $10^6$.
**Output**
For each test case, output "NO" (without quotes) in one line if no solution exists. Otherwise, output "YES" (without quotes) in one line. Then, output three binary strings of length $p_A$, $p_B$ and $p_C$ in three lines, denoting the first $p_A$, $p_B$, $p_C$ character(s) of the infinite strings $A$, $B$, $C$ respectively.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input：
2 3 6
2 3 5
Example Output：
YES
01
011
001110
NO
**Note**
Let $s=s_1 s_2 s_3 \ldots$ and $t=t_1 t_2 t_3 \ldots$ be infinite binary strings.
The period of $s$ is the smallest positive integer $k$ satisfying $s_i = s_{i+k}$ for all $i \ge 1$.
The exclusive or of strings $s$ and $t$ is given by $s \oplus t$ satisfying $(s \oplus t)_i = s_i \oplus t_i$ for all $i \ge 1$.


## Solution


import math

def solve(pa, pb, pc):
    lcm = pa * pb // math.gcd(pa, pb)
    if pc != lcm:
        if lcm % pc == 0:
            print("YES")
            a = '1' + '0' * (pa - 1)
            b = '1' + '0' * (pb - 1)
            c = '1' + '0' * (lcm - 1)
            print(a)
            print(b)
            print(c[:pc])
        else:
            print("NO")
    else:
        print("YES")
        a = '1' + '0' * (pa - 1)
        b = '0' + '1' + '0' * (pb - 2)
        c = ''
        for i in range(pc):
            c += str((int(a[i % pa]) + int(b[i % pb])) % 2)
        print(a)
        print(b)
        print(c)

t = int(input())
for _ in range(t):
    pa, pb, pc = map(int, input().split())
    solve(pa, pb, pc)



## CODE


import math

def solve(pa, pb, pc):
    lcm = pa * pb // math.gcd(pa, pb)
    if pc != lcm:
        if lcm % pc == 0:
            print("YES")
            a = '1' + '0' * (pa - 1)
            b = '1' + '0' * (pb - 1)
            c = '1' + '0' * (lcm - 1)
            print(a)
            print(b)
            print(c[:pc])
        else:
            print("NO")
    else:
        print("YES")
        a = '1' + '0' * (pa - 1)
        b = '0' + '1' + '0' * (pb - 2)
        c = ''
        for i in range(pc):
            c += str((int(a[i % pa]) + int(b[i % pb])) % 2)
        print(a)
        print(b)
        print(c)

t = int(input())
for _ in range(t):
    pa, pb, pc = map(int, input().split())
    solve(pa, pb, pc)


### Explanation
The method used in this code is to first calculate the least common multiple (LCM) of `pa` and `pb`. If the LCM is not equal to `pc`, then we check if `pc` is a divisor of the LCM. If it is, then we can create strings `A`, `B`, and `C` with periods `pa`, `pb`, and `pc` respectively, such that `A xor B = C`. If `pc` is not a divisor of the LCM, then it is impossible to create such strings. If the LCM is equal to `pc`, then we can create strings `A`, `B`, and `C` with periods `pa`, `pb`, and `pc` respectively, such that `A xor B = C`. The strings `A` and `B` are created with a single '1' followed by '0's, and the string `C` is created by performing the XOR operation on `A` and `B`.
## Token
[464, 578, 1042]
 ### 

## Question


(B)
Bobo has been playing a puzzle called Rolling Stones, which takes place on an equilateral triangular board consisting of $n$ $(n\geq 2)$ rows and $n^2$ cells. Each cell on the board is labeled with a number from $1$ to $4$. Bobo also has a tetrahedral stone, with each face numbered from $1$ to $4$ (a tetrahedral dice), initially placed at the first cell in the first row of the board. The position of the stone is as follows: the face with the number $1$ is towards the left, the face with the number $2$ is towards the next row, the face with the number $3$ is towards the right, and the face with the number $4$ is on the bottom side.
The goal of the puzzle is to roll the stone to a target cell under the following rules:

- **Matching Numbers**: When the stone rests on a cell, the number on the cell must match the number on the stone's bottom face.
- **Single Visit**: Each cell can only be visited once throughout the journey, including the starting and target cells.
The stone rolls by tipping along an edge that touches the board, moving it to a neighboring cell. Given the board layout, the target cell, and the stone's initial orientation, Bobo wants to know: is it possible to reach the target cell following the rules? If possible, what is the minimum number of rolls required to reach the target?
The illustration for a solution of the first sample test is given as follows.
![]
**Input**
The first line contains an integer $n$ $(2\leq n\leq 100)$, denoting the size of the board.
Then $n$ lines follows, with the $i$\-th $(1\leq i\leq n)$ line containing $2i-1$ numbers $a_{i,1},a_{i,2},\dots,a_{i,2i-1}$, where each $1\leq a_{i,j}\leq 4$ indicates the number on the $j$\-th cell from left to right in the $i$\-th row. It is guaranteed that $a_{1,1}=4$.
Then another line follows, containing two integers $x,y$ $(2\leq x\leq n,1\leq y\leq 2x-1)$. Here, $(x,y)$ represents the target cell, located at the $y$\-th cell from left to right in the $x$\-th row.
**Output**
If there is no way to roll the stone to the target cell, output $-1$ in a line. Otherwise, output the minimum number of rolls to roll the stone to the target cell in a line.
Example Input：
3
4
3 2 3
4 3 2 1 3
3 1
Example Output：
6


## Solution


from collections import deque

def rolling_stones(n, grid, target):
    directions = [(0, -1), (1, 0), (0, 1), (-1, -1), (-1, 0), (-1, 1)]
    visited = [[[False]*4 for _ in range(2*i+1)] for i in range(n)]
    queue = deque([(0, 0, 3, 0)])  # row, col, orientation, steps

    while queue:
        row, col, orient, steps = queue.popleft()
        
        if row == target[0]-1 and col == target[1]-1:
            return steps

        for di, (dr, dc) in enumerate(directions):
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < 2*nr+1:
                n_orient = (orient + di) % 4
                if grid[nr][nc] == n_orient + 1 and not visited[nr][nc][n_orient]:
                    queue.append((nr, nc, n_orient, steps + 1))
                    visited[nr][nc][n_orient] = True

    return -1

n = int(input())
grid = [list(map(int, input().split())) for _ in range(n)]
target = list(map(int, input().split()))

print(rolling_stones(n, grid, target))



## CODE


from collections import deque

def rolling_stones(n, grid, target):
    directions = [(0, -1), (1, 0), (0, 1), (-1, -1), (-1, 0), (-1, 1)]
    visited = [[[False]*4 for _ in range(2*i+1)] for i in range(n)]
    queue = deque([(0, 0, 3, 0)])  # row, col, orientation, steps

    while queue:
        row, col, orient, steps = queue.popleft()
        
        if row == target[0]-1 and col == target[1]-1:
            return steps

        for di, (dr, dc) in enumerate(directions):
            nr, nc = row + dr, col + dc
            if 0 <= nr < n and 0 <= nc < 2*nr+1:
                n_orient = (orient + di) % 4
                if grid[nr][nc] == n_orient + 1 and not visited[nr][nc][n_orient]:
                    queue.append((nr, nc, n_orient, steps + 1))
                    visited[nr][nc][n_orient] = True

    return -1

n = int(input())
grid = [list(map(int, input().split())) for _ in range(n)]
target = list(map(int, input().split()))

print(rolling_stones(n, grid, target))


### Explanation
We use a breadth-first search (BFS) algorithm to explore all possible paths from the starting cell to the target cell. The BFS algorithm is implemented using a queue data structure, where each element in the queue represents a cell in the grid along with its orientation and the number of steps taken to reach it.

The algorithm iterates over the queue, popping an element, checking if it's the target cell, and if not, generating all possible next cells by rolling the stone in all six directions. For each next cell, it checks if the cell's value matches the stone's bottom face and if the cell has not been visited before with the same orientation. If both conditions are true, it adds the next cell to the queue and marks it as visited.

If the algorithm exhausts all possible paths without finding the target cell, it returns -1. Otherwise, it returns the minimum number of steps taken to reach the target cell.
## Token
[506, 714, 1220]
 ### 

## Question


(C)
Bobo is exploring a set of lattice points on a two-dimensional plane. Initially, the set of points is defined as $S = \{(0,0),(A,0),(0,B),(A,B)\}$. Bobo's goal is to include a specific lattice point $(X,Y)$ in $S$. To achieve the goal, Bobo may perform the following operation:
- Select two lattice points $P,Q \in S$ such that $\frac{P+Q}{2}$ is also a lattice point, and add $\frac{P+Q}{2}$ to $S$.
Your task is to help Bobo find a sequence of operations that minimizes the number of steps to achieve the goal or determine if it is impossible to do so.
**Input**
The first line of the input contains two integers $A$ and $B$ ($0 \le A,B \le 10^9$), describing the parameters of the initial lattice points.
The second line of the input contains two integers $X$ and $Y$ ($0 \le X \le A$, $0 \le Y \le B$), denoting the coordinates of the target lattice point.
**Output**
If it is impossible to achieve the goal, output $-1$ in one line. Otherwise, output a single integer $k$ ($0 \le k \le 10^5$) in one line, denoting the total number of operations to perform. Then $k$ lines follow. The $i$\-th line contains four integers $U_i,V_i,S_i,T_i$ ($0 \le U_i,V_i,S_i,T_i \le 10^9$), describing the lattice points $P=(U_i,V_i)$ and $Q=(S_i,T_i)$ chosen in the $i$\-th operation. If there exist multiple solutions, output any.
Example Input1：
2 2
1 1
Example Output1：
1
0 0 2 2
Example Input2：
8 8
5 0
Example Output2：
3
0 0 8 0
4 0 8 0
4 0 6 0
Example Input3：
8 6
7 3
Example Output3：
3
0 0 8 0
4 0 8 0
6 0 8 6


## Solution


import sys

def solve(A, B, X, Y):
    ans = []
    def add(x1, y1, x2, y2):
        ans.append((x1, y1, x2, y2))
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    def work(x, y):
        if x == 0 or y == 0:
            return
        if x == A or y == B:
            if x == A and y == B:
                add(0, 0, A, B)
            elif x == A:
                work(A, B)
                add(A, B, A, 0)
            else:
                work(A, B)
                add(A, B, 0, B)
            return
        if x % 2 == 1:
            work(x + 1, y)
            add(x + 1, y, x - 1, y)
        elif y % 2 == 1:
            work(x, y + 1)
            add(x, y + 1, x, y - 1)
        else:
            work(x // 2, y // 2)
            add(x // 2, y // 2, x // 2 + x, y // 2 + y)

    if X % 2 == 1 and Y % 2 == 1:
        print(-1)
        return
    elif X % 2 == 1:
        work(A, Y)
        add(A, Y, 0, Y)
        work(X + 1, Y)
        add(X + 1, Y, X - 1, Y)
    elif Y % 2 == 1:
        work(X, B)
        add(X, B, X, 0)
        work(X, Y + 1)
        add(X, Y + 1, X, Y - 1)
    else:
        work(X, Y)

    print(len(ans))
    for x1, y1, x2, y2 in ans:
        print(x1, y1, x2, y2)

A, B = map(int, sys.stdin.readline().split())
X, Y = map(int, sys.stdin.readline().split())
solve(A, B, X, Y)



## CODE


import sys

def solve(A, B, X, Y):
    ans = []
    def add(x1, y1, x2, y2):
        ans.append((x1, y1, x2, y2))
        return ((x1 + x2) // 2, (y1 + y2) // 2)

    def work(x, y):
        if x == 0 or y == 0:
            return
        if x == A or y == B:
            if x == A and y == B:
                add(0, 0, A, B)
            elif x == A:
                work(A, B)
                add(A, B, A, 0)
            else:
                work(A, B)
                add(A, B, 0, B)
            return
        if x % 2 == 1:
            work(x + 1, y)
            add(x + 1, y, x - 1, y)
        elif y % 2 == 1:
            work(x, y + 1)
            add(x, y + 1, x, y - 1)
        else:
            work(x // 2, y // 2)
            add(x // 2, y // 2, x // 2 + x, y // 2 + y)

    if X % 2 == 1 and Y % 2 == 1:
        print(-1)
        return
    elif X % 2 == 1:
        work(A, Y)
        add(A, Y, 0, Y)
        work(X + 1, Y)
        add(X + 1, Y, X - 1, Y)
    elif Y % 2 == 1:
        work(X, B)
        add(X, B, X, 0)
        work(X, Y + 1)
        add(X, Y + 1, X, Y - 1)
    else:
        work(X, Y)

    print(len(ans))
    for x1, y1, x2, y2 in ans:
        print(x1, y1, x2, y2)

A, B = map(int, sys.stdin.readline().split())
X, Y = map(int, sys.stdin.readline().split())
solve(A, B, X, Y)


### Explanation
This code uses a recursive approach to find the sequence of operations that minimizes the number of steps to achieve the goal. It starts by checking if the target point (X, Y) can be reached by adding two lattice points in S. If not, it tries to find a point (x, y) that is closest to (X, Y) and can be reached by adding two lattice points in S. Then it adds the point (x, y) to S and repeats the process until (X, Y) is reached. The sequence of operations is stored in the ans list and printed out at the end.
## Token
[630, 593, 1223]
 ### 

## Question


(F)
Bobo is trapped in an infinite time loop of a peculiar day! Each day consists of exactly $k$ hours, and every day, $n$ tasks arrive for Bobo to complete.
- The $i$\-th task of the day arrives at the beginning of the $a_i$\-th hour and requires $b_i$ hours of uninterrupted effort to finish.
- Bobo works diligently and always follows a disciplined approach: whenever there are unfinished tasks, 、textbf{Bobo works on the earliest received unfinished task}.
At the beginning of the first day, Bobo starts with no tasks.
Your mission is to help Bobo answer $q$ queries. For the $i$\-th query, you are given $x_i$, the day on which a task is received, and $y_i$, the index of the task received on that day. Your goal is to determine the exact day and hour when Bobo will complete the $y_i$\-th taskof day $x_i$.
**Input**
The first line contains three space-separated integers, which are $n$ ($1 \leq n \leq 10^5$), $k$ ($1 \leq k \leq 10^8$), and $q$ ($1 \leq q \leq 10^5$), respectively.
The next $n$ lines each contain two space-separated integers, where the $i$\-th line contains $a_i$ ($1 \leq a_i \leq k$) and $b_i$ ($1 \leq b_i \leq k$). It is guaranteed that $a_i$ is strictly monotonically increasing.
Then $q$ lines follow, each containing two space-separated integers, where the $i$\-th line contains $x_i$ ($1 \leq x_i \leq 5 \times 10^5$) and $y_i$ ($1 \leq y_i \leq n$).
**Output**
Output $q$ lines, where the $i$\-th line outputs two space-separated integers $d_i$ and $h_i$, indicating that the task for the $i$\-th query is completed at the $h_i$\-th hour on the $d_i$\-th day.
Example Input1:
2 5 6
1 1
4 3
1 1
1 2
2 1
2 2
3 1
3 2
Example Output1:
1 1
2 1
2 2
3 1
3 2
4 1
Example Input2:
3 10 5
2 4
3 1
10 7
2 2
7 1
4 3
5 2
28 3
Example Output2:
3 1
8 10
6 2
6 7
34 10


## Solution


import sys
import bisect

def read_ints():
    return map(int, sys.stdin.readline().strip().split())

n, k, q = read_ints()

tasks = []
for _ in range(n):
    a, b = read_ints()
    tasks.append((a, b))

def get_completion_time(x, y):
    day = x
    hour = 0
    task_idx = y - 1
    task_day = x
    while task_idx >= 0:
        task_a, task_b = tasks[task_idx]
        task_a += (task_day - 1) * k
        if hour < task_a:
            hour = task_a
        hour += task_b
        if hour > day * k:
            day += (hour - 1) // k
            hour = (hour - 1) % k + 1
        task_idx -= 1
    return day, hour

def get_completion_time_bisect(x, y):
    task_a, task_b = tasks[y - 1]
    base_day = x
    base_hour = task_a
    total_days = (base_hour + task_b - 1) // k
    base_day += total_days
    base_hour = (base_hour + task_b - 1) % k + 1
    if y == 1:
        return base_day, base_hour

    days = [0] * n
    hours = [0] * n
    for i in range(n - 1, 0, -1):
        task_a, task_b = tasks[i - 1]
        days[i - 1] = days[i]
        hours[i - 1] = hours[i]
        if hours[i - 1] < task_a:
            hours[i - 1] = task_a
        hours[i - 1] += task_b
        if hours[i - 1] > k:
            days[i - 1] += (hours[i - 1] - 1) // k
            hours[i - 1] = (hours[i - 1] - 1) % k + 1

    idx = bisect.bisect_left(days, total_days)
    if idx < y - 1:
        idx = y - 1
    day = base_day + days[idx]
    hour = hours[idx]
    if hour < base_hour:
        day += 1
    return day, hour

for _ in range(q):
    x, y = read_ints()
    day, hour = get_completion_time_bisect(x, y)
    print(day, hour)



## CODE


import sys
import bisect

def read_ints():
    return map(int, sys.stdin.readline().strip().split())

n, k, q = read_ints()

tasks = []
for _ in range(n):
    a, b = read_ints()
    tasks.append((a, b))

def get_completion_time(x, y):
    day = x
    hour = 0
    task_idx = y - 1
    task_day = x
    while task_idx >= 0:
        task_a, task_b = tasks[task_idx]
        task_a += (task_day - 1) * k
        if hour < task_a:
            hour = task_a
        hour += task_b
        if hour > day * k:
            day += (hour - 1) // k
            hour = (hour - 1) % k + 1
        task_idx -= 1
    return day, hour

def get_completion_time_bisect(x, y):
    task_a, task_b = tasks[y - 1]
    base_day = x
    base_hour = task_a
    total_days = (base_hour + task_b - 1) // k
    base_day += total_days
    base_hour = (base_hour + task_b - 1) % k + 1
    if y == 1:
        return base_day, base_hour

    days = [0] * n
    hours = [0] * n
    for i in range(n - 1, 0, -1):
        task_a, task_b = tasks[i - 1]
        days[i - 1] = days[i]
        hours[i - 1] = hours[i]
        if hours[i - 1] < task_a:
            hours[i - 1] = task_a
        hours[i - 1] += task_b
        if hours[i - 1] > k:
            days[i - 1] += (hours[i - 1] - 1) // k
            hours[i - 1] = (hours[i - 1] - 1) % k + 1

    idx = bisect.bisect_left(days, total_days)
    if idx < y - 1:
        idx = y - 1
    day = base_day + days[idx]
    hour = hours[idx]
    if hour < base_hour:
        day += 1
    return day, hour

for _ in range(q):
    x, y = read_ints()
    day, hour = get_completion_time_bisect(x, y)
    print(day, hour)


### Explanation
We use two methods to calculate the completion time of a task. The first method, `get_completion_time`, iterates through the tasks from the given task to the first task of the day, simulating the work process. The second method, `get_completion_time_bisect`, uses binary search to find the number of days and hours needed to complete the tasks before the given task. It then adds this to the base day and hour of the given task to get the completion time. This method is more efficient when the number of tasks is large.
## Token
[678, 706, 1384]
 ### 

## Question


(G)
Bobo is working with an integer sequence $a_1,a_2,\ldots,a_n$ of length $n$. He must process $q$ queries in order. Each query is of one of the following two types:
- 1 $L$ $R$ $v$ ($1 \le L \le R \le n$, $0 \le v \le 2 \cdot 10^5$): for all $i \in [L,R]$, update $a_i \gets a_i + v$;
- 2 $L$ $R$ ($1 \le L &lt; R \le n$, $R-L+1$ is even): determine if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum.
Your task is to help Bobo process these queries efficiently.
**Input**
The first line of input contains two integers $n$, $q$ ($1 \le n,q \le 2 \cdot 10^5$).
The second line of input contains $n$ integers $a_1, a_2, \ldots, a_n$ ($0 \le a_i \le 2 \cdot 10^5$).
Then $q$ lines follow. Each of the following lines contains a query, described in the statement.
**Output**
For each query of the second type, output "YES" (without quotes) in one line if elements $a_L, a_{L+1}, \ldots, a_R$ can be divided into $(R-L+1)/2$ pairs of integers with the same sum; otherwise, output "NO" (without quotes) in one line.
You can output "YES" and "NO" in any case (for example, strings "yES", "yes", and "Yes" will all be recognized as a positive response).
Example Input:
8 4
1 2 3 4 5 6 7 8
2 1 8
1 1 4 4
2 1 6
2 1 8
Example Output:
YES
NO
YES 


## Solution


import sys
input = sys.stdin.readline

class FenwickTree:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * n

    def sum(self, r):
        res = 0
        while r >= 0:
            res += self.bit[r]
            r = (r & (r + 1)) - 1
        return res

    def rsum(self, l, r):
        return self.sum(r) - self.sum(l - 1)

    def add(self, idx, delta):
        while idx < self.n:
            self.bit[idx] += delta
            idx = idx | (idx + 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    bit1 = FenwickTree(n + 1)
    bit2 = FenwickTree(n + 1)

    for i in range(n):
        bit1.add(i + 1, a[i])
        bit2.add(i + 1, a[i] * (i % 2 == 1 and -1 or 1))

    for _ in range(q):
        query = list(map(int, input().split()))
        if query[0] == 1:
            l, r, v = query[1:]
            bit1.add(l, v)
            bit1.add(r + 1, -v)
            bit2.add(l, v * (l % 2 == 1 and -1 or 1))
            bit2.add(r + 1, -v * (r % 2 == 1 and -1 or 1))
        else:
            l, r = query[1:]
            s1 = bit1.rsum(l, r)
            s2 = bit2.rsum(l, r)
            if (r - l + 1) % 2 == 0 and s2 == 0:
                print("YES")
            else:
                print("NO")

solve()



## CODE


import sys
input = sys.stdin.readline

class FenwickTree:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * n

    def sum(self, r):
        res = 0
        while r >= 0:
            res += self.bit[r]
            r = (r & (r + 1)) - 1
        return res

    def rsum(self, l, r):
        return self.sum(r) - self.sum(l - 1)

    def add(self, idx, delta):
        while idx < self.n:
            self.bit[idx] += delta
            idx = idx | (idx + 1)

def solve():
    n, q = map(int, input().split())
    a = list(map(int, input().split()))

    bit1 = FenwickTree(n + 1)
    bit2 = FenwickTree(n + 1)

    for i in range(n):
        bit1.add(i + 1, a[i])
        bit2.add(i + 1, a[i] * (i % 2 == 1 and -1 or 1))

    for _ in range(q):
        query = list(map(int, input().split()))
        if query[0] == 1:
            l, r, v = query[1:]
            bit1.add(l, v)
            bit1.add(r + 1, -v)
            bit2.add(l, v * (l % 2 == 1 and -1 or 1))
            bit2.add(r + 1, -v * (r % 2 == 1 and -1 or 1))
        else:
            l, r = query[1:]
            s1 = bit1.rsum(l, r)
            s2 = bit2.rsum(l, r)
            if (r - l + 1) % 2 == 0 and s2 == 0:
                print("YES")
            else:
                print("NO")

solve()


### Explanation
The code uses two Fenwick Trees, also known as Binary Indexed Trees, to keep track of the prefix sums of the array and the prefix sums of the array with alternating signs. The first Fenwick Tree, `bit1`, stores the prefix sums of the array, and the second Fenwick Tree, `bit2`, stores the prefix sums of the array with alternating signs.

When a query of type 1 is encountered, the code updates the corresponding ranges in both Fenwick Trees.

When a query of type 2 is encountered, the code calculates the sum of the elements in the range using `bit1` and the sum of the elements with alternating signs in the range using `bit2`. If the range has an even number of elements and the sum of the elements with alternating signs is 0, it means that the elements can be divided into pairs with the same sum, so the code prints "YES". Otherwise, it prints "NO".
## Token
[630, 556, 1186]
 ### 

## Question


(K)
Bobo is playing a game called **Brotato**. The game consists of $n$ levels, each of which he can either pass or fail. Each level has a probability $p$ of failure and a probability $1-p$ of passing. If Bobo fails a level, he must normally restart from the first level.

Bobo is quite frustrated about the fact that each time he dies, he has to start over from the very beginning. Therefore, Bobo decided to cheat. Now, Bobo has $k$ special items that allow him to continue from the same level after a failure rather than restarting from the beginning.

Given this setup, determine the minimum expected number of attempts for levels needed for Bobo to complete all $n$ levels.
**Input**

The first line contains two integers $n,k$ ($1 \le n\leq 10^5, 0 \le k\leq 10^9)$, denoting the number of levels and the number of items, respectively.

The second line contains a number $p$ $(0&lt;p\leq 0.5)$. It is guaranteed that $p$ has at most $4$ decimal places.

**It is guaranteed that $np\leq 20$.**
**Output**

Output a number in a line denoting the answer.

Your answer is considered correct if its absolute or relative error doesn't exceed $10^{-9}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $\frac{|b-a|}{\max(b,1)} \le 10^{-9}$.
Example Input1:
5 0
0.5
Example Output1:
62.0000000000
Example Input2:
5 1
0.5
Example Output2:
47.0000000000
Example Input3：
10000 0
0.002
Example Output3：
247489700298.2536834329
Example Input4：
100000 10
0.0002
Example Output4：
38767507133.2322179824


## Solution


import sys

def calculate_expected_attempts(n, k, p):
    dp = [0] * (k + 1)
    dp[0] = 1 / (1 - p)

    for i in range(1, k + 1):
        dp[i] = (1 / (1 - p)) * (1 - (p ** (i + 1)))

    attempts = 0
    for i in range(n):
        if k > 0:
            attempts += dp[min(i, k)]
        else:
            attempts += dp[0]

    return attempts

n, k = map(int, input().split())
p = float(input())

result = calculate_expected_attempts(n, k, p)
print(f"{result:.12f}")



## CODE


import sys

def calculate_expected_attempts(n, k, p):
    dp = [0] * (k + 1)
    dp[0] = 1 / (1 - p)

    for i in range(1, k + 1):
        dp[i] = (1 / (1 - p)) * (1 - (p ** (i + 1)))

    attempts = 0
    for i in range(n):
        if k > 0:
            attempts += dp[min(i, k)]
        else:
            attempts += dp[0]

    return attempts

n, k = map(int, input().split())
p = float(input())

result = calculate_expected_attempts(n, k, p)
print(f"{result:.12f}")


### Explanation
The code uses dynamic programming to calculate the expected number of attempts for each level. The `dp` array stores the expected number of attempts for each number of items from 0 to `k`. The `dp[0]` is initialized to `1 / (1 - p)`, which is the expected number of attempts when there are no items.

Then, for each number of items from 1 to `k`, the `dp[i]` is calculated as `(1 / (1 - p)) * (1 - (p ** (i + 1)))`, which is the expected number of attempts when there are `i` items.

Finally, the total expected number of attempts is calculated by summing up the expected number of attempts for each level. If there are items left, the expected number of attempts for each level is `dp[min(i, k)]`, otherwise it is `dp[0]`. The result is printed with 12 decimal places.
## Token
[366, 538, 904]
 ### 

## Question


(L)
Welcome to the China Collegiate Programming Contest (CCPC) Zhengzhou onsite! Bobo has noticed that the initials of "Zheng" and "Zhou" are both Z. This motivates him to study the well-known Z-order curve.

To introduce the Z-order curve, we first introduce the Moser–de Bruijn sequence $(B_t)_{t \ge 0}$, the ordered sequence of numbers whose binary representation has nonzero digits only in the even positions. The first few terms of the Moser-de Bruijn sequence are $0, 1, 4, 5, 16, 17, 20, 21$.

Each non-negative integer $z$ can be uniquely decomposed into the sum of $B_x$ and $2B_y$. Therefore, we can write down all natural numbers in an infinitely large table. The Z-order curve is then obtained by connecting all the numbers in numerical order.

| ![](https://espresso.codeforces.com/3763e73d21e60b6c9037b14d5210dc6564fed8b9.png) |
| --- |
Illustration of Z-curve

Bobo now challenges you with the following problem: For a given fragment extracted from the Z-curve from $L$ to $R$, find the smallest integer $l$ such that the Z-curve from $l$ to $l+R-L$ is identical to the given fragment (i.e., the curve from $l$ to $l+R-L$ can be obtained by translating the curve from $L$ to $R$).

**Please note that in this problem, the curve is directed. Specifically, the curve from $1$ to $2$ is NOT identical to the curve from $3$ to $4$.**
**Input**

The first line of the input contains a single integer $T$ ($1 \le T \le 100$), denoting the number of test cases.

The first and only line of each test case contains two integers $L$ and $R$ ($0 \le L &lt; R \le 10^{18}$).
**Output**

For each test case, output the answer in one line.
Example Input1:
4
17 20
0 63
38 40
998244353998244353 998244853998244853
Example Output1:
1
0
6
2145186925057
**Note**

The following figure illustrates the Z-curve for the first and third test cases in the sample.

| ![](https://espresso.codeforces.com/709824a4ad98c5006c72824943a94018c45ea03d.png) |
| --- |
Illustration of test cases in the sample (red: test case 1, green: test case 3)


## Solution


def solve():
    l, r = map(int, input().split())
    x = r - l
    highest_bit = 1 << (x.bit_length() - 1)
    k = 0
    while highest_bit:
        k |= highest_bit & l
        highest_bit >>= 2
    print(k)

for _ in range(int(input())):
    solve()



## CODE


def solve():
    l, r = map(int, input().split())
    x = r - l
    highest_bit = 1 << (x.bit_length() - 1)
    k = 0
    while highest_bit:
        k |= highest_bit & l
        highest_bit >>= 2
    print(k)

for _ in range(int(input())):
    solve()


### Explanation
The code works by finding the highest bit that is set in the difference between `r` and `l`, then it creates a mask `k` where only the bits that are set in `l` at the positions corresponding to the highest bit set in `r - l` are set. This effectively finds the smallest integer `k` such that the Z-curve from `k` to `k + r - l` is identical to the Z-curve from `l` to `r`.
## Token
[193, 687, 880]
 ### 

## Question


(M)
Bobo wants to use a rejection sampling algorithm to construct a random set $T\subset \{1,2,\dots,n\}$ of size $k$. For parameters $p_1,p_2,...,p_n$ $(0\leq p_i\leq 1)$ and integer $k$, the rejection sampler is defined as follows:

1. Initialize $T \gets \emptyset$;
2. For each $i$ $(1\leq i\leq n)$, add $i$ into $T$ with probability $p_i$;
3. Output $T$ if the size of $T$ is exactly $k$; otherwise, repeat the process.

Now you are given integers $a_1,a_2,...,a_n$ and $k$. Bobo needs to set the parameters $p_1,p_2,\ldots,p_n$ satisfying

- $\sum_{i=1}^n p_i=k$;
- for all $S\subseteq \{1,2,\cdots, n\}$ such that $|S|=k$, the probability that the rejection sampler outputs $S$ is proportional to $\prod_{i \in S} a_i$.

Your task is to find out the parameters $p_1,p_2,\dots,p_n$ for Bobo. It is guaranteed that such parameters exist and **are unique**. Your answer will be considered correct if the absolute error of each $p_i$ doesn't exceed $10^{-6}$ compared to the unique answer.
**Input**

The first line of the input contains two integers $n$ and $k$ ($2 \le n \le 10^5$, $1 \le k \le n-1$).

The second line of the input contains $n$ integers $a_1,a_2,\ldots,a_n$ ($1 \le a_i \le 10^9$).
**Output**

Output $n$ lines. The $i$\-th line contains a single real number $p_i$.

Your answer is considered correct if the absolute error of each parameter does not exceed $10^{-6}$. Namely, if your answer is $a$, and the jury's answer is $b$, then your answer is accepted if $|b-a| \le 10^{-6}$ for all parameters.
Example Input1:
3 2
5 5 5
Example Output1:
0.666666666667
0.666666666667

0.666666666667 

## Solution


import sys

n, k = map(int, input().split())
a = list(map(int, input().split()))

def calc_p(a, k):
    n = len(a)
    sum_a = sum(a)
    p = [x / sum_a for x in a]
    t = k / sum(p)
    for i in range(50):
        sum_p = sum(p)
        t = k / sum_p
        for j in range(n):
            p[j] = a[j] * t / (1 + (a[j] - 1) * t)
    return p

p = calc_p(a, k)
for pi in p:
    print(pi)



## CODE


import sys

n, k = map(int, input().split())
a = list(map(int, input().split()))

def calc_p(a, k):
    n = len(a)
    sum_a = sum(a)
    p = [x / sum_a for x in a]
    t = k / sum(p)
    for i in range(50):
        sum_p = sum(p)
        t = k / sum_p
        for j in range(n):
            p[j] = a[j] * t / (1 + (a[j] - 1) * t)
    return p

p = calc_p(a, k)
for pi in p:
    print(pi)


### Explanation
The method used here is an iterative algorithm to find the parameters p_i. The idea is to start with an initial guess for p_i, which is proportional to a_i. Then, we iteratively update p_i until the sum of p_i converges to k. In each iteration, we calculate the sum of the current p_i and adjust each p_i accordingly. This process is repeated until the sum of p_i is close enough to k. The number of iterations is fixed to 50, which is sufficient for the given constraints.
## Token
[262, 623, 885]
 ### 

