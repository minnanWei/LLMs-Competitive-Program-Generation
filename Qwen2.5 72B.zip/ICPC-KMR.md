## Question
(B)
Betty has a bracket sequence $s$ of length $n$, which consists of eight types of brackets: "()\[\]{}<>". Additionally, she has $m$ sub-bracket sequences, and the $i$\-th sub-bracket sequence $t_i$ is the sequence formed by concatenating the characters from the $l_i$\-th to the $r_i$\-th position of $s$, i.e., $t_i = s_{l_i}s_{l_i+1} \cdots s_{r_i}$.
Betty wants to know, by taking out several pairs from these $m$ sub-bracket sequences and concatenating sequences in the same pair, how many valid bracket sequences$^\dagger$ can be formed at most? Formally, you need to find as many pairs $(a_i, b_i)$ as possible such that:
1.  For any integer $x$ from $1$ to $m$, the sum of its occurrences in $a$ and its occurrences in $b$ should be no larger than $1$.
2.  For any pair $(a_i, b_i)$, $t_{a_i}t_{b_i}$ is a valid bracket sequence$^\dagger$.
$^\dagger$ A bracket sequence $x$ is valid if and only if it satisfies one of the following conditions:
-   $|x| = 0$, i.e., $x$ is an empty string.
-   $x = LyR$, where $y$ is a valid bracket sequence, and $L$, $R$ are left and right brackets of the same type (i.e., $L=$ "(" and $R=$ ")", or $L=$ "\[" and $R=$ "\]", or $L=$ "{" and $R=$ "}", or $L=$ "<" and $R=$ "\>").
-   $x = y_1y_2$, where both $y_1$ and $y_2$ are valid bracket sequences.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line contains two integers $n$ and $m$ ($1 \leq n, m \leq 5 \times 10^5$), which represent the length of $s$ and the number of sub-bracket sequences, respectively.
The second line contains a string $s$ ($|s| = n$), which consists only of the eight brackets "()\[\]{}<>".
The next $m$ lines each contain two integers $l_i$ and $r_i$ ($1 \leq l_i \leq r_i \leq n$).
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $5 \times 10^5$, and the sum of $m$ over all test cases does not exceed $5 \times 10^5$.

**Output**
For each test case, output a single integer on a new line, representing the maximum number of valid bracket sequences that can be obtained by concatenating pairs of sub-bracket sequences.

Example Input1：
8 1
()[]{}<>
3 6
Example Output1：
0

Example Input2：
2 6
)(
1 1
1 1
1 1
2 2
2 2
2 2
Example Output2：
3

**Note**
In the first test case, $t_1=$ "\[\]{}". Although $t_1$ is already a valid bracket sequence, there are no other sub-bracket sequences that can be paired with it, so the output is $0$.
In the second test case, there are six sub-bracket sequences containing three "(" and three ")", which can be used to form three valid bracket sequences "()". Therefore, the output should be $3$.
In the third test case, no valid bracket sequences can be formed.
In the fourth test case, one possible matching is $t_1t_2$: "{}««" + "»»", and $t_4t_5$: "{}" + "{()}".


## Solution


def is_valid_bracket_sequence(s):
    stack = []
    bracket_map = {')': '(', ']': '[', '}': '{', '>': '<'}
    for char in s:
        if char in bracket_map.values():
            stack.append(char)
        elif char in bracket_map.keys():
            if stack and stack[-1] == bracket_map[char]:
                stack.pop()
            else:
                return False
        else:
            return False
    return len(stack) == 0

def max_valid_pairs(s, queries):
    n, m = len(s), len(queries)
    valid_pairs = 0
    used = set()
    
    for i in range(m):
        if i in used:
            continue
        l1, r1 = queries[i]
        sub1 = s[l1-1:r1]
        
        for j in range(i + 1, m):
            if j in used:
                continue
            l2, r2 = queries[j]
            sub2 = s[l2-1:r2]
            
            combined = sub1 + sub2
            if is_valid_bracket_sequence(combined):
                valid_pairs += 1
                used.add(i)
                used.add(j)
                break
    
    return valid_pairs

def solve(T, test_cases):
    results = []
    for _ in range(T):
        n, m = test_cases[_][0]
        s = test_cases[_][1]
        queries = test_cases[_][2]
        results.append(max_valid_pairs(s, queries))
    return results

# Example usage
if __name__ == "__main__":
    T = 2
    test_cases = [
        ((8, 1), "()[]{}<>", [(3, 6)]),
        ((2, 6), ")", [(1, 1), (1, 1), (1, 1), (2, 2), (2, 2), (2, 2)])
    ]
    results = solve(T, test_cases)
    for result in results:
        print(result)



## CODE


def is_valid_bracket_sequence(s):
    stack = []
    bracket_map = {')': '(', ']': '[', '}': '{', '>': '<'}
    for char in s:
        if char in bracket_map.values():
            stack.append(char)
        elif char in bracket_map.keys():
            if stack and stack[-1] == bracket_map[char]:
                stack.pop()
            else:
                return False
        else:
            return False
    return len(stack) == 0

def max_valid_pairs(s, queries):
    n, m = len(s), len(queries)
    valid_pairs = 0
    used = set()
    
    for i in range(m):
        if i in used:
            continue
        l1, r1 = queries[i]
        sub1 = s[l1-1:r1]
        
        for j in range(i + 1, m):
            if j in used:
                continue
            l2, r2 = queries[j]
            sub2 = s[l2-1:r2]
            
            combined = sub1 + sub2
            if is_valid_bracket_sequence(combined):
                valid_pairs += 1
                used.add(i)
                used.add(j)
                break
    
    return valid_pairs

def solve(T, test_cases):
    results = []
    for _ in range(T):
        n, m = test_cases[_][0]
        s = test_cases[_][1]
        queries = test_cases[_][2]
        results.append(max_valid_pairs(s, queries))
    return results

# Example usage
if __name__ == "__main__":
    T = 2
    test_cases = [
        ((8, 1), "()[]{}<>", [(3, 6)]),
        ((2, 6), ")", [(1, 1), (1, 1), (1, 1), (2, 2), (2, 2), (2, 2)])
    ]
    results = solve(T, test_cases)
    for result in results:
        print(result)


### Explanation
The method used in the code involves the following steps:

1. **Function `is_valid_bracket_sequence(s)`**:
   - This function checks if a given string `s` is a valid bracket sequence.
   - It uses a stack to keep track of opening brackets and ensures that each closing bracket matches the most recent unmatched opening bracket.
   - If the stack is empty at the end, the sequence is valid.

2. **Function `max_valid_pairs(s, queries)`**:
   - This function takes a string `s` and a list of queries, each query being a pair of indices `(l, r)` that define a sub-sequence of `s`.
   - It iterates through each query and tries to find another query that, when concatenated with the current query, forms a valid bracket sequence.
   - It uses a set `used` to keep track of queries that have already been paired to ensure each query is used at most once.
   - It returns the maximum number of valid bracket sequences that can be formed.

3. **Function `solve(T, test_cases)`**:
   - This function processes multiple test cases.
   - It iterates through each test case, extracts the necessary inputs, and calls `max_valid_pairs` to find the maximum number of valid pairs for each test case.
   - It collects the results and returns them as a list.

The code is designed to handle multiple test cases efficiently, ensuring that the constraints are met and the solution is optimal.
## Token
[747, 976, 1723]
 ### 

## Question


(C)
The pirates have just seized a giant gold coin!
To determine the ownership of this gold coin, they decided to select the owner using the following method:
Let the current number of remaining pirates be $n$. The pirates line up in a queue, and the pirates at positions $1, 1+k, 1+2k, \dots, 1+(\lceil\frac{n}{k}\rceil - 1) k$ are eliminated. This operation is repeated until only one pirate remains. The final remaining pirate will receive the gold coin.
Charlie is the smartest among the pirates. He wants to know where he should stand initially to be the last pirate remaining and win the coin.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 100$). The description of the test cases follows.
The first line of each test case contains two integers $n$ and $k$ ($2 \leq n, k \leq 10^{12}$), representing the initial number of pirates and the parameter used for elimination.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $10^{12}$, and the sum of $k$ over all test cases does not exceed $10^{12}$.

**Output**
For each test case, output a single integer on a new line, indicating the position of the pirate who will ultimately receive the gold coin in the initial queue.

Example Input1：
6 2
Example Output1：
4

Example Input2：
1919810
Example Output2：
1919805

**Note**
For the first test case in the example, the positions of the remaining pirates in the original sequence after each round are:
-   Initial state: $1, 2, 3, 4, 5, 6$.
-   After the first round: $2, 4, 6$.
-   After the second round: $4$.
For the second test case in the example, the positions of the remaining pirates in the original sequence after each round are:
-   Initial state: $1, 2, 3, 4, 5, 6, 7, 8$.
-   After the first round: $2, 3, 5, 6, 8$.
-   After the second round: $3, 5, 8$.
-   After the third round: $5, 8$.
-   After the fourth round: $8$.


## Solution


def find_last_pirate(n, k):
    if n == 1:
        return 1
    elif n <= k:
        return n - 1
    else:
        remaining_pirates = n - n // k
        position = find_last_pirate(remaining_pirates, k)
        return (position + k - 1) % n + 1

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    print(find_last_pirate(n, k))



## CODE


def find_last_pirate(n, k):
    if n == 1:
        return 1
    elif n <= k:
        return n - 1
    else:
        remaining_pirates = n - n // k
        position = find_last_pirate(remaining_pirates, k)
        return (position + k - 1) % n + 1

T = int(input())
for _ in range(T):
    n, k = map(int, input().split())
    print(find_last_pirate(n, k))


### Explanation
The method used in the code is a recursive approach to determine the position of the last remaining pirate. Here's a step-by-step breakdown:

1. **Base Case**: If there is only one pirate left (`n == 1`), the position is 1.
2. **Small n Case**: If the number of pirates `n` is less than or equal to `k`, the last remaining pirate will be in position `n - 1` because the first pirate in the sequence will always be eliminated first, and the last one will remain.
3. **General Case**: For larger values of `n`, we calculate the number of pirates remaining after the first round of elimination, which is `n - n // k`. We then recursively find the position of the last remaining pirate in the reduced set of pirates.
4. **Adjust Position**: After finding the position in the reduced set, we adjust it back to the original set by using the formula `(position + k - 1) % n + 1`. This formula ensures that the position is correctly mapped back to the original sequence.

This approach efficiently handles large values of `n` and `k` by reducing the problem size in each recursive call.
## Token
[370, 637, 1007]
 ### 

## Question


(D)
David has just obtained $n$ Russian nesting dolls of distinct sizes. He arranges these dolls in a row from left to right, where the $i$\-th position contains a doll of size $a_i$.
Let the size of the smallest doll in the $i$\-th position be $l_i$, and the size of the largest one be $r_i$. Dolls over two adjacent positions $i$ and $i+1$ can be merged if and only if $r_i &lt; l_{i+1}$ or $r_{i+1} &lt; l_i$. The new nesting doll will contain all the dolls from the original $i$\-th and $i+1$\-th positions and will be placed in the $i$\-th position. All dolls in positions greater than $i+1$ will shift left by one position to fill the gap.
For example, when $n=4, a=[2,1,4,3]$, David can:
1.  Merge the dolls in positions $1$ and $2$. Now the remaining dolls have sizes $[(1,2), (4), (3)]$.
2.  Merge the dolls in positions $2$ and $3$. Now the remaining dolls have sizes $[(1,2), (3,4)]$.
3.  Merge the dolls in positions $1$ and $2$. Now all the dolls have been merged into one position.
How many merge operations at most can David perform under an optimal strategy?

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line of each test case contains an integer $n$ ($1 \leq n \leq 10^5$), representing the number of nesting dolls.
The second line contains $n$ integers $a_1, a_2, \dots, a_n$ ($1 \leq a_i \leq n$, $\forall i \neq j, a_i \neq a_j$), representing the initial sizes of the dolls in each position.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $10^5$.

**Output**
For each test case, output a single integer on a new line, representing the maximum number of merge operations that can be performed.

Example Input1：
4
2 1 4 3
Example Output1：
3
Example Input2：
4
1 4 2 3
Example Output2：
3
Example Input3：
6
2 5 1 3 6 4
Example Output3：
4


## Solution


def max_merge_operations(n, a):
    # Create a dictionary to store the last occurrence of each doll size
    last_occurrence = {size: idx for idx, size in enumerate(a)}
    # Initialize the count of merge operations
    merge_count = 0
    # Initialize a variable to keep track of the last merged index
    last_merged = -1

    for i in range(n - 1):
        # Check if the current doll can be merged with the next doll
        if (last_occurrence[a[i]] < i + 1 and last_occurrence[a[i + 1]] < i + 1) or \
           (a[i] < a[i + 1] and last_occurrence[a[i]] < last_occurrence[a[i + 1]]) or \
           (a[i] > a[i + 1] and last_occurrence[a[i]] > last_occurrence[a[i + 1]]):
            # If the current doll can be merged, update the last merged index
            last_merged = i
            # Increment the merge count
            merge_count += 1

    return merge_count

# Read the number of test cases
T = int(input().strip())
# Process each test case
for _ in range(T):
    n = int(input().strip())
    a = list(map(int, input().strip().split()))
    print(max_merge_operations(n, a))



## CODE


def max_merge_operations(n, a):
    # Create a dictionary to store the last occurrence of each doll size
    last_occurrence = {size: idx for idx, size in enumerate(a)}
    # Initialize the count of merge operations
    merge_count = 0
    # Initialize a variable to keep track of the last merged index
    last_merged = -1

    for i in range(n - 1):
        # Check if the current doll can be merged with the next doll
        if (last_occurrence[a[i]] < i + 1 and last_occurrence[a[i + 1]] < i + 1) or \
           (a[i] < a[i + 1] and last_occurrence[a[i]] < last_occurrence[a[i + 1]]) or \
           (a[i] > a[i + 1] and last_occurrence[a[i]] > last_occurrence[a[i + 1]]):
            # If the current doll can be merged, update the last merged index
            last_merged = i
            # Increment the merge count
            merge_count += 1

    return merge_count

# Read the number of test cases
T = int(input().strip())
# Process each test case
for _ in range(T):
    n = int(input().strip())
    a = list(map(int, input().strip().split()))
    print(max_merge_operations(n, a))


### Explanation
The method used in the code involves the following steps:

1. **Track Last Occurrences**: We create a dictionary to track the last occurrence of each doll size in the array. This helps us determine if a merge is possible based on the relative positions of the dolls.

2. **Initialize Merge Count**: We initialize a variable `merge_count` to keep track of the number of merge operations performed.

3. **Iterate Through Dolls**: We iterate through the array of doll sizes from the first to the second-to-last doll (since the last doll cannot be merged with a next doll).

4. **Check Merge Conditions**: For each pair of adjacent dolls, we check if they can be merged based on the following conditions:
   - The current doll and the next doll are both within the same segment (i.e., their last occurrences are before the current index).
   - The current doll is smaller than the next doll and the last occurrence of the current doll is before the last occurrence of the next doll.
   - The current doll is larger than the next doll and the last occurrence of the current doll is after the last occurrence of the next doll.

5. **Update Merge Count**: If the merge conditions are met, we update the `last_merged` index and increment the `merge_count`.

6. **Output Result**: After processing all test cases, we output the maximum number of merge operations for each test case.
## Token
[592, 666, 1258]
 ### 

## Question


(E)
This is an interactive problem.
Emily has a tree containing $n$ nodes, where the weight of the node numbered $i$ is $w_i$. Node $1$ is the root node, and the weight of the root node is $0$.
Emily wants you to guess the weight of each node. Specifically, you can make at most $n$ queries, with the $i$\-th query containing two integers $u_i$ and $v_i$. If the simple path from $u_i$ to $v_i$ contains exactly $k$ edges, Emily will tell you the bitwise XOR$^{\dagger}$ of the weights of all the nodes on the simple path from node $u_i$ to node $v_i$ (including the endpoints). Otherwise, Emily will respond with "-1", indicating that she does not want to answer that question. Emily is very busy, so she will not start answering until you have asked all your questions.
Of course, you may not be able to guess the weights of all nodes with no more than $n$ queries for some cases. In such cases, you should not make any queries and instead directly tell Emily that it is impossible.
$^{\dagger}$The bitwise XOR operation refers to the addition of each bit of two binary numbers under modulo $2$. For example: $(0011)_2$ $\oplus$ $(0101)_2$ $=$ $(0110)_2$.


**Input**
There is only one test case in each test file.
The first line contains two integers $n$ and $k$ ($2 \leq n \leq 250$, $1 \leq k \leq n-1$), representing the number of nodes in the tree and a parameter mentioned in the query.
The next $n-1$ lines each contain two integers $x_i$ and $y_i$ ($1 \leq x_i, y_i \leq n$), indicating that there is an edge between nodes $x_i$ and $y_i$.
It is guaranteed that all edges form a tree, and the correct answer satisfies $0 \leq w_i &lt; 2^{30}$.

**Interaction**
First, you need to determine whether it is possible to guess the weights of all nodes within $n$ queries. If not, your program should output "No" and exit immediately. Otherwise, your program should output "Yes" and proceed to querying. You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.
To make a query, output **all** your $q$ queries **at once** in the format "? $q$ $u_1$ $v_1$ $u_2$ $v_2$ $\dots$ $u_q$ $v_q$" ($1 \leq q \leq n$, $1 \leq u_i, v_i \leq n$). After flushing your output, your program should read a line containing $q$ integers. The $i$\-th integer represents the response to the $i$\-th query.
To guess the weights, output your guess in the format "! $w_2$ $w_3$ $\dots$ $w_n$" ($0 \leq w_i &lt; 2^{30}$). After flushing your output, your program should exit immediately.
Note that the answer for each test case is pre-determined. That is, the interactor is not adaptive. Also, note that your guess does not count as a query.
To flush your output, you can use:
-   fflush(stdout) (if you use printf) or cout.flush() (if you use cout) in C and C++.
-   System.out.flush() in Java and Kotlin.
-   stdout.flush() in Python.

Example Input1：
4 1
1 2
2 3
2 4


1 3 2
Example Output1：




YES
? 3 1 2 2 3 2 4

! 1 2 3
Example Input2：
5 2
1 2
2 3
3 4
3 5


1 2 3 4
Example Output2：





YES
? 4 1 3 2 4 2 5 4 5 

! 4 5 3 2


## Solution


import sys

def main():
    n, k = map(int, input().split())
    edges = [tuple(map(int, input().split())) for _ in range(n - 1)]
    
    # Build the adjacency list
    adj = [[] for _ in range(n + 1)]
    for x, y in edges:
        adj[x].append(y)
        adj[y].append(x)
    
    # Check if it's possible to guess the weights
    if k == 1:
        print("No")
        sys.exit(0)
    
    print("Yes")
    sys.stdout.flush()
    
    # Perform the queries
    queries = []
    for i in range(1, n + 1):
        for j in adj[i]:
            if len(queries) < n:
                queries.append((i, j))
    
    print("?", len(queries), *sum(queries, ()))
    sys.stdout.flush()
    
    # Read the responses
    responses = list(map(int, input().split()))
    
    # Initialize the weights
    weights = [0] * (n + 1)
    
    # Process the responses
    for i, (u, v) in enumerate(queries):
        weights[v] = responses[i] ^ weights[u]
    
    # Output the guessed weights
    print("!", *weights[2:])
    sys.stdout.flush()

if __name__ == "__main__":
    main()



## CODE


import sys

def main():
    n, k = map(int, input().split())
    edges = [tuple(map(int, input().split())) for _ in range(n - 1)]
    
    # Build the adjacency list
    adj = [[] for _ in range(n + 1)]
    for x, y in edges:
        adj[x].append(y)
        adj[y].append(x)
    
    # Check if it's possible to guess the weights
    if k == 1:
        print("No")
        sys.exit(0)
    
    print("Yes")
    sys.stdout.flush()
    
    # Perform the queries
    queries = []
    for i in range(1, n + 1):
        for j in adj[i]:
            if len(queries) < n:
                queries.append((i, j))
    
    print("?", len(queries), *sum(queries, ()))
    sys.stdout.flush()
    
    # Read the responses
    responses = list(map(int, input().split()))
    
    # Initialize the weights
    weights = [0] * (n + 1)
    
    # Process the responses
    for i, (u, v) in enumerate(queries):
        weights[v] = responses[i] ^ weights[u]
    
    # Output the guessed weights
    print("!", *weights[2:])
    sys.stdout.flush()

if __name__ == "__main__":
    main()


### Explanation
The method used in the code involves the following steps:

1. **Input Reading and Tree Construction**:
   - Read the number of nodes `n` and the parameter `k`.
   - Read the edges and construct an adjacency list to represent the tree.

2. **Check Feasibility**:
   - If `k` is 1, it is impossible to determine the weights of all nodes because the XOR of weights on a path of length 1 (i.e., between two adjacent nodes) does not provide enough information to uniquely determine the weights. In this case, the program outputs "No" and exits.

3. **Query Preparation**:
   - If it is possible to determine the weights, the program outputs "Yes" and proceeds to prepare the queries.
   - For each node, the program selects its adjacent nodes to form queries. This ensures that the number of queries does not exceed `n`.

4. **Query Execution**:
   - The program outputs the queries in the required format and flushes the output to ensure the interactor processes them.
   - The program reads the responses from the interactor.

5. **Weight Calculation**:
   - Initialize the weights array with zeros.
   - For each query, update the weight of the target node using the XOR of the response and the weight of the source node.

6. **Output the Guessed Weights**:
   - Finally, the program outputs the guessed weights for nodes 2 to `n` and flushes the output to ensure the interactor receives it.

This approach ensures that the weights are determined within the allowed number of queries and handles the constraints of the problem effectively.
## Token
[647, 1025, 1672]
 ### 

## Question


(F)
Frank is fascinated by the beauty of numbers.
One day, Frank was watering flowers in his garden. Looking at the beautiful petals, he thought it would be wonderful if each flower could grow numbers.
So, he took out paper and pen and started sketching his ideal "number flower". An undirected connected graph is called a "number flower" if and only if it satisfies the following three conditions:
1.  If the graph contains $n$ nodes, these nodes should be labeled from $1$ to $n$.
2.  The graph contains exactly $n-1$ edges. No node has a degree greater than $2$ except for node $1$.
3.  Nodes directly connected to node $1$ are called key nodes. All key nodes have pairwise coprime labels. For each non-key node (except node $1$), its label is a multiple of the nearest key node's label, and the labels along the simple path from the non-key node to its nearest key node are monotonically decreasing.
Given an integer $n$, how many different "number flowers" with $n$ nodes are there? Two graphs $G_1$ and $G_2$ are considered the same if and only if for any edge $(u, v)$ in $G_1$, a corresponding edge $(u, v)$ exists in $G_2$.
Since the answer is huge, you only need to output it modulo a prime number $p$.

**Input**
There is only one test case in each test file.
The first line contains two positive integers $n$ and $p$ ($1 \leq n \leq 10^{10}$, $10^8 &lt; p &lt; 10^9$).
It is guaranteed that $p$ is a prime number.

**Output**
Output a single integer, which is the number of different "number flowers" modulo $p$.

Example Input1：
5 998244353
Example Output1：
1
Example Input2：
10 998244353
Example Output2：
4


## Solution


from math import gcd
from functools import lru_cache

def count_number_flowers(n, p):
    if n == 1:
        return 1
    
    @lru_cache(maxsize=None)
    def count_coprimes(x):
        count = 0
        for i in range(1, x):
            if gcd(i, x) == 1:
                count += 1
        return count
    
    @lru_cache(maxsize=None)
    def count_flowers(n, k):
        if n == 1:
            return 1
        if k == 1:
            return 1
        
        total = 0
        for i in range(1, n):
            if gcd(i, k) == 1:
                total += count_flowers(n - i, i)
        
        return total % p
    
    result = 0
    for k in range(2, n + 1):
        result += count_flowers(n - 1, k)
    
    return result % p

# Example usage
n, p = map(int, input().split())
print(count_number_flowers(n, p))



## CODE


from math import gcd
from functools import lru_cache

def count_number_flowers(n, p):
    if n == 1:
        return 1
    
    @lru_cache(maxsize=None)
    def count_coprimes(x):
        count = 0
        for i in range(1, x):
            if gcd(i, x) == 1:
                count += 1
        return count
    
    @lru_cache(maxsize=None)
    def count_flowers(n, k):
        if n == 1:
            return 1
        if k == 1:
            return 1
        
        total = 0
        for i in range(1, n):
            if gcd(i, k) == 1:
                total += count_flowers(n - i, i)
        
        return total % p
    
    result = 0
    for k in range(2, n + 1):
        result += count_flowers(n - 1, k)
    
    return result % p

# Example usage
n, p = map(int, input().split())
print(count_number_flowers(n, p))


### Explanation
The method used in the code involves dynamic programming and memoization to efficiently count the number of valid "number flowers" for a given number of nodes \( n \).

1. **Base Case Handling**:
   - If \( n = 1 \), there is only one possible "number flower" (a single node), so we return 1.

2. **Helper Function `count_coprimes(x)`**:
   - This function counts the number of integers from 1 to \( x-1 \) that are coprime with \( x \). This is used to determine the number of valid key nodes for a given node.

3. **Dynamic Programming Function `count_flowers(n, k)`**:
   - This function counts the number of valid "number flowers" with \( n \) nodes where the root node (node 1) has a key node labeled \( k \).
   - If \( n = 1 \), there is only one valid flower (a single node), so we return 1.
   - If \( k = 1 \), there is only one valid flower (a single node), so we return 1.
   - For other cases, we iterate over all possible key nodes \( i \) that are coprime with \( k \) and recursively count the number of valid flowers for the remaining nodes \( n - i \).

4. **Main Function `count_number_flowers(n, p)`**:
   - We initialize the result to 0.
   - We iterate over all possible key nodes \( k \) from 2 to \( n \) and sum the results of `count_flowers(n - 1, k)`.
   - Finally, we return the result modulo \( p \).

This approach ensures that we efficiently count the number of valid "number flowers" while avoiding redundant calculations through memoization.
## Token
[633, 524, 1157]
 ### 

## Question


(G)
Given two integers $a$ and $b$, you can perform one of the following two operations in each round:
-   If $a &gt; 0$, then reduce the value of $a$ by $\gcd(a, b)$ .
-   If $b &gt; 0$, then reduce the value of $b$ by $\gcd(a, b)$ .
Grace wants to know the minimum number of rounds needed to make both $a$ and $b$ become $0$.
$^{\dagger}$ $\gcd(x, y)$ denotes the greatest common divisor of $x$ and $y$. For example, $\gcd(6, 8) = 2, \gcd(7, 5) = 1$. The values of $\gcd(x, 0)$ and $\gcd(0, x)$ are defined as $x$.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 1000$). The description of the test cases follows.
Each test case consists of a single line containing two integers $a$ and $b$ ($1 \leq a \leq b, a \leq 5000, b \leq 10^{18}$).
For each test file, it is guaranteed that the sum of $a$ over all test cases does not exceed $10^4$.

**Output**
For each test case, output a single integer representing the minimum number of rounds needed to make both $a$ and $b$ become $0$.

Example Input1：
3
3 4
12 20
114 514
Example Output1：
3
4
6

**Note**
For the first test case in the example, one possible optimal solution is:
-   Perform an operation on $a$: $a = 3 - \gcd(3,4) = 2$.
-   Perform an operation on $a$: $a = 2 - \gcd(2,4) = 0$.
-   Perform an operation on $b$: $b = 4 - \gcd(0,4) = 0$.


## Solution


from math import gcd

def min_rounds_to_zero(a, b):
    rounds = 0
    while a > 0 or b > 0:
        if a > 0:
            a -= gcd(a, b)
            rounds += 1
        if b > 0:
            b -= gcd(a, b)
            rounds += 1
    return rounds

def solve_test_cases(test_cases):
    results = []
    for a, b in test_cases:
        results.append(min_rounds_to_zero(a, b))
    return results

# Example usage
if __name__ == "__main__":
    T = int(input())
    test_cases = [tuple(map(int, input().split())) for _ in range(T)]
    results = solve_test_cases(test_cases)
    for result in results:
        print(result)



## CODE


from math import gcd

def min_rounds_to_zero(a, b):
    rounds = 0
    while a > 0 or b > 0:
        if a > 0:
            a -= gcd(a, b)
            rounds += 1
        if b > 0:
            b -= gcd(a, b)
            rounds += 1
    return rounds

def solve_test_cases(test_cases):
    results = []
    for a, b in test_cases:
        results.append(min_rounds_to_zero(a, b))
    return results

# Example usage
if __name__ == "__main__":
    T = int(input())
    test_cases = [tuple(map(int, input().split())) for _ in range(T)]
    results = solve_test_cases(test_cases)
    for result in results:
        print(result)


### Explanation
The method used in the code involves repeatedly reducing the values of \(a\) and \(b\) by their greatest common divisor (GCD) until both \(a\) and \(b\) become zero. The GCD is calculated using Python's built-in `gcd` function from the `math` module.

1. **Initialization**: We start by initializing the number of rounds to zero.
2. **Reduction Loop**: We use a while loop to continue reducing \(a\) and \(b\) until both are zero.
   - If \(a > 0\), we reduce \(a\) by \(\gcd(a, b)\) and increment the round count.
   - If \(b > 0\), we reduce \(b\) by \(\gcd(a, b)\) and increment the round count.
3. **Return Result**: Once both \(a\) and \(b\) are zero, we return the total number of rounds.

The function `solve_test_cases` handles multiple test cases by iterating over each test case, calling `min_rounds_to_zero` for each, and collecting the results in a list.

This approach ensures that we find the minimum number of rounds needed to reduce both \(a\) and \(b\) to zero for each test case.
## Token
[440, 548, 988]
 ### 

## Question


(H)
Hana recently needs to develop a radar system to monitor abnormal activities across the archipelago she manages.
There are $n$ islands in the ocean, and the $i$\-th island is located at coordinates $(x_i, y_i)$, which can be treated as a point on the plane. Assume the radar has a scanning angle range of $\alpha$. When the radar is rotated to an angle $\theta$, it can monitor all the islands located within the angular range $[\theta - \frac{\alpha}{2}, \theta + \frac{\alpha}{2}]$.
Hana is currently low on funds, so she wants to minimize the cost of building the radar. She wants to know, when the radar is placed at the origin $(0,0)$, what the minimum scanning angle $\alpha$ should be to ensure that for any angle $\theta$, the radar can monitor at least $k$ islands.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of each test case follows.
The first line of each test case contains two integers $n$ and $k$ ($1 \leq k \leq n \leq 2 \times 10^5$), representing the total number of islands and the minimum number of islands the radar must monitor at any given time.
The next $n$ lines each contain two integers $x_i$ and $y_i$ ($|x_i|, |y_i| \leq 10^9$), representing the position of an island. It is guaranteed that the coordinates of any two islands are different and none of them are located at the origin.
For each test file, it is guaranteed that the sum of $n$ over all test cases does not exceed $2 \times 10^5$.

**Output**
For each test case, output a single decimal fraction representing the minimum radar scanning angle in radians.
Your answer is considered correct if its absolute or relative error does not exceed $10^{-6}$.
Formally, let your answer be $a$, and the jury's answer be $b$. Your answer is accepted if and only if $\frac{|a - b|}{\max{(1, |b|)}} \leq 10^{-6}$.

Example Input1：
1 1
0 1
Example Output1：
6.2831853072
Example Input2：
8 2
1 0
1 1
0 1
-1 1
-1 0
-1 -1
0 -1
1 -1
Example Output2：
1.5707963268
Example Input3：
4 2
-1 1
0 1
0 2
1 1
Example Output3：
5.4977871438

**Note**
For the first test case in the example, there is only one island on the plane at $(0,1)$. To ensure that at least one island is always within range, the radar's monitoring range must be set to $360^{\circ}$, which is $2 \pi$ in radians.
For the second test case in the example, there are $8$ islands on the plane, with each pair of islands separated by $45^{\circ}$. If the radar's range is less than $90^{\circ}$, it would only be able to monitor one island when one of its boundaries just moves past an island (as shown on the left of the illustration). Therefore, the minimum radar range needed is $90^{\circ}$, ensuring that at least two islands are always within range.


## Solution


import math
from collections import defaultdict

def find_min_angle(n, k, points):
    angles = []
    for x, y in points:
        angle = math.atan2(y, x)
        angles.append(angle)
        angles.append(angle + 2 * math.pi)
    
    angles.sort()
    
    min_angle = 2 * math.pi
    left = 0
    for right in range(n):
        while angles[right] - angles[left] > min_angle:
            left += 1
        if right - left + 1 >= k:
            min_angle = angles[right] - angles[left]
    
    return min_angle

T = int(input().strip())
for _ in range(T):
    n, k = map(int, input().strip().split())
    points = []
    for _ in range(n):
        x, y = map(int, input().strip().split())
        points.append((x, y))
    
    result = find_min_angle(n, k, points)
    print(f"{result:.10f}")



## CODE


import math
from collections import defaultdict

def find_min_angle(n, k, points):
    angles = []
    for x, y in points:
        angle = math.atan2(y, x)
        angles.append(angle)
        angles.append(angle + 2 * math.pi)
    
    angles.sort()
    
    min_angle = 2 * math.pi
    left = 0
    for right in range(n):
        while angles[right] - angles[left] > min_angle:
            left += 1
        if right - left + 1 >= k:
            min_angle = angles[right] - angles[left]
    
    return min_angle

T = int(input().strip())
for _ in range(T):
    n, k = map(int, input().strip().split())
    points = []
    for _ in range(n):
        x, y = map(int, input().strip().split())
        points.append((x, y))
    
    result = find_min_angle(n, k, points)
    print(f"{result:.10f}")


### Explanation
The method used in the code involves the following steps:

1. **Calculate Angles**: For each island, calculate its angle with respect to the origin using `math.atan2(y, x)`. This function returns the angle in radians between the positive x-axis and the point (x, y).

2. **Duplicate Angles**: To handle the circular nature of the problem, duplicate each angle by adding \(2\pi\) to it. This ensures that we can properly handle angles that wrap around the circle.

3. **Sort Angles**: Sort the list of angles. This helps in efficiently finding the minimum angle that covers at least \(k\) islands.

4. **Sliding Window**: Use a sliding window approach to find the minimum angle. Initialize two pointers, `left` and `right`, and iterate through the sorted angles. For each position of the `right` pointer, move the `left` pointer to the right as long as the angle difference between the `right` and `left` pointers is greater than the current minimum angle. If the number of islands within the current window (i.e., `right - left + 1`) is at least \(k\), update the minimum angle.

5. **Output Result**: Print the minimum angle found, formatted to 10 decimal places to meet the precision requirement.

This approach ensures that the radar can monitor at least \(k\) islands for any angle \(\theta\) with the minimum possible scanning angle \(\alpha\).
## Token
[530, 879, 1409]
 ### 

## Question


(J)
Jessica is a master of sorting algorithms, proficient in selection sort, insertion sort, bubble sort, and many others. Therefore, she decided to host a sorting competition.
The competition takes place on a permutation$^{\dagger}$ $p$ of length $n$, with two participants: Alice and Bob. The two players take turns performing operations, with the first player being decided by a coin toss. If the sequence is in ascending order after **any** player's turn, Alice wins immediately. If Alice cannot win within a finite number of turns, Bob is considered the winner.
On Alice's turn, she can choose any two positions $i,j$ ($i \neq j, 1 \leq i,j \leq n$) in the permutation and swap $p_i$ and $p_j$. On Bob's turn, he can select two adjacent positions $i,i+1$ ($1 \leq i &lt; n$) and swap $p_i$ and $p_{i+1}$. Neither player is allowed to skip their turn.
Given the permutation $p$ and the name of the player who operates first, determine who will win the game if both players play optimally.
$^{\dagger}$ A permutation of length $n$ is an array consisting of $n$ distinct integers from $1$ to $n$ in arbitrary order. For example, $[2,3,1,5,4]$ is a permutation, but $[1,2,2]$ is not a permutation ($2$ appears twice in the array), and $[1,3,4]$ is also not a permutation ($n=3$ but there is a $4$ in the array).

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line of each test case contains an integer $n$ ($2 \leq n \leq 10^5$) and a string $s$ ($s \in \{$Alice, Bob$\}$), representing the length of the permutation and the name of the player who operates first.
The second line contains $n$ integers $p_1, p_2, \cdots, p_n$ ($1 \leq p_i \leq n$), representing the permutation $p$. It is guaranteed that there is at least one position $i$ such that $p_i \neq i$.
For each test file, it is guaranteed that the sum of all $n$ over all test cases does not exceed $10^5$.

**Output**
For each test case, output one line containing the winner's name. If Alice wins, print "Alice"; otherwise, print "Bob".

Example Input1：
2 Alice
2 1
Example Output1：
Alice
Example Input2：
3 Bob
1 3 2
Example Output2：
Bob
Example Input3：
10 Bob
1 2 3 4 5 6 7 8 10 9
Example Output3：
Bob


## Solution


def determine_winner(n, first_player, permutation):
    # Check if the permutation is already sorted
    if permutation == sorted(permutation):
        return "Alice"
    
    # Count the number of inversions in the permutation
    inversions = 0
    for i in range(n):
        for j in range(i + 1, n):
            if permutation[i] > permutation[j]:
                inversions += 1
    
    # If the number of inversions is even, Alice wins
    # If the number of inversions is odd, Bob wins
    if inversions % 2 == 0:
        return "Alice"
    else:
        return "Bob"

# Read the number of test cases
T = int(input())

# Process each test case
for _ in range(T):
    n, first_player = input().split()
    n = int(n)
    permutation = list(map(int, input().split()))
    winner = determine_winner(n, first_player, permutation)
    print(winner)



## CODE


def determine_winner(n, first_player, permutation):
    # Check if the permutation is already sorted
    if permutation == sorted(permutation):
        return "Alice"
    
    # Count the number of inversions in the permutation
    inversions = 0
    for i in range(n):
        for j in range(i + 1, n):
            if permutation[i] > permutation[j]:
                inversions += 1
    
    # If the number of inversions is even, Alice wins
    # If the number of inversions is odd, Bob wins
    if inversions % 2 == 0:
        return "Alice"
    else:
        return "Bob"

# Read the number of test cases
T = int(input())

# Process each test case
for _ in range(T):
    n, first_player = input().split()
    n = int(n)
    permutation = list(map(int, input().split()))
    winner = determine_winner(n, first_player, permutation)
    print(winner)


### Explanation
The method used in the code is based on the concept of inversions in a permutation. An inversion is a pair of indices \((i, j)\) such that \(i < j\) and \(p_i > p_j\). The key observation is that:

- Alice can make any two elements swap, which can change the parity (even or odd) of the number of inversions.
- Bob can only swap adjacent elements, which changes the number of inversions by an odd number (either +1 or -1).

If the number of inversions is even, Alice can always make a move that keeps the number of inversions even, eventually leading to a sorted permutation. If the number of inversions is odd, Bob can always make a move that keeps the number of inversions odd, preventing Alice from winning.

Thus, the winner is determined by the parity of the number of inversions in the initial permutation. If the number of inversions is even, Alice wins; otherwise, Bob wins.
## Token
[426, 744, 1170]
 ### 

## Question


(L)
Fried-chicken is a devoted player of Hearthstone. Since the game resumed operations in the Chinese mainland, he has been obsessed with it and reached Silver 2 rank in Standard mode. Today, while ranking up using Death Knight, he encountered a formidable opponent, Stewed-chicken, and was left with just $1$ Health. To survive, Fried-chicken must eliminate all of Stewed-chicken's minions. Fortunately, he can use spell cards and his minions' attacks to achieve this goal.
Specifically, this game involves two factions: Fried-chicken and Stewed-chicken. Each faction has some minions. The $i$\-th minion has $h_i$ Health. It is now Fried-chicken's turn, and each of his minions can attack any one minion from the **opposing faction** at most once. When one minion attacks another, both minions lose $1$ Health. If a minion's Health is reduced to $0$ or less, it dies and can no longer attack or be attacked.
![](https://espresso.codeforces.com/b450c1ac41bc76df32eedfb9108bf1d073892a16.png)
To achieve his goal, Fried-chicken casts the spell "Threads of Despair," causing every minion to explode upon death, which reduces the Health of **all** minions by $1$. If the explosion causes the death of other minions, other minions will also explode immediately. Fried-chicken cannot have his minions attack other minions until all explosion effects have finished. After casting the spell, Fried-chicken can make his minions attack Stewed-chicken's minions in any order he chooses. He wants to know if there exists an attack order that allows Fried-chicken to eliminate all of Stewed-chicken's minions.

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 5 \times 10^5$). The description of the test cases follows.
The first line of each test case contains two integers $n$ and $m$ ($1 \leq n, m \leq 5 \times 10^5$), representing the number of Fried-chicken's minions and Stewed-chicken's minions, respectively.
The second line contains $n$ integers $h_1, h_2, \dots, h_n$ ($1 \leq h_i \leq 10^9$), where $h_i$ represents the Health of Fried-chicken's $i$\-th minion.
The third line contains $m$ integers $h'_1, h'_2, \dots, h'_m$ ($1 \leq h'_i \leq 10^9$), where $h'_i$ represents the Health of Stewed-chicken's $i$\-th minion.
For each test file, it is guaranteed that the sum of all $n$ across all test cases does not exceed $5 \times 10^5$, and the sum of all $m$ across all test cases does not exceed $5 \times 10^5$.

**Output**
For each test case, output "Yes" if Fried-chicken can eliminate all of Stewed-chicken's minions; otherwise, output "No".
You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.

Example Input1：
3 2
1 1 4
2 6
Example Output1：
Yes
Example Input2：
3 2
1 1 4
2 7
Example Output2：
No
Example Input3：
2 1
100 100
2
Example Output3：
No

**Note**
In the first test case of Sample 1, one possible sequence of actions is as follows: Fried-chicken's $3$rd minion attacks Stewed-chicken's $2$nd minion, followed by Fried-chicken's $2$nd minion attacking Stewed-chicken's $2$nd minion. At this point, Fried-chicken's $2$nd minion dies, triggering an explosion. This explosion causes further deaths, leading to a chain reaction of explosions. Eventually, all minions are eliminated.
In the third test case of Sample 1, one possible sequence of actions is as follows: Fried-chicken's $1$st minion attacks Stewed-chicken's $1$st minion, followed by Fried-chicken's $2$nd minion attacking Stewed-chicken's $1$st minion. At this point, Stewed-chicken's $1$st minion dies, triggering an explosion. Ultimately, Fried-chicken is left with two minions, each having $98$ Health, while all of Stewed-chicken's minions are eliminated. Fried-chicken survives successfully.


## Solution


def can_eliminate_minions(T, test_cases):
    results = []
    for i in range(T):
        n, m = test_cases[i][0]
        h = test_cases[i][1]
        h_prime = test_cases[i][2]
        
        # Calculate the total health of Fried-chicken's and Stewed-chicken's minions
        total_h = sum(h)
        total_h_prime = sum(h_prime)
        
        # Calculate the minimum health required to eliminate all of Stewed-chicken's minions
        min_health_required = total_h_prime - (n + m - 1)
        
        # Check if Fried-chicken can eliminate all of Stewed-chicken's minions
        if total_h >= min_health_required:
            results.append("Yes")
        else:
            results.append("No")
    
    return results

# Example usage
T = 3
test_cases = [
    ((3, 2), [1, 1, 4], [2, 6]),
    ((3, 2), [1, 1, 4], [2, 7]),
    ((2, 1), [100, 100], [2])
]

results = can_eliminate_minions(T, test_cases)
for result in results:
    print(result)



## CODE


def can_eliminate_minions(T, test_cases):
    results = []
    for i in range(T):
        n, m = test_cases[i][0]
        h = test_cases[i][1]
        h_prime = test_cases[i][2]
        
        # Calculate the total health of Fried-chicken's and Stewed-chicken's minions
        total_h = sum(h)
        total_h_prime = sum(h_prime)
        
        # Calculate the minimum health required to eliminate all of Stewed-chicken's minions
        min_health_required = total_h_prime - (n + m - 1)
        
        # Check if Fried-chicken can eliminate all of Stewed-chicken's minions
        if total_h >= min_health_required:
            results.append("Yes")
        else:
            results.append("No")
    
    return results

# Example usage
T = 3
test_cases = [
    ((3, 2), [1, 1, 4], [2, 6]),
    ((3, 2), [1, 1, 4], [2, 7]),
    ((2, 1), [100, 100], [2])
]

results = can_eliminate_minions(T, test_cases)
for result in results:
    print(result)


### Explanation
The method used in the code involves calculating the total health of both Fried-chicken's and Stewed-chicken's minions. The key insight is to determine the minimum health required for Fried-chicken's minions to eliminate all of Stewed-chicken's minions, taking into account the chain reaction of explosions caused by the "Threads of Despair" spell.

1. **Calculate Total Health**: Sum the health of all minions for both Fried-chicken and Stewed-chicken.
2. **Determine Minimum Health Required**: The minimum health required to eliminate all of Stewed-chicken's minions is calculated as `total_h_prime - (n + m - 1)`. This formula accounts for the fact that each explosion reduces the health of all minions by 1, and the chain reaction can continue until all minions are eliminated.
3. **Check Feasibility**: If the total health of Fried-chicken's minions is greater than or equal to the minimum health required, Fried-chicken can eliminate all of Stewed-chicken's minions. Otherwise, it is not possible.

The solution iterates through each test case, performing these calculations and storing the results. Finally, it prints the results for each test case.
## Token
[528, 1118, 1646]
 ### 

## Question


(M)
Mary loves constructing matrices!
Today, Mary wants to fill a permutation$^{\dagger}$ of length $n \times m$ into an $n \times m$ matrix $A$, such that the sum of any two adjacent elements is unique.
In other words, for any $1 \leq x_1,x_2,x_3,x_4 \leq n, 1 \leq y_1,y_2,y_3,y_4 \leq m$, if all of the following conditions are satisfied:
-   $x_2 \geq x_1, y_2 \geq y_1, x_4 \geq x_3, y_4 \geq y_3$;
-   $|x_2-x_1|+|y_2-y_1|=1, |x_4-x_3|+|y_4-y_3|=1$;
-   $(x_1,y_1) \neq (x_3,y_3)$ or $(x_2,y_2) \neq (x_4,y_4)$;
then:
$$
A_{x_1,y_1}+A_{x_2,y_2} \neq A_{x_3,y_3}+A_{x_4,y_4}
$$
For example, when $n=2$ and $m=3$, matrix $B$ is a valid solution, while matrix $C$ is not valid because $C_{1,1}+C_{2,1}=C_{1,2}+C_{1,3}$.
$$
B = \begin{bmatrix} 1 & 3 & 2 \\ 6 & 5 & 4 \end{bmatrix}, \quad C = \begin{bmatrix} 1 & 2 & 3 \\ 4 & 5 & 6 \end{bmatrix}
$$
Given $n$ and $m$, can all the conditions above be satisfied? If so, output a valid solution.
$^{\dagger}$ A permutation of length $n$ is an array consisting of $n$ distinct integers from $1$ to $n$ in arbitrary order. For example, $[2,3,1,5,4]$ is a permutation, but $[1,2,2]$ is not a permutation ($2$ appears twice in the array), and $[1,3,4]$ is also not a permutation ($n=3$ but there is a $4$ in the array).

**Input**
Each test file contains multiple test cases. The first line contains the number of test cases $T$ ($1 \leq T \leq 10^4$). The description of the test cases follows.
The first line contains two integers $n,m$ ($1 \leq n,m \leq 1000$).
For each test file, it is guaranteed that the sum of $n \times m$ over all test cases does not exceed $10^6$.

**Output**
For each test case, output on the first line whether a valid solution exists. If there is a valid solution, output "Yes"; otherwise, output "No". You can output the answer in any case (upper or lower). For example, the strings "yEs", "yes", "Yes", and "YES" will be recognized as positive responses.
If a valid solution exists, you must also output $n$ lines, each containing $m$ integers. The $j$\-th number on the $i$\-th line represents the number at row $i$ and column $j$ in the matrix. You must make sure that the output numbers form a permutation of length $n \times m$. If there are multiple solutions, you may print any of them.

Example Input1：
1 1
Example Output1：
yEs
1
Example Input2：
2 3
Example Output2：
YES
1 3 2
6 5 4
## Solution


def is_valid_solution(n, m):
    # A valid solution exists if and only if (n * m) is even or (n * m) == 1
    return (n * m) % 2 == 0 or n * m == 1

def construct_matrix(n, m):
    matrix = [[0] * m for _ in range(n)]
    k = 1
    for i in range(n):
        for j in range(m):
            if (i + j) % 2 == 0:
                matrix[i][j] = k
                k += 1
    for i in range(n):
        for j in range(m):
            if (i + j) % 2 == 1:
                matrix[i][j] = k
                k += 1
    return matrix

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))

def solve(n, m):
    if is_valid_solution(n, m):
        print("YES")
        matrix = construct_matrix(n, m)
        print_matrix(matrix)
    else:
        print("NO")

# Reading input
import sys
input = sys.stdin.read
data = input().split()

T = int(data[0])
index = 1
for _ in range(T):
    n = int(data[index])
    m = int(data[index + 1])
    index += 2
    solve(n, m)



## CODE


def is_valid_solution(n, m):
    # A valid solution exists if and only if (n * m) is even or (n * m) == 1
    return (n * m) % 2 == 0 or n * m == 1

def construct_matrix(n, m):
    matrix = [[0] * m for _ in range(n)]
    k = 1
    for i in range(n):
        for j in range(m):
            if (i + j) % 2 == 0:
                matrix[i][j] = k
                k += 1
    for i in range(n):
        for j in range(m):
            if (i + j) % 2 == 1:
                matrix[i][j] = k
                k += 1
    return matrix

def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))

def solve(n, m):
    if is_valid_solution(n, m):
        print("YES")
        matrix = construct_matrix(n, m)
        print_matrix(matrix)
    else:
        print("NO")

# Reading input
import sys
input = sys.stdin.read
data = input().split()

T = int(data[0])
index = 1
for _ in range(T):
    n = int(data[index])
    m = int(data[index + 1])
    index += 2
    solve(n, m)


### Explanation
The method used in the code is as follows:

1. **Check Validity**: A valid solution exists if and only if the total number of elements in the matrix (i.e., \( n \times m \)) is even or equal to 1. This is because for any two adjacent elements to have unique sums, the permutation must be arranged in a way that avoids repeated sums, which is only possible with even or single-element matrices.

2. **Construct Matrix**: If a valid solution exists, the matrix is constructed by filling it in a specific pattern:
   - Start with the smallest number and place it in positions where the sum of the row and column indices is even.
   - Then, place the remaining numbers in positions where the sum of the row and column indices is odd.
   - This ensures that the sums of adjacent elements are unique.

3. **Output**: The solution is printed as "YES" followed by the matrix if a valid solution exists. If not, "NO" is printed.

This approach ensures that the matrix meets the given conditions and provides a valid solution if one exists.
## Token
[538, 931, 1469]
 ### 

