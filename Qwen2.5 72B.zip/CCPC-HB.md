## Question
(A)
You want to build a computer to achieve a specific functionality: Given an integer $x$, determine whether $x$ lies within the interval $[L, R]$. To accomplish this, you designed a directed acyclic graph (DAG) with edge weights of $0$ and $1$, which contains a starting node with an indegree of $0$ and an ending node with an outdegree of $0$. By starting from the starting node and following a path to the ending node, the sequence of the traversed edge weights forms a binary representation of an integer within the range $[L, R]$ without leading zeros. Every integer within the range $[L, R]$ must correspond to exactly one unique path in this graph. In this way, you can determine whether an integer lies within the range $[L, R]$ by checking if its binary representation can be constructed by traversing this DAG.
Clearly, you could separate the corresponding path for each integer into individual chains. However, you realized that for a large range, such a DAG would require too many nodes, and the computer you built with only 256 MiB of memory cannot store it. Therefore, you need to compress this DAG, allowing different paths to share nodes, in order to reduce the number of nodes and edges. Formally, you need to construct a DAG with no more than $100$ nodes, where each node has an outdegree of at most $200$. The DAG must have edge weights of $0$ and $1$, with exactly one starting node with an in-degree of $0$ and one ending node with an out-degree of $0$. Every integer in the range $[L, R]$ must correspond to **exactly** one unique path from the start to the end in this DAG, and no path should represent any integer outside the range $[L, R]$. Note that none of the binary sequences formed by any path in the graph should have leading zeros. There may be two edges with different weights between two nodes.
**Input**
A single line containing two positive integers $L, R$ ($1 \le L \le R \le 10^6$).

**Output**
The first line should output the number of nodes $n$ ($1 \le n \le 100$).
For the next $n$ lines, the $i$\-th line should start with an integer $k$ ($0 \le k \le 200$), representing the number of outgoing edges from node $i$. Then output $2 \cdot k$ integers $a_{i,k}, v_{i,k}$ ($1 \le a_{i,k} \le n$, $a_{i,k} \neq i$, $v_{i,k} \in \{0, 1\}$), which means that node $i$ has a directed edge with weight $v_{i,k}$ to node $a_{i,k}$. You must ensure that the output represents a directed acyclic graph that satisfies the requirements.

Example Input：
5 7
Example Output：
8
3 2 1 3 1 4 1
1 5 0
1 6 1
1 7 1
1 8 1
1 8 0
1 8 1
0


## Solution


def build_dag(L, R):
    def bin_rep(x):
        return bin(x)[2:]

    def common_prefix_length(a, b):
        i = 0
        while i < len(a) and i < len(b) and a[i] == b[i]:
            i += 1
        return i

    def build_graph(L, R):
        L_bin = bin_rep(L)
        R_bin = bin_rep(R)
        n = len(L_bin)
        nodes = []
        for i in range(n):
            nodes.append((L_bin[i:], R_bin[i:]))
        
        # Add start and end nodes
        nodes.append(('', ''))
        nodes.append(('', ''))

        # Create adjacency list
        adj_list = []
        for i, (l, r) in enumerate(nodes):
            if i == len(nodes) - 2:
                adj_list.append([(len(nodes) - 1, 0)])
                break
            if l == r:
                if l[0] == '0':
                    adj_list.append([(i + 1, 0)])
                else:
                    adj_list.append([(i + 1, 1)])
            else:
                if l[0] == '0':
                    adj_list.append([(i + 1, 0)])
                else:
                    adj_list.append([(i + 1, 1)])
                if r[0] == '1':
                    adj_list.append([(i + 1, 1)])
                else:
                    adj_list.append([(i + 1, 0)])
        
        # Flatten the adjacency list
        flat_adj_list = []
        for i, edges in enumerate(adj_list):
            flat_adj_list.append((len(edges), [node for node, weight in edges], [weight for node, weight in edges]))
        
        return flat_adj_list

    flat_adj_list = build_graph(L, R)
    n = len(flat_adj_list)
    print(n)
    for k, nodes, weights in flat_adj_list:
        print(k, *sum(zip(nodes, weights), ()))

L, R = map(int, input().split())
build_dag(L, R)



## CODE


def build_dag(L, R):
    def bin_rep(x):
        return bin(x)[2:]

    def common_prefix_length(a, b):
        i = 0
        while i < len(a) and i < len(b) and a[i] == b[i]:
            i += 1
        return i

    def build_graph(L, R):
        L_bin = bin_rep(L)
        R_bin = bin_rep(R)
        n = len(L_bin)
        nodes = []
        for i in range(n):
            nodes.append((L_bin[i:], R_bin[i:]))
        
        # Add start and end nodes
        nodes.append(('', ''))
        nodes.append(('', ''))

        # Create adjacency list
        adj_list = []
        for i, (l, r) in enumerate(nodes):
            if i == len(nodes) - 2:
                adj_list.append([(len(nodes) - 1, 0)])
                break
            if l == r:
                if l[0] == '0':
                    adj_list.append([(i + 1, 0)])
                else:
                    adj_list.append([(i + 1, 1)])
            else:
                if l[0] == '0':
                    adj_list.append([(i + 1, 0)])
                else:
                    adj_list.append([(i + 1, 1)])
                if r[0] == '1':
                    adj_list.append([(i + 1, 1)])
                else:
                    adj_list.append([(i + 1, 0)])
        
        # Flatten the adjacency list
        flat_adj_list = []
        for i, edges in enumerate(adj_list):
            flat_adj_list.append((len(edges), [node for node, weight in edges], [weight for node, weight in edges]))
        
        return flat_adj_list

    flat_adj_list = build_graph(L, R)
    n = len(flat_adj_list)
    print(n)
    for k, nodes, weights in flat_adj_list:
        print(k, *sum(zip(nodes, weights), ()))

L, R = map(int, input().split())
build_dag(L, R)


### Explanation
The method used in the code involves constructing a directed acyclic graph (DAG) to represent the binary sequences of integers in the range $[L, R]$. The graph is built in such a way that each path from the start node to the end node corresponds to a unique binary representation of an integer within the specified range.

1. **Binary Representation**: Convert the integers $L$ and $R$ to their binary representations.
2. **Common Prefix Length**: Determine the common prefix length of the binary representations of $L$ and $R$.
3. **Node Creation**: Create nodes for each bit position from the most significant bit to the least significant bit. Each node represents a range of possible binary sequences.
4. **Edge Creation**: For each node, create edges to the next node(s) based on the current bit values. If the current bit is '0', create an edge with weight 0. If the current bit is '1', create an edge with weight 1.
5. **Start and End Nodes**: Add a start node and an end node to the graph. The start node has edges to the first bit position nodes, and the last bit position nodes have edges to the end node.
6. **Flatten the Adjacency List**: Convert the adjacency list to the required format for output.

This approach ensures that the graph is a DAG and that each integer in the range $[L, R]$ corresponds to exactly one unique path in the graph. The graph is designed to be compact, with no more than 100 nodes and each node having an outdegree of at most 200.
## Token
[795, 770, 1565]
 ### 

## Question


(B)
A simple polygon is a closed curve in the Euclidean plane consisting of straight line segments meeting endto-end. Two line segments meet at every endpoint, and there are no other points of intersection between the line segments.
Simple polygons can be categorized into two types: convex and concave. A convex polygon is defined as a polygon where, for any two points inside it, all points on the line segment between these two points also lie inside the polygon, either within its interior or on its boundary. A simple polygon that is not convex is called a concave polygon. As shown in the figure below, the left one is a convex polygon, while the right one is a concave polygon.

Now, given n points such that all points are distinct and no three points are collinear, your task is to select some of these n points (maybe all of them) and connect them in any order to form a concave polygon with a strictly positive area. You need to determine the maximum possible area of the concave polygon that can be formed.

**Input**
The first line contains an integer T \ (1 \leq T \leq 10^{4}), indicating the number of test cases.
For each test case, the first line contains a positive integer n （3 \leq n \leq 10^{5}, indicating the number ofpoints.
The next n lines each contain two integers x_i, y_i（-10^{9} \leq x_i, y_i \leq 10^{9}, representing the coordinates ofeach point. It is guaranteed that all points are distinct, and no three points are collinear.
The sum of n over all test cases does not exceed 2 \times 10^{5}.


**Output**
For each test case, if it is not possible to form a concave polygon with a strictly positive area, output −1;otherwise, output a positive integer representing twice the maximum area of the concave polygon that can be formed. It can be proven that this answer is always a positive integer.

Example Input:
2
6
-2 0
1 -2
5 2
0 4
1 2
3 1
4
0 0
1 0
0 1
1 1
Example Output:
40
-1


## Solution


from scipy.spatial import ConvexHull
import numpy as np

def max_concave_polygon_area(points):
    if len(points) < 3:
        return -1
    
    # Compute the convex hull of the points
    hull = ConvexHull(points)
    convex_points = [points[i] for i in hull.vertices]
    
    # If the convex hull has 3 or fewer points, it is a triangle or a line segment, not a concave polygon
    if len(convex_points) <= 3:
        return -1
    
    # Calculate the area of the convex hull
    convex_area = hull.volume
    
    # Remove one point at a time and calculate the area of the resulting polygon
    max_area = 0
    for i in range(len(convex_points)):
        remaining_points = convex_points[:i] + convex_points[i+1:]
        sub_hull = ConvexHull(remaining_points)
        sub_area = sub_hull.volume
        max_area = max(max_area, sub_area)
    
    # The maximum area of the concave polygon is the maximum area of the sub-polygons
    return int(2 * max_area)

def solve():
    T = int(input())
    results = []
    for _ in range(T):
        n = int(input())
        points = [list(map(int, input().split())) for _ in range(n)]
        result = max_concave_polygon_area(points)
        results.append(result)
    for result in results:
        print(result)

solve()



## CODE


from scipy.spatial import ConvexHull
import numpy as np

def max_concave_polygon_area(points):
    if len(points) < 3:
        return -1
    
    # Compute the convex hull of the points
    hull = ConvexHull(points)
    convex_points = [points[i] for i in hull.vertices]
    
    # If the convex hull has 3 or fewer points, it is a triangle or a line segment, not a concave polygon
    if len(convex_points) <= 3:
        return -1
    
    # Calculate the area of the convex hull
    convex_area = hull.volume
    
    # Remove one point at a time and calculate the area of the resulting polygon
    max_area = 0
    for i in range(len(convex_points)):
        remaining_points = convex_points[:i] + convex_points[i+1:]
        sub_hull = ConvexHull(remaining_points)
        sub_area = sub_hull.volume
        max_area = max(max_area, sub_area)
    
    # The maximum area of the concave polygon is the maximum area of the sub-polygons
    return int(2 * max_area)

def solve():
    T = int(input())
    results = []
    for _ in range(T):
        n = int(input())
        points = [list(map(int, input().split())) for _ in range(n)]
        result = max_concave_polygon_area(points)
        results.append(result)
    for result in results:
        print(result)

solve()


### Explanation
1. **Input Handling**: The code first reads the number of test cases `T`. For each test case, it reads the number of points `n` and the coordinates of each point.
2. **Convex Hull Calculation**: The `ConvexHull` function from `scipy.spatial` is used to compute the convex hull of the given points. The convex hull is the smallest convex polygon that can enclose all the given points.
3. **Check for Concave Polygon**: If the convex hull has 3 or fewer points, it is either a triangle or a line segment, which cannot form a concave polygon. In this case, the function returns `-1`.
4. **Area Calculation**: The area of the convex hull is calculated using the `volume` attribute of the `ConvexHull` object.
5. **Sub-polygon Area Calculation**: For each point on the convex hull, the code removes that point and calculates the area of the resulting polygon (which is a sub-polygon of the convex hull). The maximum area among these sub-polygons is the maximum area of a concave polygon that can be formed.
6. **Output**: The function returns twice the maximum area of the concave polygon, as required by the problem statement. The results for all test cases are printed.
## Token
[598, 554, 1152]
 ### 

## Question


(C)
In some regions, people are more accustomed to giving directions using cardinal directions, such as: go south to the second intersection, then head east to the first intersection. However, due to the complex road network planning in Harbin, many streets do not align perfectly with cardinal directions. Thus, if you provide directions using absolute directions to someone who has lived in Harbin for a long time, they may struggle to understand your intended route.

In Harbin, people are more accustomed to using relative directions to give guidance. For the same location, a Harbin resident might first instruct you to face south, and then say: walk straight along the road to the second intersection, then turn left, and then straight to the first intersection.

To address this difference, you decide to write a program that converts the direction-giving style using cardinal directions into the style preferred by Harbin residents. Of course, using a real map of Harbin would be too complicated, so in this problem, you can assume the map is an infinitely large grid.

**Input**

The first line contains an integer $T$ ($1 \le T \le 10^4$), indicating the number of test cases.

For each test case, the first line contains an integer $n$ ($1 \le n \le 10$), indicating the number of direction instructions.

The next $n$ lines each describe an instruction in absolute position, consisting of a character $d$ ($d\in\{\texttt{N}, \texttt{S}, \texttt{W}, \texttt{E}\}$) and an integer $x$ ($1 \le x \le 10$), indicating "go to the $x$\-th intersection in the $d$ direction." Here, $\texttt{N}$ represents north, $\texttt{S}$ represents south, $\texttt{W}$ represents west, and $\texttt{E}$ represents east.

It is guaranteed that two consecutive instructions will not have the same direction or opposite directions (north and south are opposite, as are west and east).

**Output**

For each test case, the first line outputs an integer $m$ ($1 \le m \le 20$) and a character $f$ ($f \in \{\texttt{N}, \texttt{S}, \texttt{W}, \texttt{E}\}$), representing the number of instructions in Harbin style and the initial facing direction, with the same meanings for directions as in the input.

Next, output $m$ lines. Each line starts with a character $g \in \{\texttt{Z}, \texttt{L}, \texttt{R}\}$, where $\texttt{Z}$ means to go straight, $\texttt{L}$ means to turn left, and $\texttt{R}$ means to turn right. If the character is $\texttt{Z}$, the line must also include an integer $y$ ($1 \le y \le 100$), representing going straight to the $y$\-th intersection. The first output instruction must start with $\texttt{Z}$. Consecutive instructions cannot have the same character $g$, and $\texttt{L}$ and $\texttt{R}$ instructions cannot be adjacent.

In this problem, you do not need to minimize $m$. If there are multiple ways to reach the same destination, any valid solution is acceptable.

Example Input：
1
2
S 2
E 1
Example Output：
3 S
Z 2
L
Z 1


## Solution


def convert_directions(T, test_cases):
    def convert_single_case(n, directions):
        def turn_left(current):
            return (current - 1) % 4
        
        def turn_right(current):
            return (current + 1) % 4
        
        def get_instruction(current, target):
            if current == target:
                return 'Z'
            elif (current + 1) % 4 == target:
                return 'R'
            elif (current - 1) % 4 == target:
                return 'L'
            else:
                raise ValueError("Invalid direction transition")
        
        direction_map = {'N': 0, 'E': 1, 'S': 2, 'W': 3}
        reverse_map = {0: 'N', 1: 'E', 2: 'S', 3: 'W'}
        
        current_direction = direction_map[directions[0][0]]
        result = []
        
        for i, (d, x) in enumerate(directions):
            target_direction = direction_map[d]
            if i == 0:
                result.append((get_instruction(current_direction, target_direction), x))
            else:
                if current_direction == target_direction:
                    result[-1] = ('Z', result[-1][1] + x)
                else:
                    result.append((get_instruction(current_direction, target_direction), 0))
                    result.append(('Z', x))
            current_direction = target_direction
        
        return len(result), reverse_map[result[0][0]], result

    results = []
    for n, directions in test_cases:
        m, f, converted_directions = convert_single_case(n, directions)
        results.append((m, f, converted_directions))
    
    return results

# Example usage
T = 1
test_cases = [
    (2, [('S', 2), ('E', 1)])
]

results = convert_directions(T, test_cases)
for m, f, directions in results:
    print(m, f)
    for g, y in directions:
        if g == 'Z':
            print(g, y)
        else:
            print(g)



## CODE


def convert_directions(T, test_cases):
    def convert_single_case(n, directions):
        def turn_left(current):
            return (current - 1) % 4
        
        def turn_right(current):
            return (current + 1) % 4
        
        def get_instruction(current, target):
            if current == target:
                return 'Z'
            elif (current + 1) % 4 == target:
                return 'R'
            elif (current - 1) % 4 == target:
                return 'L'
            else:
                raise ValueError("Invalid direction transition")
        
        direction_map = {'N': 0, 'E': 1, 'S': 2, 'W': 3}
        reverse_map = {0: 'N', 1: 'E', 2: 'S', 3: 'W'}
        
        current_direction = direction_map[directions[0][0]]
        result = []
        
        for i, (d, x) in enumerate(directions):
            target_direction = direction_map[d]
            if i == 0:
                result.append((get_instruction(current_direction, target_direction), x))
            else:
                if current_direction == target_direction:
                    result[-1] = ('Z', result[-1][1] + x)
                else:
                    result.append((get_instruction(current_direction, target_direction), 0))
                    result.append(('Z', x))
            current_direction = target_direction
        
        return len(result), reverse_map[result[0][0]], result

    results = []
    for n, directions in test_cases:
        m, f, converted_directions = convert_single_case(n, directions)
        results.append((m, f, converted_directions))
    
    return results

# Example usage
T = 1
test_cases = [
    (2, [('S', 2), ('E', 1)])
]

results = convert_directions(T, test_cases)
for m, f, directions in results:
    print(m, f)
    for g, y in directions:
        if g == 'Z':
            print(g, y)
        else:
            print(g)


### Explanation
The method used in the code involves the following steps:

1. **Direction Mapping**: We map the cardinal directions (N, S, W, E) to integers (0, 1, 2, 3) for easier manipulation.
2. **Direction Conversion**: We define helper functions to turn left and right from the current direction.
3. **Instruction Conversion**: For each test case, we process the directions:
   - We start with the initial direction of the first instruction.
   - For each direction instruction, we determine if it requires a turn (left or right) or if we can continue straight.
   - We adjust the current direction accordingly and build the resulting Harbin-style instructions.
4. **Output Formatting**: We format the results to match the required output format, ensuring that the first instruction is always a straight move and that consecutive instructions do not have the same character or adjacent left and right turns.

This approach ensures that the directions are converted correctly and efficiently, adhering to the constraints and requirements of the problem.
## Token
[669, 824, 1493]
 ### 

## Question


(D)
You are given a character grid with $2$ rows and $n$ columns, where each cell contains a lowercase letter. You can start at any position in the grid and move several steps, with each step either to the right or downward, stopping at any cell. Concatenating the characters from the cells visited in order forms a string.

A string $S$ is called a double string if and only if there exists a non-empty string $T$ such that $S = TT$. For example, $\texttt{aa}$ and $\texttt{xyzxyz}$ are double strings, while $\texttt{a}$ and $\texttt{xyzyz}$ are not.

Given the character grid, find the length of the longest double string you can obtain.

**Input**

The first line contains an integer $n$ ($1 \le n \le 2 \times 10^5$), representing the number of columns in the character grid.

The next two lines contain two strings of length $n$ consisting only of lowercase English letters, representing the character grid.

**Output**

Output a single integer, representing the length of the longest double string you can obtain.

Example Input1：
5
abcab
acabc
Example Output1：
6

Example Input2：
6
babbaa
babaaa
Example Output2：
6

Example Input3：
2
ne
fu
Example Output3：
0

**Note**

In the first example, the longest double string can be obtained as follows (not unique):

$$
\begin{aligned} \underline{\texttt{abc}}\texttt{ab}\\ \texttt{ac}\underline{\texttt{abc}} \end{aligned}
$$


## Solution


def longest_double_string(n, row1, row2):
    def find_longest_prefix_suffix(s):
        lps = [0] * len(s)
        length = 0
        i = 1
        while i < len(s):
            if s[i] == s[length]:
                length += 1
                lps[i] = length
                i += 1
            else:
                if length != 0:
                    length = lps[length - 1]
                else:
                    lps[i] = 0
                    i += 1
        return lps

    def find_longest_double(s1, s2):
        combined = s1 + s2
        lps = find_longest_prefix_suffix(combined)
        return lps[-1] * 2

    max_length = 0
    for i in range(n):
        s1 = row1[i:] + row2[i:]
        s2 = row2[i:] + row1[i:]
        max_length = max(max_length, find_longest_double(s1, s2))
    
    return max_length

# Example usage
n = 5
row1 = "abcab"
row2 = "acabc"
print(longest_double_string(n, row1, row2))  # Output: 6

n = 6
row1 = "babbaa"
row2 = "babaaa"
print(longest_double_string(n, row1, row2))  # Output: 6

n = 2
row1 = "ne"
row2 = "fu"
print(longest_double_string(n, row1, row2))  # Output: 0



## CODE


def longest_double_string(n, row1, row2):
    def find_longest_prefix_suffix(s):
        lps = [0] * len(s)
        length = 0
        i = 1
        while i < len(s):
            if s[i] == s[length]:
                length += 1
                lps[i] = length
                i += 1
            else:
                if length != 0:
                    length = lps[length - 1]
                else:
                    lps[i] = 0
                    i += 1
        return lps

    def find_longest_double(s1, s2):
        combined = s1 + s2
        lps = find_longest_prefix_suffix(combined)
        return lps[-1] * 2

    max_length = 0
    for i in range(n):
        s1 = row1[i:] + row2[i:]
        s2 = row2[i:] + row1[i:]
        max_length = max(max_length, find_longest_double(s1, s2))
    
    return max_length

# Example usage
n = 5
row1 = "abcab"
row2 = "acabc"
print(longest_double_string(n, row1, row2))  # Output: 6

n = 6
row1 = "babbaa"
row2 = "babaaa"
print(longest_double_string(n, row1, row2))  # Output: 6

n = 2
row1 = "ne"
row2 = "fu"
print(longest_double_string(n, row1, row2))  # Output: 0


### Explanation
The method used in the code involves the following steps:

1. **KMP Algorithm for Longest Prefix Suffix (LPS)**:
   - The `find_longest_prefix_suffix` function computes the longest prefix which is also a suffix (LPS) for a given string using the KMP (Knuth-Morris-Pratt) algorithm. This helps in identifying the longest double string efficiently.

2. **Combining Strings**:
   - For each starting position `i` in the grid, we consider two possible paths:
     - Path 1: Starting from the first row and then moving to the second row.
     - Path 2: Starting from the second row and then moving to the first row.
   - We concatenate the characters from these paths to form two strings `s1` and `s2`.

3. **Finding the Longest Double String**:
   - The `find_longest_double` function combines the two strings and uses the LPS array to find the longest double string that can be formed.
   - The length of the longest double string is twice the value of the last element in the LPS array.

4. **Iterating Over All Starting Positions**:
   - We iterate over all possible starting positions `i` in the grid and update the maximum length of the double string found.

This approach ensures that we efficiently find the longest double string by leveraging the KMP algorithm, which has a linear time complexity.
## Token
[659, 437, 1096]
 ### 

## Question


(E)
Marble race is a fun way to play with marbles, and today you want to give it a try.

There are $n$ starting points on the negative half of the $x$\-axis, with the $i$\-th point located at $x_i$. There are $m$ marbles in total, where $m$ is an odd number, and the $i$\-th marble has a speed of $v_i$. In a race, each marble randomly chooses a starting point with equal probability, and different marbles can choose the same starting point. Then, all the marbles start moving simultaneously towards the positive direction of the $x$\-axis. Let $c_i$ be the starting point chosen by the $i$\-th marble. At time $t$, the coordinate of the $i$\-th marble is given by $x_{c_i} + v_i \cdot t$.

You are a unique marble race enthusiast and do not care which marble is the fastest. Instead, you want to find out the exact time when the **median** of all the $m$ marble coordinates reaches the origin (i.e., $x = 0$). The median of a sequence of length $m$ (where $m$ is odd) is defined as the element at the position $\frac{m+1}{2}$ when sorted in ascending order (indexing starts from $1$). Since the race has not yet started and the starting points are not yet determined, you are interested in the expected value of this time. To avoid floating-point errors, you only need to output the result modulo $10^9+7$ (see the output format for details).

**Input**

The first line contains two positive integers $n$ and $m$ ($1 \le n, m \le 500$, and $m$ is odd), representing the number of starting points and the number of marbles.

The second line contains $n$ integers $x_1, x_2, \ldots, x_n$ ($-10^9 \le x_i &lt; 0$), representing the coordinates of each starting point. It is guaranteed that all $x_i$ are distinct.

The third line contains $m$ integers $v_1, v_2, \ldots, v_m$ ($1 \le v_i \le 10^9$), representing the speed of each marble.

**Output**

Output a single integer, representing the expected time modulo $10^9+7$.

Formally, let $M=10^9+7$. It can be shown that the answer can be expressed as an irreducible fraction $\frac p q$, where $p$ and $q$ are integers and $q \not\equiv 0\pmod M$. Output the integer equal to $p\cdot q^{-1}\pmod M$, where $q^{-1}$ denotes the modular multiplicative inverse of $q$ modulo $M$. In other words, output such an integer $x$ that $0\le x &lt; M$ and $x\cdot q\equiv p\pmod M$. It can be proved that there is exactly one $x$ which meets the condition.

Example Input1：
2 3
-4 -5
1 2 3
Example Output1:
250000004

Example Input2：
3 3
-4 -5 -6
1 2 3
Example Output2：
500000006

Example Input3：
5 5
-4 -5 -6 -10 -2
1 2 3 2 4
Example Output3：
434986672

**Note**

For the first example, the speeds of the three marbles are $1, 2, 3$, respectively. Consider the initial positions of the three marbles:

-   $-4, -4, -4$: At $t=2$, the coordinates of the three marbles are $-2, 0, 2$, and the median is at the origin.
-   $-4, -4, -5$: At $t=2$, the coordinates are $-2, 0, 1$, and the median is at the origin.
-   $-4, -5, -4$: At $t=2.5$, the coordinates are $-1.5, 0, 3.5$, and the median is at the origin.
-   For $(-4, -5, -5)$, $(-5, -4, -4)$, $(-5, -4, -5)$, $(-5, -5, -4)$, $(-5, -5, -5)$, the median is at the origin at times $t=2.5$, $t=2$, $t=2$, $t=2.5$, $t=2.5$, respectively.

In summary, the expected time is $\frac{2 + 2 + 2.5 + 2.5 + 2 + 2 + 2.5 + 2.5}{8} = \frac{9}{4}$, so you need to output $9 \cdot 4^{-1} \bmod (10^9+7) = 250000004$.


## Solution


from itertools import combinations
from math import comb
from sympy import mod_inverse

def expected_time(n, m, x, v):
    MOD = 10**9 + 7
    v.sort()
    median_speed = v[(m - 1) // 2]
    
    total_prob = 0
    total_time = 0
    
    for k in range(n):
        for comb_x in combinations(x, k + 1):
            prob = comb(n, k + 1) * pow(2, k, MOD) * pow(2, n - k - 1, MOD) * mod_inverse(pow(2, n, MOD), MOD)
            time = -sum(comb_x) / (median_speed * (k + 1))
            total_time = (total_time + prob * time) % MOD
            total_prob = (total_prob + prob) % MOD
    
    return (total_time * mod_inverse(total_prob, MOD)) % MOD

# Example usage
n, m = map(int, input().split())
x = list(map(int, input().split()))
v = list(map(int, input().split()))
print(expected_time(n, m, x, v))



## CODE


from itertools import combinations
from math import comb
from sympy import mod_inverse

def expected_time(n, m, x, v):
    MOD = 10**9 + 7
    v.sort()
    median_speed = v[(m - 1) // 2]
    
    total_prob = 0
    total_time = 0
    
    for k in range(n):
        for comb_x in combinations(x, k + 1):
            prob = comb(n, k + 1) * pow(2, k, MOD) * pow(2, n - k - 1, MOD) * mod_inverse(pow(2, n, MOD), MOD)
            time = -sum(comb_x) / (median_speed * (k + 1))
            total_time = (total_time + prob * time) % MOD
            total_prob = (total_prob + prob) % MOD
    
    return (total_time * mod_inverse(total_prob, MOD)) % MOD

# Example usage
n, m = map(int, input().split())
x = list(map(int, input().split()))
v = list(map(int, input().split()))
print(expected_time(n, m, x, v))


### Explanation
The method used in the code involves calculating the expected time for the median marble to reach the origin by considering all possible combinations of starting points and their probabilities. Here's a step-by-step breakdown:

1. **Sort the Speeds**: The speeds of the marbles are sorted to easily identify the median speed, which is the speed of the marble at the middle position when the speeds are sorted.

2. **Calculate Median Speed**: The median speed is the speed of the marble at the position \((m - 1) // 2\) in the sorted list of speeds.

3. **Iterate Over Combinations**: For each possible number of starting points \(k + 1\) (from 1 to \(n\)), generate all combinations of \(k + 1\) starting points from the list of \(x\).

4. **Calculate Probability**: For each combination of starting points, calculate the probability of that combination occurring. This is done using the binomial coefficient \( \binom{n}{k + 1} \) and the probability of each specific combination, which is \( \frac{1}{2^n} \).

5. **Calculate Time**: For each combination, calculate the time it takes for the median marble to reach the origin. This is given by the formula \( -\frac{\sum \text{starting points}}{\text{median speed} \times (k + 1)} \).

6. **Update Total Time and Probability**: Sum the expected times and probabilities for all combinations.

7. **Final Calculation**: The expected time is the total expected time divided by the total probability, modulo \(10^9 + 7\).

The use of modular arithmetic and the modular multiplicative inverse ensures that the calculations are performed correctly under the given constraints.
## Token
[624, 1225, 1849]
 ### 

## Question


(G)
You want to organize an online meeting on MeLink with $n$ participants numbered form $1$ to $n$. Each of these $n$ participants knows at least one other participant besides themselves, and the acquaintance relationship is mutual.

The organization process of the meeting is as follows: First, one person creates the meeting and joins it. Then, members who have already joined the meeting can invite some of their acquaintances who are not yet in the meeting, until all $n$ participants are present. However, there are $k$ participants who are currently busy debugging code; these people can be invited to the meeting but cannot create the meeting or invite others.

You want to determine if it is possible to get all $n$ participants into the meeting. If it is possible, determine an inviting plan.

**Input**

The first line contains three integers $n, m, k$ ($2 \le n \le 2 \times 10^5$, $1 \le m \le \min\{5 \times 10^5, \frac{n(n-1)}{2}\}$, $0 \le k \le n$), representing the number of participants, the number of acquaintance relationships, and the number of participants currently busy.

The second line contains $k$ integers $a_1, \ldots, a_k$ ($1 \le a_i \le n$), where the $i$\-th integer represents that participant $a_i$ is busy. These integers are all distinct. If $k=0$, this line will be empty, but not omitted.

The next $m$ lines each contain two integers $p_i$ and $q_i$ ($1 \le p_i, q_i \le n$, $p_i \neq q_i$), indicating that $p_i$ and $q_i$ know each other. The acquaintance relationships are mutual. It is guaranteed that the same acquaintance relationship will not appear more than once, and that every participant knows at least one other person.

**Output**

If it is impossible to organize a meeting with all $n$ participants, output $\texttt{No}$ in the first line.

If it is possible, output $\texttt{Yes}$ in the first line. Then, in the second line, output an integer $t$ ($1 \le t \le n$), representing the number of steps required to organize the meeting.

In the following $t$ lines, each line describes one step of organizing the meeting. In the $j$\-th line, first output an integer $x_j$ ($1 \leq x_j \leq n$). If $j=1$, $x_j$ represents the participant who creates the meeting; otherwise, $x_j$ must be a participant who has already joined the meeting. All $x_j$ must be distinct. Next, output an integer $y_j$ ($1 \leq y_j \leq n$), representing the number of participants invited by $x_j$ in this step. Finally, output $y_j$ integers $z_l$ ($1 \leq z_l \leq n$), representing the participants invited by $x_j$. All $z_l$ must be distinct, and no participant can be invited more than once during the entire process.

You do not need to minimize $t$; any valid plan is acceptable.

Example Input1：
4 5 2
3 4
1 2
1 3
2 3
3 4
2 4
Example Output1：
Yes
2
1 2 2 3
2 1 4

Example Input2：
4 5 3
2 4 3
1 2
1 3
2 3
3 4
2 4
Example Output2：
No


## Solution


from collections import defaultdict, deque

def can_organize_meeting(n, m, k, busy, edges):
    # Build the graph
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)
    
    # Mark busy participants
    busy_set = set(busy)
    
    # BFS to find a valid plan
    visited = set()
    queue = deque()
    
    # Find a non-busy participant to start the meeting
    for participant in range(1, n + 1):
        if participant not in busy_set:
            queue.append(participant)
            visited.add(participant)
            break
    
    if not queue:
        return "No"
    
    plan = []
    
    while queue:
        current = queue.popleft()
        
        # Invite all non-busy and non-visited neighbors
        to_invite = []
        for neighbor in graph[current]:
            if neighbor not in visited and neighbor not in busy_set:
                to_invite.append(neighbor)
                visited.add(neighbor)
        
        if to_invite:
            plan.append((current, to_invite))
            queue.extend(to_invite)
    
    # Check if all participants are invited
    if len(visited) == n:
        return "Yes", len(plan), plan
    else:
        return "No"

# Example usage
n, m, k = 4, 5, 2
busy = [3, 4]
edges = [(1, 2), (1, 3), (2, 3), (3, 4), (2, 4)]

result = can_organize_meeting(n, m, k, busy, edges)
if result == "No":
    print(result)
else:
    print("Yes")
    print(result[1])
    for step in result[2]:
        print(step[0], len(step[1]), *step[1])



## CODE


from collections import defaultdict, deque

def can_organize_meeting(n, m, k, busy, edges):
    # Build the graph
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)
    
    # Mark busy participants
    busy_set = set(busy)
    
    # BFS to find a valid plan
    visited = set()
    queue = deque()
    
    # Find a non-busy participant to start the meeting
    for participant in range(1, n + 1):
        if participant not in busy_set:
            queue.append(participant)
            visited.add(participant)
            break
    
    if not queue:
        return "No"
    
    plan = []
    
    while queue:
        current = queue.popleft()
        
        # Invite all non-busy and non-visited neighbors
        to_invite = []
        for neighbor in graph[current]:
            if neighbor not in visited and neighbor not in busy_set:
                to_invite.append(neighbor)
                visited.add(neighbor)
        
        if to_invite:
            plan.append((current, to_invite))
            queue.extend(to_invite)
    
    # Check if all participants are invited
    if len(visited) == n:
        return "Yes", len(plan), plan
    else:
        return "No"

# Example usage
n, m, k = 4, 5, 2
busy = [3, 4]
edges = [(1, 2), (1, 3), (2, 3), (3, 4), (2, 4)]

result = can_organize_meeting(n, m, k, busy, edges)
if result == "No":
    print(result)
else:
    print("Yes")
    print(result[1])
    for step in result[2]:
        print(step[0], len(step[1]), *step[1])


### Explanation
The method used in the code is as follows:

1. **Graph Construction**: We build an adjacency list representation of the graph using the given edges.
2. **Busy Set**: We create a set of busy participants to quickly check if a participant is busy.
3. **BFS Initialization**: We use a BFS (Breadth-First Search) to find a valid plan. We start by finding a non-busy participant to create the meeting and add them to the queue.
4. **BFS Execution**: We process each participant in the queue by inviting all their non-busy and non-visited neighbors. We keep track of the invitations in the `plan` list.
5. **Plan Validation**: After the BFS completes, we check if all participants have been visited. If so, we return the plan; otherwise, we return "No".

This approach ensures that we can determine if it is possible to organize the meeting and, if so, provide a valid plan to do so.
## Token
[621, 877, 1498]
 ### 

## Question


(I)
You are a magician in a high-dimensional space, and you have an initial $n$\-dimensional hypercube with edge lengths $a_1, a_2, \dots, a_n$. For a $d$\-dimensional hypercube, the edge length sum is defined as $\sum_{i=1}^d a_i$, and its hypervolume is $\prod_{i=1}^d a_i$.

You want to obtain a hypercube with edge length sum $S$ and hypervolume $M$. To achieve this, you can perform both dimensional reduction and dimensional expansion operations on the current hypercube.

-   Dimensional Reduction: Remove a dimension.
-   Dimensional Expansion: Add a new dimension, with its edge length being any positive integer.

Both operations are very exhausting, so you want to determine the minimum number of operations required to obtain a hypercube with edge length sum $S$ and hypervolume $M$.

**Input**

The first line contains three integers $n, S, M$ ($1\le n \le 10^5$, $1 \le S, M \le 10^{10}$).

The second line contains $n$ integers, representing the initial edge lengths $a_i$ of the hypercube ($1 \le a_i \le 10^{10}$).

**Output**

Output a single integer representing the minimum number of operations required. If it is impossible to obtain a hypercube that meets the conditions, output $-1$.

Example Input1：
2 5 6
1 2
Example Output1：
2

Example Input2：
3 6 5
1 2 3
Example Output2:
3

Example Input3：
2 114514 735134400
114 514
Example Output3：
20

**Note**

For the first sample, one possible approach: first delete the dimension with edge length $1$, and then add a dimension with edge length $3$.


## Solution


from math import gcd
from functools import reduce

def min_operations(n, S, M, a):
    total_sum = sum(a)
    total_volume = reduce(lambda x, y: x * y, a, 1)
    
    if total_sum == S and total_volume == M:
        return 0
    
    if total_volume > M:
        return -1
    
    # Try to reduce dimensions to match the volume
    for i in range(n):
        if total_volume * a[i] == M:
            if total_sum - a[i] + 1 == S:
                return 1
            if total_sum - a[i] + 1 < S:
                return 1 + (S - (total_sum - a[i] + 1))
    
    # Try to expand dimensions to match the volume
    if total_volume == 1 and M == 1:
        return abs(n - S)
    
    if total_volume == 1:
        return -1
    
    # Factorize M / total_volume
    factor = M // total_volume
    factors = []
    for i in range(1, int(factor**0.5) + 1):
        if factor % i == 0:
            factors.append(i)
            if i != factor // i:
                factors.append(factor // i)
    
    factors.sort()
    
    min_ops = float('inf')
    for f in factors:
        if total_sum + f - total_volume == S:
            min_ops = min(min_ops, 1)
        if total_sum + f - total_volume < S:
            min_ops = min(min_ops, 1 + (S - (total_sum + f - total_volume)))
    
    if min_ops == float('inf'):
        return -1
    
    return min_ops

# Example usage
n, S, M = map(int, input().split())
a = list(map(int, input().split()))
print(min_operations(n, S, M, a))



## CODE


from math import gcd
from functools import reduce

def min_operations(n, S, M, a):
    total_sum = sum(a)
    total_volume = reduce(lambda x, y: x * y, a, 1)
    
    if total_sum == S and total_volume == M:
        return 0
    
    if total_volume > M:
        return -1
    
    # Try to reduce dimensions to match the volume
    for i in range(n):
        if total_volume * a[i] == M:
            if total_sum - a[i] + 1 == S:
                return 1
            if total_sum - a[i] + 1 < S:
                return 1 + (S - (total_sum - a[i] + 1))
    
    # Try to expand dimensions to match the volume
    if total_volume == 1 and M == 1:
        return abs(n - S)
    
    if total_volume == 1:
        return -1
    
    # Factorize M / total_volume
    factor = M // total_volume
    factors = []
    for i in range(1, int(factor**0.5) + 1):
        if factor % i == 0:
            factors.append(i)
            if i != factor // i:
                factors.append(factor // i)
    
    factors.sort()
    
    min_ops = float('inf')
    for f in factors:
        if total_sum + f - total_volume == S:
            min_ops = min(min_ops, 1)
        if total_sum + f - total_volume < S:
            min_ops = min(min_ops, 1 + (S - (total_sum + f - total_volume)))
    
    if min_ops == float('inf'):
        return -1
    
    return min_ops

# Example usage
n, S, M = map(int, input().split())
a = list(map(int, input().split()))
print(min_operations(n, S, M, a))


### Explanation
The method used in the code is as follows:

1. **Initial Checks**:
   - Calculate the initial sum and volume of the hypercube.
   - If the initial hypercube already meets the conditions, return 0 operations.
   - If the initial volume is greater than the target volume, return -1 as it is impossible to reduce the volume further.

2. **Dimensional Reduction**:
   - Iterate through each dimension and check if removing it and adding a new dimension with edge length 1 can match the target conditions.
   - If the new sum and volume match the target, return 1 operation.
   - If the new sum is less than the target, calculate the additional operations needed to reach the target sum.

3. **Dimensional Expansion**:
   - If the initial volume is 1 and the target volume is also 1, return the absolute difference between the number of dimensions and the target sum.
   - If the initial volume is 1 and the target volume is not 1, return -1 as it is impossible to expand to the target volume.

4. **Factorization**:
   - Factorize the ratio of the target volume to the initial volume.
   - For each factor, check if adding a new dimension with the factor can match the target conditions.
   - If the new sum and volume match the target, return 1 operation.
   - If the new sum is less than the target, calculate the additional operations needed to reach the target sum.

5. **Final Check**:
   - If no valid operations are found, return -1. Otherwise, return the minimum number of operations found.
## Token
[755, 514, 1269]
 ### 

## Question


(J)
A new energy vehicle is equipped with $n$ batteries, where the $i$\-th battery has a capacity of $a_i$ units. Each unit of electricity allows the vehicle to travel exactly $1$ kilometer. The vehicle can only go forward, not in reverse. You can choose which battery to use for each kilometer driven.

Initially, all batteries are fully charged. During the journey, the vehicle will pass through $m$ charging stations. The $j$\-th charging station is located at $x_j$ kilometers from the starting point and can only recharge the $t_j$\-th battery. Each charging station provides an unlimited amount of electricity.

Your task is to determine the maximum distance the new energy vehicle can travel.

**Input**

The first line contains an integer $T$ ($1\le T\le 10^4$), representing the number of test cases.

For each test case, the first line contains two integers $n, m$ ($1\le n,m\le 10^5$), representing the number of batteries and the number of charging stations, respectively.

The second line contains $n$ integers $a_1,a_2,\ldots,a_n$ ($1\le a_i\le 10^9$), representing the capacity of each battery.

The next $m$ lines each contain two integers $x_j, t_j$ ($1\le x_j\le 10^9$, $1\le t_j\le n$), representing the position of each charging station and the battery it can recharge.

For each test case, it is guaranteed that $1\le x_1&lt;x_2&lt;\ldots&lt;x_m\le 10^9$. Either the sum of $n$ or the sum of $m$ over all test cases does not exceed $2\cdot 10^5$.

**Output**

For each test case, output an integer in a single line, representing the maximum distance the vehicle can travel.

Example Input：
2
3 1
3 3 3
8 1
2 2
5 2
1 2
2 1
Example Output：
12
9


## Solution


def max_distance(T, cases):
    results = []
    for _ in range(T):
        n, m = cases[_]['nm']
        a = cases[_]['a']
        stations = cases[_]['stations']
        
        # Initialize the battery charges
        charges = a[:]
        
        # Process each charging station
        for x, t in stations:
            # If the distance to the next station is greater than the current total charge, the vehicle cannot reach it
            if sum(charges) < x:
                results.append(x - 1)
                break
            # Charge the specified battery
            charges[t - 1] = a[t - 1]
        else:
            # If all stations are processed, the maximum distance is the sum of the charges
            results.append(sum(charges))
    
    return results

# Example usage
T = 2
cases = [
    {'nm': (3, 1), 'a': [3, 3, 3], 'stations': [(8, 1)]},
    {'nm': (2, 2), 'a': [5, 2], 'stations': [(1, 2), (2, 1)]}
]

print(max_distance(T, cases))



## CODE


def max_distance(T, cases):
    results = []
    for _ in range(T):
        n, m = cases[_]['nm']
        a = cases[_]['a']
        stations = cases[_]['stations']
        
        # Initialize the battery charges
        charges = a[:]
        
        # Process each charging station
        for x, t in stations:
            # If the distance to the next station is greater than the current total charge, the vehicle cannot reach it
            if sum(charges) < x:
                results.append(x - 1)
                break
            # Charge the specified battery
            charges[t - 1] = a[t - 1]
        else:
            # If all stations are processed, the maximum distance is the sum of the charges
            results.append(sum(charges))
    
    return results

# Example usage
T = 2
cases = [
    {'nm': (3, 1), 'a': [3, 3, 3], 'stations': [(8, 1)]},
    {'nm': (2, 2), 'a': [5, 2], 'stations': [(1, 2), (2, 1)]}
]

print(max_distance(T, cases))


### Explanation
The method used in the code is as follows:

1. **Initialization**: For each test case, we initialize the charges of the batteries to their initial capacities.

2. **Processing Charging Stations**: We iterate through each charging station in the order they appear. For each station:
   - We check if the vehicle can reach the station by comparing the sum of the current battery charges to the distance to the station.
   - If the vehicle cannot reach the station, we append the distance to the results list and break out of the loop.
   - If the vehicle can reach the station, we recharge the specified battery to its full capacity.

3. **Final Calculation**: If the vehicle can reach all the charging stations, the maximum distance it can travel is the sum of the final battery charges.

4. **Output**: The results list contains the maximum distances for each test case, which is printed at the end.
## Token
[452, 540, 992]
 ### 

## Question


(K)
You have given up programming and moved to the Sanjiang Plain to start farming. During your time working in the fields, you have adopted a regular daily schedule, and now you work **exactly** $m$ units of time each day. It is now harvest season, and you need to harvest and process $n$ types of crops. For crop type $i$, processing it for one unit of time will yield a profit of $w_i$. To make your daily work less monotonous, for each crop type $i$, the time spent processing it each day can range between $[l_i, r_i]$ inclusive as an integer.

At some day, the weather forecast says that there will be a heavy rain tomorrow and you can't work, so you need to adjust your schedule to quickly gather your crops today. Specifically, you can choose at most one type of crop and remove its daily time range restriction, allowing the time spent processing this crop to be any integer in the range $[0, m]$. The time ranges for all other crops remain unchanged. You have to work **exactly** $m$ units of time as well.

You want to determine the maximum profit you can earn today.

**Input**

The first line contains two integers $n$ and $m$ ($1 \le n \le 10^5$, $1 \le m \le 10^{11}$), representing the number of crop types and the length of the workday in units of time, respectively.

The next $n$ lines each contain three integers $w_i$, $l_i$, and $r_i$ ($1 \le w_i \le 10^6$, $1 \le l_i \le r_i \le 10^6$), indicating the profits and time constraints of the crops.

It is guaranteed that $\sum_{i=1}^n l_i \le m \le \sum_{i=1}^n r_i$.

**Output**

Output a single integer representing the maximum profit you can earn today.

Example Input：
5 17
2 3 4
6 1 5
8 2 4
4 3 3
7 5 5
Example Output：
109


## Solution


def max_profit(n, m, crops):
    # Calculate the minimum and maximum possible profit without any changes
    min_profit = sum(w * l for w, l, r in crops)
    max_profit = sum(w * r for w, l, r in crops)
    
    # Calculate the current total time spent
    total_time = sum(l for _, l, _ in crops)
    
    # Calculate the initial profit
    profit = min_profit
    
    # Find the best crop to remove the time range restriction for
    for w, l, r in crops:
        # Calculate the remaining time after removing the constraint for this crop
        remaining_time = m - (total_time - l)
        
        # Calculate the profit if we use the remaining time for this crop
        additional_profit = w * min(remaining_time, r - l)
        
        # Update the maximum profit
        profit = max(profit, min_profit + additional_profit)
    
    return profit

# Example input
n = 5
m = 17
crops = [
    (2, 3, 4),
    (6, 1, 5),
    (8, 2, 4),
    (4, 3, 3),
    (7, 5, 5)
]

# Example output
print(max_profit(n, m, crops))



## CODE


def max_profit(n, m, crops):
    # Calculate the minimum and maximum possible profit without any changes
    min_profit = sum(w * l for w, l, r in crops)
    max_profit = sum(w * r for w, l, r in crops)
    
    # Calculate the current total time spent
    total_time = sum(l for _, l, _ in crops)
    
    # Calculate the initial profit
    profit = min_profit
    
    # Find the best crop to remove the time range restriction for
    for w, l, r in crops:
        # Calculate the remaining time after removing the constraint for this crop
        remaining_time = m - (total_time - l)
        
        # Calculate the profit if we use the remaining time for this crop
        additional_profit = w * min(remaining_time, r - l)
        
        # Update the maximum profit
        profit = max(profit, min_profit + additional_profit)
    
    return profit

# Example input
n = 5
m = 17
crops = [
    (2, 3, 4),
    (6, 1, 5),
    (8, 2, 4),
    (4, 3, 3),
    (7, 5, 5)
]

# Example output
print(max_profit(n, m, crops))


### Explanation
The method used in the code is as follows:

1. **Calculate the Minimum and Maximum Possible Profit Without Changes**:
   - `min_profit` is the profit calculated by processing each crop for the minimum required time (`l_i`).
   - `max_profit` is the profit calculated by processing each crop for the maximum allowed time (`r_i`).

2. **Calculate the Current Total Time Spent**:
   - `total_time` is the sum of the minimum required times for all crops.

3. **Find the Best Crop to Remove the Time Range Restriction For**:
   - For each crop, calculate the remaining time available after removing the constraint for that crop.
   - Calculate the additional profit that can be gained by using the remaining time for that crop.
   - Update the maximum profit if the new profit is higher.

4. **Return the Maximum Profit**:
   - The function returns the maximum profit that can be achieved by possibly removing the time range restriction for one crop.
## Token
[499, 547, 1046]
 ### 

## Question


(L)
There is a tree (a connected undirected graph with $n$ nodes and $n-1$ edges) consisting of $n$ nodes, with nodes numbered from $1$ to $n$. Clearly, there is a unique simple path between any two nodes in the tree.

Xiaohong and Xiaolan are playing a game on this tree. In each game, both players **independently and uniformly** select a random simple path from all $\frac{n(n-1)}{2}$ simple paths (regardless of direction) that exist in the tree. Note that they may choose the same path. Let $X$ denote the number of edges that are common to both selected paths, and the score of the game is $X^2$.

Your task is to find the expected value of the score $E(X^2)$ when Xiaohong and Xiaolan play the game once, and output the result modulo $998244353$ (see the output format for details).

**Input**

The first line contains a positive integer $T$ ($1\le T \le 10^4$), representing the number of test cases.

For each test case, the first line contains a positive integer $n$ ($2\le n \le 10^5$), representing the number of nodes in the tree.

The next $n-1$ lines each contain two positive integers $u, v$ ($1\le u,v \le n$), indicating that there is an edge between nodes $u$ and $v$. The input is guaranteed to be a tree.

The sum of all $n$ over all test cases does not exceed $10^6$.

**Output**

For each test case, output a single integer, representing the answer modulo $998244353$.

Formally, let $M=998244353$. It can be shown that the answer can be expressed as an irreducible fraction $\frac p q$, where $p$ and $q$ are integers and $q \not\equiv 0\pmod M$. Output the integer equal to $p\cdot q^{-1}\pmod M$, where $q^{-1}$ denotes the modular multiplicative inverse of $q$ modulo $M$. In other words, output such an integer $x$ that $0\le x &lt; M$ and $x\cdot q\equiv p\pmod M$. It can be proved that there is exactly one $x$ which meets the condition.

Example Input：
2
3
1 2
2 3
5
1 2
1 5
3 2
4 2
Example Output：
443664158
918384806

**Note**

For the first test case in the example, the answer without taking the modulo is $\frac{10}{9}$.

Among the $9$ possible cases:

-   In $2$ cases, the number of common edges between the two paths is $0$;
-   In $6$ cases, the number of common edges between the two paths is $1$;
-   In $1$ case, the number of common edges between the two paths is $2$.

Therefore, the answer is $E(X^2) = \frac{2 \cdot 0^2 + 6 \cdot 1^2 + 1 \cdot 2^2}{9} = \frac{10}{9}$.


## Solution


from collections import defaultdict
from math import gcd

MOD = 998244353

def mod_inv(x, mod=MOD):
    return pow(x, mod - 2, mod)

def dfs(node, parent, depth, subtree_size, depth_sum, graph):
    subtree_size[node] = 1
    depth_sum[node] = depth
    for child in graph[node]:
        if child != parent:
            dfs(child, node, depth + 1, subtree_size, depth_sum, graph)
            subtree_size[node] += subtree_size[child]
            depth_sum[node] += depth_sum[child]

def solve(n, edges):
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)

    subtree_size = [0] * (n + 1)
    depth_sum = [0] * (n + 1)
    dfs(1, -1, 0, subtree_size, depth_sum, graph)

    total_paths = n * (n - 1) // 2
    total_paths_inv = mod_inv(total_paths)

    expected_x2 = 0

    for u, v in edges:
        below = min(subtree_size[u], subtree_size[v])
        above = n - below
        paths_through_edge = below * above

        # Contribution to E(X)
        expected_x = paths_through_edge * total_paths_inv

        # Contribution to E(X^2)
        expected_x2 += paths_through_edge * (paths_through_edge - 1) * total_paths_inv * total_paths_inv
        expected_x2 += paths_through_edge * total_paths_inv

    expected_x2 %= MOD
    return expected_x2

T = int(input())
for _ in range(T):
    n = int(input())
    edges = [tuple(map(int, input().split())) for _ in range(n - 1)]
    print(solve(n, edges))



## CODE


from collections import defaultdict
from math import gcd

MOD = 998244353

def mod_inv(x, mod=MOD):
    return pow(x, mod - 2, mod)

def dfs(node, parent, depth, subtree_size, depth_sum, graph):
    subtree_size[node] = 1
    depth_sum[node] = depth
    for child in graph[node]:
        if child != parent:
            dfs(child, node, depth + 1, subtree_size, depth_sum, graph)
            subtree_size[node] += subtree_size[child]
            depth_sum[node] += depth_sum[child]

def solve(n, edges):
    graph = defaultdict(list)
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)

    subtree_size = [0] * (n + 1)
    depth_sum = [0] * (n + 1)
    dfs(1, -1, 0, subtree_size, depth_sum, graph)

    total_paths = n * (n - 1) // 2
    total_paths_inv = mod_inv(total_paths)

    expected_x2 = 0

    for u, v in edges:
        below = min(subtree_size[u], subtree_size[v])
        above = n - below
        paths_through_edge = below * above

        # Contribution to E(X)
        expected_x = paths_through_edge * total_paths_inv

        # Contribution to E(X^2)
        expected_x2 += paths_through_edge * (paths_through_edge - 1) * total_paths_inv * total_paths_inv
        expected_x2 += paths_through_edge * total_paths_inv

    expected_x2 %= MOD
    return expected_x2

T = int(input())
for _ in range(T):
    n = int(input())
    edges = [tuple(map(int, input().split())) for _ in range(n - 1)]
    print(solve(n, edges))


### Explanation
The method used in the code involves a depth-first search (DFS) to compute the size of the subtree and the sum of depths for each node in the tree. This information is then used to calculate the expected value of \(X^2\).

1. **Graph Construction**: We build an adjacency list representation of the tree using the given edges.
2. **DFS Traversal**: We perform a DFS starting from node 1 to compute the size of the subtree and the sum of depths for each node.
3. **Path Calculation**: For each edge, we calculate the number of paths that pass through that edge. This is done by considering the smaller and larger subtrees formed by the edge.
4. **Expected Value Calculation**: We calculate the contribution of each edge to the expected value of \(X^2\). The contribution is calculated based on the number of paths that pass through the edge and the total number of paths.
5. **Modulo Operation**: The final result is taken modulo \(998244353\) to ensure the result fits within the required constraints.
## Token
[641, 826, 1467]
 ### 

## Question


(M)
While learning about the ceiling function, a student wrote the following pseudocode:

1: function f(a, b)
2: i ← b
3: while i ≥ 2 do
4: if a mod i = 0 then
5: return a/i
6: end if
7: i ← i − 1
8: end while
9: return a
10: end function

You know that this is incorrect, but you are curious about the characteristics of the function f(a, b)
defined by this student. Specifically, you want to calculate the value of \sum_{i=1}^{n} f(n, i)

**Input**
The first line contains an integer T $$ 1 \leq T \leq 10^{3} $$, indicating the number of test cases.
For each test case, there is one line containing an integer n $$ 1 \leq n \leq 10^{9} $$.

Example Input：
3
5
451
114514
Example Output：
21
10251
7075858
## Solution


def f(a, b):
    for i in range(b, 1, -1):
        if a % i == 0:
            return a // i
    return a

def sum_f(n):
    result = 0
    for i in range(1, n + 1):
        result += f(n, i)
    return result

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    T = int(data[0])
    cases = list(map(int, data[1:]))
    
    for n in cases:
        print(sum_f(n))

if __name__ == "__main__":
    main()



## CODE


def f(a, b):
    for i in range(b, 1, -1):
        if a % i == 0:
            return a // i
    return a

def sum_f(n):
    result = 0
    for i in range(1, n + 1):
        result += f(n, i)
    return result

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    T = int(data[0])
    cases = list(map(int, data[1:]))
    
    for n in cases:
        print(sum_f(n))

if __name__ == "__main__":
    main()


### Explanation
The method used in the code is straightforward and follows the pseudocode provided:

1. **Function `f(a, b)`**:
   - This function iterates from `b` down to 2.
   - For each `i`, it checks if `a` is divisible by `i` (i.e., `a % i == 0`).
   - If it is, it returns `a // i`.
   - If no such `i` is found, it returns `a`.

2. **Function `sum_f(n)`**:
   - This function calculates the sum of `f(n, i)` for all `i` from 1 to `n`.
   - It initializes a result variable to 0.
   - It iterates from 1 to `n`, calling `f(n, i)` and adding the result to the result variable.
   - Finally, it returns the accumulated result.

3. **Main Function**:
   - Reads the input, which includes the number of test cases `T` and the values of `n` for each test case.
   - For each test case, it calls `sum_f(n)` and prints the result.

This approach ensures that the function `f(a, b)` is correctly implemented and the sum is calculated as required. The input is read efficiently using `sys.stdin.read` to handle large inputs.
## Token
[435, 315, 750]
 ### 

