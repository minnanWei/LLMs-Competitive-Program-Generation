## Question
(A)
Hailing from a long lost tribe of vastaya, Neeko can blend into any crowd by borrowing the appearances of others, even absorbing something of their emotional state to tell friend from foe in an instant. No one is ever sure where — or who — Neeko might be, but those who intend to do her harm will soon witness her true colors revealed, and feel the full power of her primordial spirit magic unleashed upon them.

Neeko has infiltrated a grid of characters with dimensions $n \times m$, each cell in the grid is represented by a string of length $k$. She can mimic the other cells; however, Neeko's cell has at least one character different from the other cells while all the other cells are the same. Your task is to find Neeko.

**Input**

The first line of the input contains three integers $n, m, k ~(2 \leq n, m \leq 200, 1 \leq k \leq 10)$.

The next $n$ lines contain $m \cdot k$ characters each, consisting of visible ASCII characters from !(33) to  (126). The $((j - 1) \cdot k + 1)$\-th to the $(j \cdot k)$\-th character in the $i$\-th line represents the cell $(i, j)$.

It's guaranteed that there is no extra space or line break, and the answer can be uniquely determined.

**Output**

Print two integers $r, c$, denoting the position of Neeko is in the $r$\-th row and the $c$\-th column.

Example Input1：
3 5 3
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQWQ
QWQQWQQWQQWQQwQ
Example Output1：
3 5


## Solution


def find_neeko(n, m, k, grid):
    # Create a dictionary to store the frequency of each cell's string
    cell_count = {}
    
    # Iterate through each cell in the grid
    for i in range(n):
        for j in range(m):
            cell = grid[i][j * k : (j + 1) * k]
            if cell in cell_count:
                cell_count[cell].append((i, j))
            else:
                cell_count[cell] = [(i, j)]
    
    # Find the cell that appears only once
    for cell, positions in cell_count.items():
        if len(positions) == 1:
            return positions[0]

# Read input
n, m, k = map(int, input().split())
grid = [input().strip() for _ in range(n)]

# Find and print Neeko's position
r, c = find_neeko(n, m, k, grid)
print(r + 1, c + 1)



## CODE


def find_neeko(n, m, k, grid):
    # Create a dictionary to store the frequency of each cell's string
    cell_count = {}
    
    # Iterate through each cell in the grid
    for i in range(n):
        for j in range(m):
            cell = grid[i][j * k : (j + 1) * k]
            if cell in cell_count:
                cell_count[cell].append((i, j))
            else:
                cell_count[cell] = [(i, j)]
    
    # Find the cell that appears only once
    for cell, positions in cell_count.items():
        if len(positions) == 1:
            return positions[0]

# Read input
n, m, k = map(int, input().split())
grid = [input().strip() for _ in range(n)]

# Find and print Neeko's position
r, c = find_neeko(n, m, k, grid)
print(r + 1, c + 1)


### Explanation
The method used in the code is as follows:

1. **Create a Dictionary to Store Cell Frequencies**:
   - We use a dictionary `cell_count` to store the frequency of each cell's string. The key is the string of the cell, and the value is a list of positions (row, column) where the cell appears.

2. **Iterate Through Each Cell**:
   - We iterate through each cell in the grid. For each cell, we extract the string of length `k` and update the dictionary `cell_count`.

3. **Find the Unique Cell**:
   - After populating the dictionary, we iterate through it to find the cell that appears only once. This cell corresponds to Neeko's position.

4. **Return the Position**:
   - We return the position of the unique cell, adjusting the row and column indices to be 1-based instead of 0-based.

5. **Read Input and Print Result**:
   - We read the input values `n`, `m`, and `k`, and the grid itself.
   - We call the `find_neeko` function and print the result.
## Token
[458, 475, 933]
 ### 

## Question


(C)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to construct a Push-Pop program that halts after executing **exactly $k$ instructions**. Due to the naive implementation of the interpreter, a program can contain **at most $64$ instructions**.

**Input**

The only line contains a single integer $k$ ($1\le k \le 2^{31} - 1$, $k$ is odd).

**Output**

The first line contains an integer $n ~(1\le n\le 64)$ denoting the number of instructions, and then follows $n$ lines denoting the Push-Pop program. For each instruction, $1\le a,b\le 128,~ 1\le x,y\le n$ should hold.

It is guaranteed that a solution exists for given input.

Example Input1：
1
Example Output1：
1
HALT; PUSH 1 GOTO 1

Example Input2：
5
Example Output2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4

**Note**

For the second example, instructions are: 1(PUSH), 2(PUSH), 3(POP), 4(POP), 2(HALT).


## Solution


def generate_push_pop_program(k):
    if k == 1:
        return "1\nHALT; PUSH 1 GOTO 1"
    
    n = 1
    while (1 << n) < k:
        n += 1
    
    instructions = []
    for i in range(1, n + 1):
        if i == 1:
            instructions.append(f"POP 1 GOTO {2}; PUSH 1 GOTO {2}")
        elif i == n:
            instructions.append(f"HALT; PUSH 1 GOTO {n}")
        else:
            instructions.append(f"POP 1 GOTO {i + 1}; PUSH 1 GOTO {i + 1}")
    
    remaining = k - (1 << n) + 1
    for i in range(n - 1, 0, -1):
        if remaining & (1 << (i - 1)):
            instructions[i - 1] = f"HALT; PUSH 1 GOTO {i + 1}"
    
    return f"{n}\n" + "\n".join(instructions)

# Example usage
k = int(input().strip())
print(generate_push_pop_program(k))



## CODE


def generate_push_pop_program(k):
    if k == 1:
        return "1\nHALT; PUSH 1 GOTO 1"
    
    n = 1
    while (1 << n) < k:
        n += 1
    
    instructions = []
    for i in range(1, n + 1):
        if i == 1:
            instructions.append(f"POP 1 GOTO {2}; PUSH 1 GOTO {2}")
        elif i == n:
            instructions.append(f"HALT; PUSH 1 GOTO {n}")
        else:
            instructions.append(f"POP 1 GOTO {i + 1}; PUSH 1 GOTO {i + 1}")
    
    remaining = k - (1 << n) + 1
    for i in range(n - 1, 0, -1):
        if remaining & (1 << (i - 1)):
            instructions[i - 1] = f"HALT; PUSH 1 GOTO {i + 1}"
    
    return f"{n}\n" + "\n".join(instructions)

# Example usage
k = int(input().strip())
print(generate_push_pop_program(k))


### Explanation
The method used in the code is to construct a Push-Pop program that halts after executing exactly \( k \) instructions. The program is constructed using a binary representation approach:

1. **Base Case**: If \( k = 1 \), the program simply halts immediately with one instruction.
2. **General Case**: For \( k > 1 \), we find the smallest \( n \) such that \( 2^n \geq k \). This \( n \) will be the number of instructions in the program.
3. **Instruction Construction**:
   - The first instruction is a POP that will push and go to the next instruction.
   - The last instruction is a HALT that will push and go to the next instruction.
   - Intermediate instructions are constructed to form a binary tree structure, where each instruction either pops and goes to the next instruction or pushes and goes to the next instruction.
4. **Adjusting for Exact \( k \)**:
   - We adjust the instructions based on the binary representation of \( k - 2^n + 1 \) to ensure the program halts after exactly \( k \) instructions.

This approach ensures that the program is constructed with at most 64 instructions and halts after exactly \( k \) instructions.
## Token
[529, 580, 1109]
 ### 

## Question


(D)
Capoo invented an interesting language named Push-Pop. This language is an interpreted language. The interpreter starts with an empty stack with infinite capacity and reads the first instruction of the custom program. There are only two kinds of instructions in this language:

-   POP a GOTO x; PUSH b GOTO y
    
    If the top element of the stack is $a$, then pop the stack once and transfer the control flow to the $x$\-th instruction (which means the next instruction will be the $x$\-th). Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    
-   HALT; PUSH b GOTO y
    
    If the stack is empty, halt the whole program after executing this instruction. Otherwise, push an element $b$ into the stack and transfer the control flow to the $y$\-th instruction.
    

Capoo wants to upgrade the naive interpreter to deal with more instructions. Given a program of **at most $1024$ instructions**, calculate the number of steps the program would execute before halting.

**Input**

The first line contains an integer $n$ ($1\le n\le 1024$), followed by $n$ lines containing one instruction each. It is guaranteed that $1\le a,b\le 1024,~ 1\le x,y\le n$ for each instruction.

**Output**

Print $-1$ if the program will never halt, or the number of instructions would execute, **modulo $998\,244\,353$**.

Example Input1：
1
HALT; PUSH 1 GOTO 1
Example Output1：
1

Example Input2：
5
POP 1 GOTO 2; PUSH 1 GOTO 2
HALT; PUSH 1 GOTO 3
POP 1 GOTO 4; PUSH 2 GOTO 4
POP 1 GOTO 2; PUSH 2 GOTO 4
HALT; PUSH 99 GOTO 4
Example Output2：
5

Example Input3：
1
POP 1 GOTO 1; PUSH 1 GOTO 1
Example Output3：
-1

**Note**

Key differences in constraints comparing to "The Empress":

-   $n \leq 1024$;
-   The answer may not exist (program never halts), in which case report $-1$;
-   For every program that will halt, print the result **modulo $998\,244\,353$**.


## Solution


def simulate_program(instructions):
    MOD = 998244353
    stack = []
    visited = set()
    current_instruction = 0
    steps = 0

    while current_instruction < len(instructions):
        if current_instruction in visited:
            return -1
        visited.add(current_instruction)
        steps += 1
        steps %= MOD

        instruction = instructions[current_instruction]
        if instruction.startswith("POP"):
            a, x, b, y = map(int, instruction.replace("POP", "").replace("GOTO", "").replace("PUSH", "").split())
            if stack and stack[-1] == a:
                stack.pop()
                current_instruction = x - 1
            else:
                stack.append(b)
                current_instruction = y - 1
        elif instruction.startswith("HALT"):
            if not stack:
                return steps
            b, y = map(int, instruction.replace("HALT", "").replace("GOTO", "").replace("PUSH", "").split())
            stack.append(b)
            current_instruction = y - 1

    return -1

# Example usage:
# n = int(input())
# instructions = [input().strip() for _ in range(n)]
# print(simulate_program(instructions))



## CODE


def simulate_program(instructions):
    MOD = 998244353
    stack = []
    visited = set()
    current_instruction = 0
    steps = 0

    while current_instruction < len(instructions):
        if current_instruction in visited:
            return -1
        visited.add(current_instruction)
        steps += 1
        steps %= MOD

        instruction = instructions[current_instruction]
        if instruction.startswith("POP"):
            a, x, b, y = map(int, instruction.replace("POP", "").replace("GOTO", "").replace("PUSH", "").split())
            if stack and stack[-1] == a:
                stack.pop()
                current_instruction = x - 1
            else:
                stack.append(b)
                current_instruction = y - 1
        elif instruction.startswith("HALT"):
            if not stack:
                return steps
            b, y = map(int, instruction.replace("HALT", "").replace("GOTO", "").replace("PUSH", "").split())
            stack.append(b)
            current_instruction = y - 1

    return -1

# Example usage:
# n = int(input())
# instructions = [input().strip() for _ in range(n)]
# print(simulate_program(instructions))


### Explanation
The method used in the code is a simulation of the Push-Pop language interpreter. The program is executed step by step, and the state of the stack and the current instruction index are tracked. The `visited` set is used to detect infinite loops. The `steps` variable counts the number of instructions executed, and it is taken modulo `998244353` to handle large numbers. The program halts if the `HALT` instruction is reached and the stack is empty. If the program enters an infinite loop, it returns `-1`.
## Token
[393, 640, 1033]
 ### 

## Question


(E)
In the ever-changing and chaotic environment of Night City, uncertainty is the only certainty. For safe travel, edgerunners rely on the best technology. Despite their premium price and corporation background, Delamain AI armed cabs provide the most reliable mode of transportation.

Today, you need to make a lengthy journey across Night City. The Delamain cab's fare structure is as follows:

-   The base fare is $ A $  eurodollars, covering the first $ X $  meters.
-   For the next $ Y $  meters, the fare is $ B $  eurodollars per meter.
-   Beyond $ X + Y $  meters, the fare is $ C $  eurodollars per meter.

At any point, you may perform the following operation: stop and re-hail a cab. By doing so, you will immediately settle the cost of your previous cab, and the fare for the next one will be recalculated starting from the base fare. This operation can be performed for any number of times.

Now, you want to determine the minimum cost in eurodollars for traveling $D$ meters using Delamain cabs.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1 \leq T \leq 2077$) — the number of test cases. The description of the test cases follows.

The input contains six integers in a line: $ A, B, C, X, Y, D ~ (0 &lt; A, B, C, X, Y, D &lt; 10 ^ {2077})$  in decimal representation, without leading zeros.

It is guaranteed that the sum of the number of digits of $A$ among $T$ test cases does not exceed $\texttt{0x2077}$. This constraint also applies individually to $B, C, X, Y, D$.

The value $\texttt{0x2077}$ used in the constraint is a hexadecimal number, equal to the decimal number $8311$.

**Output**

For each test case, output a single line containing the minimized cost in eurodollars for traveling $D$ meters using Delamain's cabs.

It can be proven that the answer is a positive integer. Please print the integer in decimal form without leading zeros.

Example Input1：
160 27 41 3 12 3
Example Output1：
160

Example Input2：
160 27 41 3 12 4
Example Output2：
187

Example Input3：
160 27 41 3 12 99
Example Output3：
3226

Example Input4：
1 999 999 1 99 999
Example Output4：
999

Example Input5：
999 999 1 1 99 9999999999999999
Example Output5：
10000000000099799

**Note**

For the fourth sample, the optimal solution is to hail $999$ cabs, hailing a new one every meter. It seems quite weird, but you are confident that this is the optimal way to live the life in Night City.


## Solution


def min_cost(A, B, C, X, Y, D):
    # Calculate the cost without re-hailing
    if D <= X:
        return A
    elif D <= X + Y:
        return A + (D - X) * B
    else:
        return A + Y * B + (D - X - Y) * C

    # Calculate the cost with re-hailing
    base_cost = A + Y * B
    segment_cost = min(A, base_cost)
    full_segments = D // (X + Y)
    remaining_distance = D % (X + Y)
    
    if remaining_distance == 0:
        return full_segments * segment_cost
    else:
        return full_segments * segment_cost + min(A, min_cost(A, B, C, X, Y, remaining_distance))

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    index = 0
    T = int(data[index])
    index += 1
    results = []
    
    for _ in range(T):
        A = int(data[index])
        B = int(data[index + 1])
        C = int(data[index + 2])
        X = int(data[index + 3])
        Y = int(data[index + 4])
        D = int(data[index + 5])
        index += 6
        results.append(str(min_cost(A, B, C, X, Y, D)))
    
    print("\n".join(results))

if __name__ == "__main__":
    main()



## CODE


def min_cost(A, B, C, X, Y, D):
    # Calculate the cost without re-hailing
    if D <= X:
        return A
    elif D <= X + Y:
        return A + (D - X) * B
    else:
        return A + Y * B + (D - X - Y) * C

    # Calculate the cost with re-hailing
    base_cost = A + Y * B
    segment_cost = min(A, base_cost)
    full_segments = D // (X + Y)
    remaining_distance = D % (X + Y)
    
    if remaining_distance == 0:
        return full_segments * segment_cost
    else:
        return full_segments * segment_cost + min(A, min_cost(A, B, C, X, Y, remaining_distance))

def main():
    import sys
    input = sys.stdin.read
    data = input().split()
    
    index = 0
    T = int(data[index])
    index += 1
    results = []
    
    for _ in range(T):
        A = int(data[index])
        B = int(data[index + 1])
        C = int(data[index + 2])
        X = int(data[index + 3])
        Y = int(data[index + 4])
        D = int(data[index + 5])
        index += 6
        results.append(str(min_cost(A, B, C, X, Y, D)))
    
    print("\n".join(results))

if __name__ == "__main__":
    main()


### Explanation
The method used in the code involves calculating the minimum cost of traveling a given distance using Delamain cabs, considering the possibility of re-hailing the cab at any point to minimize the cost. Here's a breakdown of the approach:

1. **Initial Cost Calculation**:
   - If the distance `D` is less than or equal to `X`, the cost is simply the base fare `A`.
   - If `D` is between `X` and `X + Y`, the cost is the base fare plus the cost for the additional distance at rate `B`.
   - If `D` is greater than `X + Y`, the cost is the base fare plus the cost for the next `Y` meters at rate `B` plus the cost for the remaining distance at rate `C`.

2. **Re-hailing Cost Calculation**:
   - The cost of a full segment (up to `X + Y` meters) is calculated as `A + Y * B`.
   - The optimal cost for re-hailing is the minimum of the base fare `A` and the full segment cost.
   - The total distance `D` is divided into full segments of `X + Y` meters, and the cost for these segments is calculated.
   - The remaining distance after full segments is handled separately, and the minimum cost for this remaining distance is added to the total cost.

3. **Input and Output Handling**:
   - The input is read in bulk to optimize performance.
   - The results for each test case are stored and printed at the end.

This approach ensures that the minimum cost is calculated efficiently, even for large distances and multiple test cases.
## Token
[683, 814, 1497]
 ### 

## Question


(F)
The renowned alchemist Xu Dog discovered that precisely removing impurities could enhance the spiritual essence of the elixirs he was refining. Through day after day of alchemy, he found that the nature of these impurities was intricately related to mathematical problems. Since your progress in Dao is still shallow, Xu Dog decided to tell you the mathematical problem he needs to solve in the most straightforward way, rather than through the esoteric problems of alchemy.

Given two positive integers $n \leq m$, calculate the sum of the answers to the following problem for all subsets of size $n$ of $\{1, 2, \dots, m\}$, modulo $998\,244\,353$:

-   In a set of $n$ numbers, you can remove some numbers so that the minimum value of the set is not equal to the greatest common divisor of the set. Find the maximum number of elements that can remain in the set after removal. If no non-empty subset satisfies the condition, the answer is defined as $0$.

The greatest common divisor of a set is defined as the largest value among the common divisors of all elements in the set. For example, the greatest common divisor of the set $\{6, 9, 15\}$ is $3$.

**Input**

Input consists of a single line containing two integers $m, n~ (1 \leq n \leq m \leq 10 ^ 5)$.

**Output**

Output an integer representing the answer, modulo $998\,244\,353$.

Example Input1：
4 3
Example Output1：
7

Example Input2：
11 4
Example Output2：
1187

Example Input3：
100000 99999
Example Output3：
17356471

**Note**

For the first example, all cases are listed below:

-   $\{1, 2, 3\}$: $\{2, 3\}$
-   $\{1, 2, 4\}$: No solution
-   $\{1, 3, 4\}$: $\{3, 4\}$
-   $\{2, 3, 4\}$: $\{2, 3, 4\}$

Therefore, the answer is $2 + 0 + 2 + 3 \bmod 998\,244\,353 = 7$.


## Solution


MOD = 998244353

def power(x, y):
    res = 1
    while y > 0:
        if y % 2 == 1:
            res = (res * x) % MOD
        y = y // 2
        x = (x * x) % MOD
    return res

def inv(x):
    return power(x, MOD - 2)

def solve(m, n):
    if n == 1:
        return 0

    fac = [1] * (m + 1)
    ifac = [1] * (m + 1)
    for i in range(2, m + 1):
        fac[i] = (fac[i - 1] * i) % MOD
    ifac[m] = inv(fac[m])
    for i in range(m - 1, 0, -1):
        ifac[i] = (ifac[i + 1] * (i + 1)) % MOD

    def comb(n, k):
        if k < 0 or k > n:
            return 0
        return (fac[n] * ifac[k] * ifac[n - k]) % MOD

    result = 0
    for i in range(1, m + 1):
        count = 0
        for j in range(i, m + 1, i):
            count += 1
        if count < n:
            continue
        result += comb(count, n) * (n - 1)
        result %= MOD

    return result

m, n = map(int, input().split())
print(solve(m, n))



## CODE


MOD = 998244353

def power(x, y):
    res = 1
    while y > 0:
        if y % 2 == 1:
            res = (res * x) % MOD
        y = y // 2
        x = (x * x) % MOD
    return res

def inv(x):
    return power(x, MOD - 2)

def solve(m, n):
    if n == 1:
        return 0

    fac = [1] * (m + 1)
    ifac = [1] * (m + 1)
    for i in range(2, m + 1):
        fac[i] = (fac[i - 1] * i) % MOD
    ifac[m] = inv(fac[m])
    for i in range(m - 1, 0, -1):
        ifac[i] = (ifac[i + 1] * (i + 1)) % MOD

    def comb(n, k):
        if k < 0 or k > n:
            return 0
        return (fac[n] * ifac[k] * ifac[n - k]) % MOD

    result = 0
    for i in range(1, m + 1):
        count = 0
        for j in range(i, m + 1, i):
            count += 1
        if count < n:
            continue
        result += comb(count, n) * (n - 1)
        result %= MOD

    return result

m, n = map(int, input().split())
print(solve(m, n))


### Explanation
The method used in the code involves combinatorial counting and modular arithmetic to solve the problem efficiently. Here's a step-by-step breakdown:

1. **Modular Exponentiation and Inverse Calculation**:
   - We use a function `power` to compute \( x^y \mod 998244353 \).
   - The function `inv` computes the modular multiplicative inverse of a number using Fermat's Little Theorem, which states that \( x^{p-2} \equiv x^{-1} \mod p \) for a prime \( p \).

2. **Factorial and Inverse Factorial Precomputation**:
   - We precompute factorials and their modular inverses up to \( m \) to efficiently compute binomial coefficients.
   - The array `fac` stores factorials, and `ifac` stores their inverses.

3. **Combination Function**:
   - The function `comb` computes the binomial coefficient \( \binom{n}{k} \) using the precomputed factorials and their inverses.

4. **Main Solution Logic**:
   - We iterate over each possible minimum value \( i \) in the subset.
   - For each \( i \), we count the number of multiples of \( i \) in the set \( \{1, 2, \dots, m\} \).
   - If the count of multiples is at least \( n \), we compute the number of ways to choose \( n \) elements from these multiples and multiply by \( n - 1 \) (since we can remove the minimum element to satisfy the condition).
   - We sum these values and take the result modulo \( 998244353 \).

This approach ensures that we efficiently compute the required sum for all subsets of size \( n \) from the set \( \{1, 2, \dots, m\} \).
## Token
[773, 623, 1396]
 ### 

## Question


(J)
In this world, only the green ones never let me down.

— Chen Loong

The renowned farmer Chen Loong discovered that a rational planting density could raise production.

Now, the farm can be viewed as a three-dimensional coordinate system, and a plant can be seen as a point in it. There are $n$ different plants $A_i=(x_i,y_i,z_i)$. For each plant $A_i$, its density is defined as follows.

-   Suppose there are $a$, $b$, and $c$ plants other than $A_i$ with the same $x$, $y$, or $z$ coordinates as $A_i$, respectively. Then, the density of $A_i$ is $\max\{a,b,c\}$.

Since Chen Loong's plants love involution, he decides to remove some plants with less density. Please answer the minimum number of plants that need to be removed such that each of the remaining plants has a density greater than or equal to $k$. Note that after removing a point, the density of other plants may change. In particular, removing all plants is always considered valid.

You need to solve for $k=0,1,\ldots,n-1$ respectively.

**Input**

The input consists of multiple test cases. The first line contains a single integer $T$ ($1\le T\le 2 \times 10^4$) — the number of test cases. The description of the test cases follows.

The first line contains an integer $n$ ($1 \le n\le 10^5$) — the number of plants.

In the next $n$ lines, the $i$\-th line contains three integers $x_i$, $y_i$, and $z_i$ ($1 \le x_i,y_i,z_i \le 10^5$) — the coordinates of each plant.

It is guaranteed that the coordinates of the $n$ plants are distinct.

It is guaranteed that the sum of $n$ among $T$ test cases does not exceed $2\times 10^5$.

**Output**

For each test case, output $n$ integers in a line, representing the answers for $k=0,1,\ldots,n-1$.

Example Input1：
5
1 1 1
1 1 2
1 1 3
2 3 5
2 2 4
Example Output1：
0 0 2 5 5

Example Input2：
3
1 1 1
2 2 2
3 3 3
Example Output2：
0 3 3


## Solution


from collections import defaultdict

def solve(n, plants):
    x_count, y_count, z_count = defaultdict(int), defaultdict(int), defaultdict(int)
    density = [0] * n
    
    # Calculate initial density for each plant
    for i, (x, y, z) in enumerate(plants):
        x_count[x] += 1
        y_count[y] += 1
        z_count[z] += 1
        density[i] = max(x_count[x] - 1, y_count[y] - 1, z_count[z] - 1)
    
    # Count the frequency of each density
    density_count = [0] * n
    for d in density:
        density_count[d] += 1
    
    # Calculate the prefix sum of density_count
    for i in range(n - 2, -1, -1):
        density_count[i] += density_count[i + 1]
    
    # Calculate the minimum number of plants to remove for each k
    result = [n - density_count[k] for k in range(n)]
    return result

T = int(input())
for _ in range(T):
    n = int(input())
    plants = [tuple(map(int, input().split())) for _ in range(n)]
    print(*solve(n, plants))



## CODE


from collections import defaultdict

def solve(n, plants):
    x_count, y_count, z_count = defaultdict(int), defaultdict(int), defaultdict(int)
    density = [0] * n
    
    # Calculate initial density for each plant
    for i, (x, y, z) in enumerate(plants):
        x_count[x] += 1
        y_count[y] += 1
        z_count[z] += 1
        density[i] = max(x_count[x] - 1, y_count[y] - 1, z_count[z] - 1)
    
    # Count the frequency of each density
    density_count = [0] * n
    for d in density:
        density_count[d] += 1
    
    # Calculate the prefix sum of density_count
    for i in range(n - 2, -1, -1):
        density_count[i] += density_count[i + 1]
    
    # Calculate the minimum number of plants to remove for each k
    result = [n - density_count[k] for k in range(n)]
    return result

T = int(input())
for _ in range(T):
    n = int(input())
    plants = [tuple(map(int, input().split())) for _ in range(n)]
    print(*solve(n, plants))


### Explanation
The method used in the code involves the following steps:

1. **Initialization**: We initialize dictionaries to count the number of plants sharing the same x, y, or z coordinates. We also initialize a list to store the density of each plant.

2. **Calculate Initial Density**: For each plant, we update the count of plants sharing the same x, y, or z coordinates and calculate the initial density of the plant as the maximum of these counts minus one (since we exclude the plant itself).

3. **Count Density Frequencies**: We count the frequency of each density value using a list `density_count`.

4. **Prefix Sum Calculation**: We compute the prefix sum of the `density_count` list in reverse order to get the number of plants with density greater than or equal to each value.

5. **Calculate Minimum Removals**: For each value of `k` from 0 to `n-1`, we calculate the minimum number of plants that need to be removed to ensure all remaining plants have a density of at least `k`. This is done by subtracting the prefix sum at index `k` from the total number of plants `n`.

6. **Output**: We print the results for each test case.
## Token
[534, 639, 1173]
 ### 

## Question


(L)
Houraisan Kaguya is a NEET princess who loves to watch videos at home. Recently, she often watches videos on a famous video-sharing website called Mikufans.

There is a useful feature on Mikufans that allows users to leave a message during the video playback, which is called danmaku. Sometimes, there are so many danmaku messages at the same time that Kaguya cannot take them all in.

For simplicity, we only focus on the top danmaku messages: top danmaku messages are displayed at the top of the video screen, and each message occupies exactly one line. There is no limit to the number of danmaku messages at the same time (although Kaguya's screen will only display the first $10^9$ lines, the remaining messages will still be correctly maintained in the overflow area of the screen).

During the video playback, there may be three types of events:

1.  A **new** user sends some top danmaku messages. Each message will be placed at the topmost empty line in order.
2.  The danmaku messages from a specific user disappear, and the lines they are in become empty lines. The other messages will **not** be affected and still remain in their positions.
3.  Kaguya is interested in a danmaku message, so she wants to know the sender of the top danmaku message at a specific line.

Kaguya has many videos to watch every day, and she is too busy to re-watch the video from the beginning, so she asks you for help. Please help her find the senders of the danmaku messages.

**Input**

The first line of input contains one integer $n$ ($1 \le n \le 5 \times 10^5$), representing the number of events.

Each of the following $n$ lines contains one event in order. Each event is described in one of the following formats:

-   1 k: A new user sends $k$ ($1 \le k \le 10^9$) top danmaku messages. The ID of the user is the smallest positive integer that has not been used before.
-   2 u: The danmaku messages from user $u$ disappeared. It is guaranteed that the ID is valid, and the danmaku messages from user $u$ have not disappeared before.
-   3 l: Kaguya wants to know the ID of the sender of the danmaku message at the $l$\-th ($1 \le l \le 10^9$) topmost line. If that line is empty, the answer is defined as 0.

**Output**

For each query of type 3, output the answer in a single line.

Example Input1：
7
1 2
1 4
3 3
2 1
3 2
1 4
3 7
Example Output1：
2
0
3

Example Input2：
5
3 6
3 8
1 2
1 5
3 2
Example Output2：
0
0
1


## Solution


from collections import defaultdict
import bisect

def solve(n, events):
    user_id = 1
    user_to_lines = defaultdict(list)
    line_to_user = {}
    next_free_line = 1
    removed_lines = []

    answers = []

    for event in events:
        if event[0] == 1:
            k = event[1]
            for _ in range(k):
                if removed_lines:
                    line = removed_lines.pop(0)
                else:
                    line = next_free_line
                    next_free_line += 1
                user_to_lines[user_id].append(line)
                line_to_user[line] = user_id
            user_id += 1
        elif event[0] == 2:
            u = event[1]
            for line in user_to_lines[u]:
                del line_to_user[line]
                bisect.insort(removed_lines, line)
            user_to_lines[u] = []
        elif event[0] == 3:
            l = event[1]
            if l in line_to_user:
                answers.append(line_to_user[l])
            else:
                answers.append(0)

    return answers

# Example usage
n = 7
events = [
    (1, 2),
    (1, 4),
    (3, 3),
    (2, 1),
    (3, 2),
    (1, 4),
    (3, 7)
]
print('\n'.join(map(str, solve(n, events))))



## CODE


from collections import defaultdict
import bisect

def solve(n, events):
    user_id = 1
    user_to_lines = defaultdict(list)
    line_to_user = {}
    next_free_line = 1
    removed_lines = []

    answers = []

    for event in events:
        if event[0] == 1:
            k = event[1]
            for _ in range(k):
                if removed_lines:
                    line = removed_lines.pop(0)
                else:
                    line = next_free_line
                    next_free_line += 1
                user_to_lines[user_id].append(line)
                line_to_user[line] = user_id
            user_id += 1
        elif event[0] == 2:
            u = event[1]
            for line in user_to_lines[u]:
                del line_to_user[line]
                bisect.insort(removed_lines, line)
            user_to_lines[u] = []
        elif event[0] == 3:
            l = event[1]
            if l in line_to_user:
                answers.append(line_to_user[l])
            else:
                answers.append(0)

    return answers

# Example usage
n = 7
events = [
    (1, 2),
    (1, 4),
    (3, 3),
    (2, 1),
    (3, 2),
    (1, 4),
    (3, 7)
]
print('\n'.join(map(str, solve(n, events))))


### Explanation
The method used in the code is as follows:

1. **Data Structures**:
   - `user_id`: Tracks the next available user ID.
   - `user_to_lines`: Maps each user to the list of lines they have occupied.
   - `line_to_user`: Maps each line to the user who has occupied it.
   - `next_free_line`: Tracks the next free line number.
   - `removed_lines`: A list of lines that have been freed and can be reused.

2. **Event Handling**:
   - **Type 1 (New User Sends Messages)**:
     - For each message, if there are any removed lines, reuse the smallest one. Otherwise, use the next free line.
     - Update the `user_to_lines` and `line_to_user` mappings.
     - Increment the `user_id` for the next new user.
   - **Type 2 (User's Messages Disappear)**:
     - Remove the user's lines from the `line_to_user` mapping.
     - Insert the freed lines into the `removed_lines` list to maintain order.
     - Clear the user's entry in `user_to_lines`.
   - **Type 3 (Query the Sender of a Line)**:
     - Check if the line is in the `line_to_user` mapping.
     - If it is, return the user ID. Otherwise, return 0.

3. **Output**:
   - Collect the results of all type 3 events and print them.

This approach ensures efficient handling of the events and maintains the correct state of the danmaku messages.
## Token
[654, 732, 1386]
 ### 

